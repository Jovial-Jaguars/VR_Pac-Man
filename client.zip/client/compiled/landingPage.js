'use strict';

var _createClass = function () { function defineProperties(target, props) { for (var i = 0; i < props.length; i++) { var descriptor = props[i]; descriptor.enumerable = descriptor.enumerable || false; descriptor.configurable = true; if ("value" in descriptor) descriptor.writable = true; Object.defineProperty(target, descriptor.key, descriptor); } } return function (Constructor, protoProps, staticProps) { if (protoProps) defineProperties(Constructor.prototype, protoProps); if (staticProps) defineProperties(Constructor, staticProps); return Constructor; }; }();

function _classCallCheck(instance, Constructor) { if (!(instance instanceof Constructor)) { throw new TypeError("Cannot call a class as a function"); } }

function _possibleConstructorReturn(self, call) { if (!self) { throw new ReferenceError("this hasn't been initialised - super() hasn't been called"); } return call && (typeof call === "object" || typeof call === "function") ? call : self; }

function _inherits(subClass, superClass) { if (typeof superClass !== "function" && superClass !== null) { throw new TypeError("Super expression must either be null or a function, not " + typeof superClass); } subClass.prototype = Object.create(superClass && superClass.prototype, { constructor: { value: subClass, enumerable: false, writable: true, configurable: true } }); if (superClass) Object.setPrototypeOf ? Object.setPrototypeOf(subClass, superClass) : subClass.__proto__ = superClass; }

var LandingPage = function (_React$Component) {
  _inherits(LandingPage, _React$Component);

  function LandingPage(props) {
    _classCallCheck(this, LandingPage);

    var _this = _possibleConstructorReturn(this, (LandingPage.__proto__ || Object.getPrototypeOf(LandingPage)).call(this, props));

    _this.mazebuilderClick = _this.mazebuilderClick.bind(_this);
    return _this;
  }

  _createClass(LandingPage, [{
    key: 'navClickHome',
    value: function navClickHome() {}
  }, {
    key: 'modalClickLogin',
    value: function modalClickLogin() {
      $('.modal').css('display', 'block');
      $('#modal-signupform').css('display', 'none');
      $('#modal-loginform').css('display', 'block');
    }
  }, {
    key: 'modalClickSignup',
    value: function modalClickSignup() {
      $('.modal').css('display', 'block');
      $('#modal-loginform').css('display', 'none');
      $('#modal-signupform').css('display', 'block');
    }
  }, {
    key: 'modalClickExit',
    value: function modalClickExit() {
      $('.modal').css('display', 'none');
    }
  }, {
    key: 'mazebuilderClick',
    value: function mazebuilderClick() {
      this.props.router.push({ pathname: '/mazebuilder' });
    }
  }, {
    key: 'signupFormSubmit',
    value: function signupFormSubmit(e) {
      e.preventDefault();
      var username = $('#signup-username').val();
      var dataString = $('#signupForm').serialize();
      $.ajax({
        type: 'POST',
        url: '/signup',
        data: dataString,
        success: function () {
          console.log('successfully signed up!');
          window.username = username;
          this.props.router.push({ pathname: '/profile' });
        }.bind(this)
      });
    }
  }, {
    key: 'loginFormSubmit',
    value: function loginFormSubmit(e) {
      e.preventDefault();
      var username = $('#login-username').val();
      console.log('username:', username);
      var dataString = $('#loginForm').serialize();
      $.ajax({
        type: 'POST',
        url: '/login',
        data: dataString,
        success: function () {
          console.log('successfully logged in!');
          window.username = username;
          this.props.router.push({ pathname: '/profile' });
        }.bind(this)
      });
    }
  }, {
    key: 'render',
    value: function render() {
      return React.createElement(
        'div',
        null,
        React.createElement(
          'nav',
          null,
          React.createElement(
            'button',
            { id: 'nav-home', onClick: this.navClickHome.bind(this) },
            'Home'
          ),
          React.createElement(
            'button',
            { id: 'nav-login', onClick: this.modalClickLogin },
            'Login'
          ),
          React.createElement(
            'button',
            { id: 'nav-signup', onClick: this.modalClickSignup },
            'Signup'
          )
        ),
        React.createElement(
          'div',
          null,
          React.createElement(
            'button',
            { id: 'mazebuilder', onClick: this.mazebuilderClick },
            'Maze Builder'
          )
        ),
        React.createElement(
          'div',
          { id: 'myModal', className: 'modal' },
          React.createElement(
            'div',
            { className: 'modal-content' },
            React.createElement(
              'div',
              { className: 'modal-header' },
              React.createElement(
                'button',
                { id: 'modal-login', onClick: this.modalClickLogin },
                'Login'
              ),
              React.createElement(
                'button',
                { id: 'modal-signup', onClick: this.modalClickSignup },
                'Signup'
              ),
              React.createElement(
                'span',
                { className: 'close', onClick: this.modalClickExit },
                '\xD7'
              )
            ),
            React.createElement(
              'div',
              { id: 'modal-loginform' },
              React.createElement(
                'p',
                null,
                'Login'
              ),
              React.createElement(LoginForm, { loginFormSubmit: this.loginFormSubmit.bind(this) })
            ),
            React.createElement(
              'div',
              { id: 'modal-signupform' },
              React.createElement(
                'p',
                null,
                'Signup'
              ),
              React.createElement(SignupForm, { signupFormSubmit: this.signupFormSubmit.bind(this) }),
              React.createElement(
                'p',
                null,
                'Already have an account?',
                React.createElement(
                  'a',
                  null,
                  'Login'
                )
              )
            ),
            React.createElement(
              'div',
              { className: 'modal-footer' },
              React.createElement(
                'h3',
                null,
                ' '
              )
            )
          )
        )
      );
    }
  }]);

  return LandingPage;
}(React.Component);

window.onclick = function (event) {
  var modal = document.getElementById('myModal');
  if (event.target == modal) {
    modal.style.display = 'none';
  }
};

window.LandingPage = LandingPage;
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIi4uL2NvbXBvbmVudHMvbGFuZGluZ1BhZ2UuanN4Il0sIm5hbWVzIjpbIkxhbmRpbmdQYWdlIiwicHJvcHMiLCJtYXplYnVpbGRlckNsaWNrIiwiYmluZCIsIiQiLCJjc3MiLCJyb3V0ZXIiLCJwdXNoIiwicGF0aG5hbWUiLCJlIiwicHJldmVudERlZmF1bHQiLCJ1c2VybmFtZSIsInZhbCIsImRhdGFTdHJpbmciLCJzZXJpYWxpemUiLCJhamF4IiwidHlwZSIsInVybCIsImRhdGEiLCJzdWNjZXNzIiwiY29uc29sZSIsImxvZyIsIndpbmRvdyIsIm5hdkNsaWNrSG9tZSIsIm1vZGFsQ2xpY2tMb2dpbiIsIm1vZGFsQ2xpY2tTaWdudXAiLCJtb2RhbENsaWNrRXhpdCIsImxvZ2luRm9ybVN1Ym1pdCIsInNpZ251cEZvcm1TdWJtaXQiLCJSZWFjdCIsIkNvbXBvbmVudCIsIm9uY2xpY2siLCJldmVudCIsIm1vZGFsIiwiZG9jdW1lbnQiLCJnZXRFbGVtZW50QnlJZCIsInRhcmdldCIsInN0eWxlIiwiZGlzcGxheSJdLCJtYXBwaW5ncyI6Ijs7Ozs7Ozs7OztJQUFNQSxXOzs7QUFDSix1QkFBWUMsS0FBWixFQUFtQjtBQUFBOztBQUFBLDBIQUNYQSxLQURXOztBQUVqQixVQUFLQyxnQkFBTCxHQUF3QixNQUFLQSxnQkFBTCxDQUFzQkMsSUFBdEIsT0FBeEI7QUFGaUI7QUFHbEI7Ozs7bUNBRWMsQ0FDZDs7O3NDQUVpQjtBQUNoQkMsUUFBRSxRQUFGLEVBQVlDLEdBQVosQ0FBZ0IsU0FBaEIsRUFBMkIsT0FBM0I7QUFDQUQsUUFBRSxtQkFBRixFQUF1QkMsR0FBdkIsQ0FBMkIsU0FBM0IsRUFBc0MsTUFBdEM7QUFDQUQsUUFBRSxrQkFBRixFQUFzQkMsR0FBdEIsQ0FBMEIsU0FBMUIsRUFBcUMsT0FBckM7QUFDRDs7O3VDQUVrQjtBQUNqQkQsUUFBRSxRQUFGLEVBQVlDLEdBQVosQ0FBZ0IsU0FBaEIsRUFBMkIsT0FBM0I7QUFDQUQsUUFBRSxrQkFBRixFQUFzQkMsR0FBdEIsQ0FBMEIsU0FBMUIsRUFBcUMsTUFBckM7QUFDQUQsUUFBRSxtQkFBRixFQUF1QkMsR0FBdkIsQ0FBMkIsU0FBM0IsRUFBc0MsT0FBdEM7QUFDRDs7O3FDQUVnQjtBQUNmRCxRQUFFLFFBQUYsRUFBWUMsR0FBWixDQUFnQixTQUFoQixFQUEyQixNQUEzQjtBQUNEOzs7dUNBRWtCO0FBQ2pCLFdBQUtKLEtBQUwsQ0FBV0ssTUFBWCxDQUFrQkMsSUFBbEIsQ0FBdUIsRUFBQ0MsVUFBVSxjQUFYLEVBQXZCO0FBQ0Q7OztxQ0FFZ0JDLEMsRUFBRztBQUNsQkEsUUFBRUMsY0FBRjtBQUNBLFVBQUlDLFdBQVdQLEVBQUUsa0JBQUYsRUFBc0JRLEdBQXRCLEVBQWY7QUFDQSxVQUFJQyxhQUFhVCxFQUFFLGFBQUYsRUFBaUJVLFNBQWpCLEVBQWpCO0FBQ0FWLFFBQUVXLElBQUYsQ0FBTztBQUNMQyxjQUFNLE1BREQ7QUFFTEMsYUFBSyxTQUZBO0FBR0xDLGNBQU1MLFVBSEQ7QUFJTE0saUJBQVMsWUFBVztBQUNsQkMsa0JBQVFDLEdBQVIsQ0FBWSx5QkFBWjtBQUNBQyxpQkFBT1gsUUFBUCxHQUFrQkEsUUFBbEI7QUFDQSxlQUFLVixLQUFMLENBQVdLLE1BQVgsQ0FBa0JDLElBQWxCLENBQXVCLEVBQUNDLFVBQVUsVUFBWCxFQUF2QjtBQUNELFNBSlEsQ0FJUEwsSUFKTyxDQUlGLElBSkU7QUFKSixPQUFQO0FBVUQ7OztvQ0FFZU0sQyxFQUFHO0FBQ2pCQSxRQUFFQyxjQUFGO0FBQ0EsVUFBSUMsV0FBV1AsRUFBRSxpQkFBRixFQUFxQlEsR0FBckIsRUFBZjtBQUNBUSxjQUFRQyxHQUFSLENBQVksV0FBWixFQUF5QlYsUUFBekI7QUFDQSxVQUFJRSxhQUFhVCxFQUFFLFlBQUYsRUFBZ0JVLFNBQWhCLEVBQWpCO0FBQ0FWLFFBQUVXLElBQUYsQ0FBTztBQUNMQyxjQUFNLE1BREQ7QUFFTEMsYUFBSyxRQUZBO0FBR0xDLGNBQU1MLFVBSEQ7QUFJTE0saUJBQVMsWUFBVztBQUNsQkMsa0JBQVFDLEdBQVIsQ0FBWSx5QkFBWjtBQUNBQyxpQkFBT1gsUUFBUCxHQUFrQkEsUUFBbEI7QUFDQSxlQUFLVixLQUFMLENBQVdLLE1BQVgsQ0FBa0JDLElBQWxCLENBQXVCLEVBQUNDLFVBQVUsVUFBWCxFQUF2QjtBQUNELFNBSlEsQ0FJUEwsSUFKTyxDQUlGLElBSkU7QUFKSixPQUFQO0FBVUQ7Ozs2QkFFUTtBQUNQLGFBQ0E7QUFBQTtBQUFBO0FBQ0U7QUFBQTtBQUFBO0FBQ0U7QUFBQTtBQUFBLGNBQVEsSUFBRyxVQUFYLEVBQXNCLFNBQVMsS0FBS29CLFlBQUwsQ0FBa0JwQixJQUFsQixDQUF1QixJQUF2QixDQUEvQjtBQUFBO0FBQUEsV0FERjtBQUVFO0FBQUE7QUFBQSxjQUFRLElBQUcsV0FBWCxFQUF1QixTQUFTLEtBQUtxQixlQUFyQztBQUFBO0FBQUEsV0FGRjtBQUdFO0FBQUE7QUFBQSxjQUFRLElBQUcsWUFBWCxFQUF3QixTQUFTLEtBQUtDLGdCQUF0QztBQUFBO0FBQUE7QUFIRixTQURGO0FBTUU7QUFBQTtBQUFBO0FBQ0U7QUFBQTtBQUFBLGNBQVEsSUFBRyxhQUFYLEVBQXlCLFNBQVMsS0FBS3ZCLGdCQUF2QztBQUFBO0FBQUE7QUFERixTQU5GO0FBU0U7QUFBQTtBQUFBLFlBQUssSUFBRyxTQUFSLEVBQWtCLFdBQVUsT0FBNUI7QUFDRTtBQUFBO0FBQUEsY0FBSyxXQUFVLGVBQWY7QUFDRTtBQUFBO0FBQUEsZ0JBQUssV0FBVSxjQUFmO0FBQ0U7QUFBQTtBQUFBLGtCQUFRLElBQUcsYUFBWCxFQUF5QixTQUFTLEtBQUtzQixlQUF2QztBQUFBO0FBQUEsZUFERjtBQUVFO0FBQUE7QUFBQSxrQkFBUSxJQUFHLGNBQVgsRUFBMEIsU0FBUyxLQUFLQyxnQkFBeEM7QUFBQTtBQUFBLGVBRkY7QUFHRTtBQUFBO0FBQUEsa0JBQU0sV0FBVSxPQUFoQixFQUF3QixTQUFTLEtBQUtDLGNBQXRDO0FBQUE7QUFBQTtBQUhGLGFBREY7QUFNRTtBQUFBO0FBQUEsZ0JBQUssSUFBRyxpQkFBUjtBQUNFO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFERjtBQUVFLGtDQUFDLFNBQUQsSUFBVyxpQkFBaUIsS0FBS0MsZUFBTCxDQUFxQnhCLElBQXJCLENBQTBCLElBQTFCLENBQTVCO0FBRkYsYUFORjtBQVVFO0FBQUE7QUFBQSxnQkFBSyxJQUFHLGtCQUFSO0FBQ0U7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQURGO0FBRUUsa0NBQUMsVUFBRCxJQUFZLGtCQUFrQixLQUFLeUIsZ0JBQUwsQ0FBc0J6QixJQUF0QixDQUEyQixJQUEzQixDQUE5QixHQUZGO0FBR0U7QUFBQTtBQUFBO0FBQUE7QUFBMkI7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUEzQjtBQUhGLGFBVkY7QUFlRTtBQUFBO0FBQUEsZ0JBQUssV0FBVSxjQUFmO0FBQ0U7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQURGO0FBZkY7QUFERjtBQVRGLE9BREE7QUFpQ0Q7Ozs7RUFoR3VCMEIsTUFBTUMsUzs7QUFtR2hDUixPQUFPUyxPQUFQLEdBQWlCLFVBQVNDLEtBQVQsRUFBZ0I7QUFDL0IsTUFBSUMsUUFBUUMsU0FBU0MsY0FBVCxDQUF3QixTQUF4QixDQUFaO0FBQ0UsTUFBSUgsTUFBTUksTUFBTixJQUFnQkgsS0FBcEIsRUFBMkI7QUFDdkJBLFVBQU1JLEtBQU4sQ0FBWUMsT0FBWixHQUFzQixNQUF0QjtBQUNIO0FBQ0osQ0FMRDs7QUFPQWhCLE9BQU90QixXQUFQLEdBQXFCQSxXQUFyQiIsImZpbGUiOiJsYW5kaW5nUGFnZS5qcyIsInNvdXJjZXNDb250ZW50IjpbImNsYXNzIExhbmRpbmdQYWdlIGV4dGVuZHMgUmVhY3QuQ29tcG9uZW50IHtcclxuICBjb25zdHJ1Y3Rvcihwcm9wcykge1xyXG4gICAgc3VwZXIocHJvcHMpO1xyXG4gICAgdGhpcy5tYXplYnVpbGRlckNsaWNrID0gdGhpcy5tYXplYnVpbGRlckNsaWNrLmJpbmQodGhpcyk7XHJcbiAgfVxyXG5cclxuICBuYXZDbGlja0hvbWUoKSB7XHJcbiAgfVxyXG5cclxuICBtb2RhbENsaWNrTG9naW4oKSB7XHJcbiAgICAkKCcubW9kYWwnKS5jc3MoJ2Rpc3BsYXknLCAnYmxvY2snKTtcclxuICAgICQoJyNtb2RhbC1zaWdudXBmb3JtJykuY3NzKCdkaXNwbGF5JywgJ25vbmUnKTtcclxuICAgICQoJyNtb2RhbC1sb2dpbmZvcm0nKS5jc3MoJ2Rpc3BsYXknLCAnYmxvY2snKTtcclxuICB9XHJcblxyXG4gIG1vZGFsQ2xpY2tTaWdudXAoKSB7XHJcbiAgICAkKCcubW9kYWwnKS5jc3MoJ2Rpc3BsYXknLCAnYmxvY2snKTtcclxuICAgICQoJyNtb2RhbC1sb2dpbmZvcm0nKS5jc3MoJ2Rpc3BsYXknLCAnbm9uZScpO1xyXG4gICAgJCgnI21vZGFsLXNpZ251cGZvcm0nKS5jc3MoJ2Rpc3BsYXknLCAnYmxvY2snKTtcclxuICB9XHJcblxyXG4gIG1vZGFsQ2xpY2tFeGl0KCkge1xyXG4gICAgJCgnLm1vZGFsJykuY3NzKCdkaXNwbGF5JywgJ25vbmUnKTtcclxuICB9XHJcblxyXG4gIG1hemVidWlsZGVyQ2xpY2soKSB7XHJcbiAgICB0aGlzLnByb3BzLnJvdXRlci5wdXNoKHtwYXRobmFtZTogJy9tYXplYnVpbGRlcid9KTtcclxuICB9XHJcblxyXG4gIHNpZ251cEZvcm1TdWJtaXQoZSkge1xyXG4gICAgZS5wcmV2ZW50RGVmYXVsdCgpXHJcbiAgICB2YXIgdXNlcm5hbWUgPSAkKCcjc2lnbnVwLXVzZXJuYW1lJykudmFsKCk7XHJcbiAgICB2YXIgZGF0YVN0cmluZyA9ICQoJyNzaWdudXBGb3JtJykuc2VyaWFsaXplKCk7XHJcbiAgICAkLmFqYXgoe1xyXG4gICAgICB0eXBlOiAnUE9TVCcsXHJcbiAgICAgIHVybDogJy9zaWdudXAnLFxyXG4gICAgICBkYXRhOiBkYXRhU3RyaW5nLFxyXG4gICAgICBzdWNjZXNzOiBmdW5jdGlvbigpIHtcclxuICAgICAgICBjb25zb2xlLmxvZygnc3VjY2Vzc2Z1bGx5IHNpZ25lZCB1cCEnKTtcclxuICAgICAgICB3aW5kb3cudXNlcm5hbWUgPSB1c2VybmFtZTtcclxuICAgICAgICB0aGlzLnByb3BzLnJvdXRlci5wdXNoKHtwYXRobmFtZTogJy9wcm9maWxlJ30pO1xyXG4gICAgICB9LmJpbmQodGhpcylcclxuICAgIH0pXHJcbiAgfVxyXG5cclxuICBsb2dpbkZvcm1TdWJtaXQoZSkge1xyXG4gICAgZS5wcmV2ZW50RGVmYXVsdCgpO1xyXG4gICAgdmFyIHVzZXJuYW1lID0gJCgnI2xvZ2luLXVzZXJuYW1lJykudmFsKCk7XHJcbiAgICBjb25zb2xlLmxvZygndXNlcm5hbWU6JywgdXNlcm5hbWUpO1xyXG4gICAgdmFyIGRhdGFTdHJpbmcgPSAkKCcjbG9naW5Gb3JtJykuc2VyaWFsaXplKCk7XHJcbiAgICAkLmFqYXgoe1xyXG4gICAgICB0eXBlOiAnUE9TVCcsXHJcbiAgICAgIHVybDogJy9sb2dpbicsXHJcbiAgICAgIGRhdGE6IGRhdGFTdHJpbmcsXHJcbiAgICAgIHN1Y2Nlc3M6IGZ1bmN0aW9uKCkge1xyXG4gICAgICAgIGNvbnNvbGUubG9nKCdzdWNjZXNzZnVsbHkgbG9nZ2VkIGluIScpO1xyXG4gICAgICAgIHdpbmRvdy51c2VybmFtZSA9IHVzZXJuYW1lO1xyXG4gICAgICAgIHRoaXMucHJvcHMucm91dGVyLnB1c2goe3BhdGhuYW1lOiAnL3Byb2ZpbGUnfSk7XHJcbiAgICAgIH0uYmluZCh0aGlzKVxyXG4gICAgfSlcclxuICB9XHJcblxyXG4gIHJlbmRlcigpIHtcclxuICAgIHJldHVybiAoXHJcbiAgICA8ZGl2PlxyXG4gICAgICA8bmF2PlxyXG4gICAgICAgIDxidXR0b24gaWQ9XCJuYXYtaG9tZVwiIG9uQ2xpY2s9e3RoaXMubmF2Q2xpY2tIb21lLmJpbmQodGhpcyl9PkhvbWU8L2J1dHRvbj5cclxuICAgICAgICA8YnV0dG9uIGlkPVwibmF2LWxvZ2luXCIgb25DbGljaz17dGhpcy5tb2RhbENsaWNrTG9naW59PkxvZ2luPC9idXR0b24+XHJcbiAgICAgICAgPGJ1dHRvbiBpZD1cIm5hdi1zaWdudXBcIiBvbkNsaWNrPXt0aGlzLm1vZGFsQ2xpY2tTaWdudXB9PlNpZ251cDwvYnV0dG9uPlxyXG4gICAgICA8L25hdj5cclxuICAgICAgPGRpdj5cclxuICAgICAgICA8YnV0dG9uIGlkPVwibWF6ZWJ1aWxkZXJcIiBvbkNsaWNrPXt0aGlzLm1hemVidWlsZGVyQ2xpY2t9Pk1hemUgQnVpbGRlcjwvYnV0dG9uPlxyXG4gICAgICA8L2Rpdj5cclxuICAgICAgPGRpdiBpZD1cIm15TW9kYWxcIiBjbGFzc05hbWU9XCJtb2RhbFwiPlxyXG4gICAgICAgIDxkaXYgY2xhc3NOYW1lPVwibW9kYWwtY29udGVudFwiPlxyXG4gICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJtb2RhbC1oZWFkZXJcIj5cclxuICAgICAgICAgICAgPGJ1dHRvbiBpZD1cIm1vZGFsLWxvZ2luXCIgb25DbGljaz17dGhpcy5tb2RhbENsaWNrTG9naW59PkxvZ2luPC9idXR0b24+XHJcbiAgICAgICAgICAgIDxidXR0b24gaWQ9XCJtb2RhbC1zaWdudXBcIiBvbkNsaWNrPXt0aGlzLm1vZGFsQ2xpY2tTaWdudXB9PlNpZ251cDwvYnV0dG9uPlxyXG4gICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJjbG9zZVwiIG9uQ2xpY2s9e3RoaXMubW9kYWxDbGlja0V4aXR9PiZ0aW1lczs8L3NwYW4+XHJcbiAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgIDxkaXYgaWQ9XCJtb2RhbC1sb2dpbmZvcm1cIj5cclxuICAgICAgICAgICAgPHA+TG9naW48L3A+XHJcbiAgICAgICAgICAgIDxMb2dpbkZvcm0gbG9naW5Gb3JtU3VibWl0PXt0aGlzLmxvZ2luRm9ybVN1Ym1pdC5iaW5kKHRoaXMpfS8+XHJcbiAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgIDxkaXYgaWQ9XCJtb2RhbC1zaWdudXBmb3JtXCI+XHJcbiAgICAgICAgICAgIDxwPlNpZ251cDwvcD5cclxuICAgICAgICAgICAgPFNpZ251cEZvcm0gc2lnbnVwRm9ybVN1Ym1pdD17dGhpcy5zaWdudXBGb3JtU3VibWl0LmJpbmQodGhpcyl9Lz5cclxuICAgICAgICAgICAgPHA+QWxyZWFkeSBoYXZlIGFuIGFjY291bnQ/PGE+TG9naW48L2E+PC9wPlxyXG4gICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cIm1vZGFsLWZvb3RlclwiPlxyXG4gICAgICAgICAgICA8aDM+IDwvaDM+XHJcbiAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICA8L2Rpdj5cclxuICAgICAgPC9kaXY+XHJcbiAgICA8L2Rpdj5cclxuICAgICk7XHJcbiAgfVxyXG59XHJcblxyXG53aW5kb3cub25jbGljayA9IGZ1bmN0aW9uKGV2ZW50KSB7XHJcbiAgdmFyIG1vZGFsID0gZG9jdW1lbnQuZ2V0RWxlbWVudEJ5SWQoJ215TW9kYWwnKTtcclxuICAgIGlmIChldmVudC50YXJnZXQgPT0gbW9kYWwpIHtcclxuICAgICAgICBtb2RhbC5zdHlsZS5kaXNwbGF5ID0gJ25vbmUnO1xyXG4gICAgfVxyXG59XHJcblxyXG53aW5kb3cuTGFuZGluZ1BhZ2UgPSBMYW5kaW5nUGFnZTsiXX0=