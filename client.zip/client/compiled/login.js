"use strict";

var LoginForm = function LoginForm(props) {
  return React.createElement(
    "form",
    { id: "loginForm" },
    React.createElement(
      "div",
      null,
      React.createElement(
        "label",
        null,
        "Username:"
      ),
      React.createElement("input", { type: "text", name: "username", id: "login-username" })
    ),
    React.createElement(
      "div",
      null,
      React.createElement(
        "label",
        null,
        "Password:"
      ),
      React.createElement("input", { type: "text", name: "password" })
    ),
    React.createElement(
      "div",
      null,
      React.createElement("input", { type: "submit", value: "Log In", onClick: props.loginFormSubmit })
    )
  );
};

window.LoginForm = LoginForm;
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIi4uL2NvbXBvbmVudHMvbG9naW4uanN4Il0sIm5hbWVzIjpbIkxvZ2luRm9ybSIsInByb3BzIiwibG9naW5Gb3JtU3VibWl0Iiwid2luZG93Il0sIm1hcHBpbmdzIjoiOztBQUFBLElBQUlBLFlBQVksU0FBWkEsU0FBWSxDQUFDQyxLQUFEO0FBQUEsU0FDZDtBQUFBO0FBQUEsTUFBTSxJQUFHLFdBQVQ7QUFDRTtBQUFBO0FBQUE7QUFDRTtBQUFBO0FBQUE7QUFBQTtBQUFBLE9BREY7QUFFRSxxQ0FBTyxNQUFLLE1BQVosRUFBbUIsTUFBSyxVQUF4QixFQUFtQyxJQUFHLGdCQUF0QztBQUZGLEtBREY7QUFLRTtBQUFBO0FBQUE7QUFDRTtBQUFBO0FBQUE7QUFBQTtBQUFBLE9BREY7QUFFRSxxQ0FBTyxNQUFLLE1BQVosRUFBbUIsTUFBSyxVQUF4QjtBQUZGLEtBTEY7QUFTRTtBQUFBO0FBQUE7QUFDRSxxQ0FBTyxNQUFLLFFBQVosRUFBcUIsT0FBTSxRQUEzQixFQUFvQyxTQUFTQSxNQUFNQyxlQUFuRDtBQURGO0FBVEYsR0FEYztBQUFBLENBQWhCOztBQWtCQUMsT0FBT0gsU0FBUCxHQUFtQkEsU0FBbkIiLCJmaWxlIjoibG9naW4uanMiLCJzb3VyY2VzQ29udGVudCI6WyJ2YXIgTG9naW5Gb3JtID0gKHByb3BzKSA9PiAoXHJcbiAgPGZvcm0gaWQ9XCJsb2dpbkZvcm1cIj5cclxuICAgIDxkaXY+XHJcbiAgICAgIDxsYWJlbD5Vc2VybmFtZTo8L2xhYmVsPlxyXG4gICAgICA8aW5wdXQgdHlwZT1cInRleHRcIiBuYW1lPVwidXNlcm5hbWVcIiBpZD1cImxvZ2luLXVzZXJuYW1lXCIvPlxyXG4gICAgPC9kaXY+XHJcbiAgICA8ZGl2PlxyXG4gICAgICA8bGFiZWw+UGFzc3dvcmQ6PC9sYWJlbD5cclxuICAgICAgPGlucHV0IHR5cGU9XCJ0ZXh0XCIgbmFtZT1cInBhc3N3b3JkXCIvPlxyXG4gICAgPC9kaXY+XHJcbiAgICA8ZGl2PlxyXG4gICAgICA8aW5wdXQgdHlwZT1cInN1Ym1pdFwiIHZhbHVlPVwiTG9nIEluXCIgb25DbGljaz17cHJvcHMubG9naW5Gb3JtU3VibWl0fS8+XHJcbiAgICA8L2Rpdj5cclxuICA8L2Zvcm0+XHJcblxyXG4pO1xyXG5cclxuXHJcbndpbmRvdy5Mb2dpbkZvcm0gPSBMb2dpbkZvcm07Il19