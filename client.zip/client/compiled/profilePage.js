'use strict';

var _createClass = function () { function defineProperties(target, props) { for (var i = 0; i < props.length; i++) { var descriptor = props[i]; descriptor.enumerable = descriptor.enumerable || false; descriptor.configurable = true; if ("value" in descriptor) descriptor.writable = true; Object.defineProperty(target, descriptor.key, descriptor); } } return function (Constructor, protoProps, staticProps) { if (protoProps) defineProperties(Constructor.prototype, protoProps); if (staticProps) defineProperties(Constructor, staticProps); return Constructor; }; }();

function _classCallCheck(instance, Constructor) { if (!(instance instanceof Constructor)) { throw new TypeError("Cannot call a class as a function"); } }

function _possibleConstructorReturn(self, call) { if (!self) { throw new ReferenceError("this hasn't been initialised - super() hasn't been called"); } return call && (typeof call === "object" || typeof call === "function") ? call : self; }

function _inherits(subClass, superClass) { if (typeof superClass !== "function" && superClass !== null) { throw new TypeError("Super expression must either be null or a function, not " + typeof superClass); } subClass.prototype = Object.create(superClass && superClass.prototype, { constructor: { value: subClass, enumerable: false, writable: true, configurable: true } }); if (superClass) Object.setPrototypeOf ? Object.setPrototypeOf(subClass, superClass) : subClass.__proto__ = superClass; }

var ProfilePage = function (_React$Component) {
  _inherits(ProfilePage, _React$Component);

  function ProfilePage(props) {
    _classCallCheck(this, ProfilePage);

    var _this = _possibleConstructorReturn(this, (ProfilePage.__proto__ || Object.getPrototypeOf(ProfilePage)).call(this, props));

    _this.state = {
      username: null,
      savedMaps: null,
      highScore: null
    };
    _this.mazebuilderClick = _this.mazebuilderClick.bind(_this);
    return _this;
  }

  _createClass(ProfilePage, [{
    key: 'logout',
    value: function logout() {
      $.ajax({
        type: 'GET',
        url: '/logout',
        success: function () {
          console.log('logged out!');
          this.props.router.push({ pathname: '/' });
        }.bind(this)
      });
    }
  }, {
    key: 'componentWillMount',
    value: function componentWillMount() {
      $.ajax({
        type: 'POST',
        url: 'profileInfo',
        data: { user: username },
        success: function (data) {
          console.log('ajax get profile info success');
          console.log('data:', JSON.stringify(data));
          this.setState({
            username: data.user.username
          });
        }.bind(this)
      });
    }
  }, {
    key: 'mazebuilderClick',
    value: function mazebuilderClick() {
      this.props.router.push({ pathname: '/mazebuilder' });
    }
  }, {
    key: 'getMazeClick',
    value: function getMazeClick() {
      $.ajax({
        type: 'GET',
        url: '/maps',
        success: function success(data) {
          console.log('ajax get /maps success');
          console.log('data:', JSON.stringify(data));
        }
      });
    }
  }, {
    key: 'render',
    value: function render() {
      return React.createElement(
        'div',
        null,
        React.createElement(
          'div',
          null,
          'Welcome ',
          this.state.username
        ),
        React.createElement(
          'button',
          { id: 'logout', onClick: this.logout.bind(this) },
          'Log Out'
        ),
        React.createElement(
          'div',
          null,
          React.createElement(
            'button',
            { id: 'mazebuilder', onClick: this.mazebuilderClick },
            'Maze Builder'
          ),
          React.createElement(
            'button',
            { id: 'getmazes', onClick: this.getMazeClick },
            'Get Mazes Wow'
          )
        )
      );
    }
  }]);

  return ProfilePage;
}(React.Component);

window.ProfilePage = ProfilePage;
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIi4uL2NvbXBvbmVudHMvcHJvZmlsZVBhZ2UuanN4Il0sIm5hbWVzIjpbIlByb2ZpbGVQYWdlIiwicHJvcHMiLCJzdGF0ZSIsInVzZXJuYW1lIiwic2F2ZWRNYXBzIiwiaGlnaFNjb3JlIiwibWF6ZWJ1aWxkZXJDbGljayIsImJpbmQiLCIkIiwiYWpheCIsInR5cGUiLCJ1cmwiLCJzdWNjZXNzIiwiY29uc29sZSIsImxvZyIsInJvdXRlciIsInB1c2giLCJwYXRobmFtZSIsImRhdGEiLCJ1c2VyIiwiSlNPTiIsInN0cmluZ2lmeSIsInNldFN0YXRlIiwibG9nb3V0IiwiZ2V0TWF6ZUNsaWNrIiwiUmVhY3QiLCJDb21wb25lbnQiLCJ3aW5kb3ciXSwibWFwcGluZ3MiOiI7Ozs7Ozs7Ozs7SUFBTUEsVzs7O0FBQ0osdUJBQVlDLEtBQVosRUFBbUI7QUFBQTs7QUFBQSwwSEFDWEEsS0FEVzs7QUFFakIsVUFBS0MsS0FBTCxHQUFhO0FBQ1hDLGdCQUFVLElBREM7QUFFWEMsaUJBQVcsSUFGQTtBQUdYQyxpQkFBVztBQUhBLEtBQWI7QUFLQSxVQUFLQyxnQkFBTCxHQUF3QixNQUFLQSxnQkFBTCxDQUFzQkMsSUFBdEIsT0FBeEI7QUFQaUI7QUFRbEI7Ozs7NkJBRVE7QUFDUEMsUUFBRUMsSUFBRixDQUFPO0FBQ0xDLGNBQU0sS0FERDtBQUVMQyxhQUFLLFNBRkE7QUFHTEMsaUJBQVMsWUFBVztBQUNsQkMsa0JBQVFDLEdBQVIsQ0FBWSxhQUFaO0FBQ0EsZUFBS2IsS0FBTCxDQUFXYyxNQUFYLENBQWtCQyxJQUFsQixDQUF1QixFQUFDQyxVQUFVLEdBQVgsRUFBdkI7QUFDRCxTQUhRLENBR1BWLElBSE8sQ0FHRixJQUhFO0FBSEosT0FBUDtBQVFEOzs7eUNBRW9CO0FBQ25CQyxRQUFFQyxJQUFGLENBQU87QUFDTEMsY0FBTSxNQUREO0FBRUxDLGFBQUssYUFGQTtBQUdMTyxjQUFNLEVBQUNDLE1BQU1oQixRQUFQLEVBSEQ7QUFJTFMsaUJBQVMsVUFBU00sSUFBVCxFQUFlO0FBQ3RCTCxrQkFBUUMsR0FBUixDQUFZLCtCQUFaO0FBQ0FELGtCQUFRQyxHQUFSLENBQVksT0FBWixFQUFxQk0sS0FBS0MsU0FBTCxDQUFlSCxJQUFmLENBQXJCO0FBQ0EsZUFBS0ksUUFBTCxDQUFjO0FBQ1puQixzQkFBVWUsS0FBS0MsSUFBTCxDQUFVaEI7QUFEUixXQUFkO0FBR0QsU0FOUSxDQU1QSSxJQU5PLENBTUYsSUFORTtBQUpKLE9BQVA7QUFZRDs7O3VDQUVrQjtBQUNqQixXQUFLTixLQUFMLENBQVdjLE1BQVgsQ0FBa0JDLElBQWxCLENBQXVCLEVBQUNDLFVBQVUsY0FBWCxFQUF2QjtBQUNEOzs7bUNBRWM7QUFDYlQsUUFBRUMsSUFBRixDQUFPO0FBQ0xDLGNBQU0sS0FERDtBQUVMQyxhQUFLLE9BRkE7QUFHTEMsaUJBQVMsaUJBQVNNLElBQVQsRUFBZTtBQUN0Qkwsa0JBQVFDLEdBQVIsQ0FBWSx3QkFBWjtBQUNBRCxrQkFBUUMsR0FBUixDQUFZLE9BQVosRUFBcUJNLEtBQUtDLFNBQUwsQ0FBZUgsSUFBZixDQUFyQjtBQUNEO0FBTkksT0FBUDtBQVFEOzs7NkJBR1E7QUFDUCxhQUNFO0FBQUE7QUFBQTtBQUNFO0FBQUE7QUFBQTtBQUFBO0FBQWMsZUFBS2hCLEtBQUwsQ0FBV0M7QUFBekIsU0FERjtBQUVFO0FBQUE7QUFBQSxZQUFRLElBQUcsUUFBWCxFQUFvQixTQUFTLEtBQUtvQixNQUFMLENBQVloQixJQUFaLENBQWlCLElBQWpCLENBQTdCO0FBQUE7QUFBQSxTQUZGO0FBR0U7QUFBQTtBQUFBO0FBQ0U7QUFBQTtBQUFBLGNBQVEsSUFBRyxhQUFYLEVBQXlCLFNBQVMsS0FBS0QsZ0JBQXZDO0FBQUE7QUFBQSxXQURGO0FBRUU7QUFBQTtBQUFBLGNBQVEsSUFBRyxVQUFYLEVBQXNCLFNBQVMsS0FBS2tCLFlBQXBDO0FBQUE7QUFBQTtBQUZGO0FBSEYsT0FERjtBQVVEOzs7O0VBaEV1QkMsTUFBTUMsUzs7QUFtRWhDQyxPQUFPM0IsV0FBUCxHQUFxQkEsV0FBckIiLCJmaWxlIjoicHJvZmlsZVBhZ2UuanMiLCJzb3VyY2VzQ29udGVudCI6WyJjbGFzcyBQcm9maWxlUGFnZSBleHRlbmRzIFJlYWN0LkNvbXBvbmVudCB7XHJcbiAgY29uc3RydWN0b3IocHJvcHMpIHtcclxuICAgIHN1cGVyKHByb3BzKTtcclxuICAgIHRoaXMuc3RhdGUgPSB7XHJcbiAgICAgIHVzZXJuYW1lOiBudWxsLFxyXG4gICAgICBzYXZlZE1hcHM6IG51bGwsXHJcbiAgICAgIGhpZ2hTY29yZTogbnVsbCxcclxuICAgIH1cclxuICAgIHRoaXMubWF6ZWJ1aWxkZXJDbGljayA9IHRoaXMubWF6ZWJ1aWxkZXJDbGljay5iaW5kKHRoaXMpO1xyXG4gIH1cclxuXHJcbiAgbG9nb3V0KCkge1xyXG4gICAgJC5hamF4KHtcclxuICAgICAgdHlwZTogJ0dFVCcsXHJcbiAgICAgIHVybDogJy9sb2dvdXQnLFxyXG4gICAgICBzdWNjZXNzOiBmdW5jdGlvbigpIHtcclxuICAgICAgICBjb25zb2xlLmxvZygnbG9nZ2VkIG91dCEnKTtcclxuICAgICAgICB0aGlzLnByb3BzLnJvdXRlci5wdXNoKHtwYXRobmFtZTogJy8nfSk7XHJcbiAgICAgIH0uYmluZCh0aGlzKVxyXG4gICAgfSlcclxuICB9XHJcblxyXG4gIGNvbXBvbmVudFdpbGxNb3VudCgpIHtcclxuICAgICQuYWpheCh7XHJcbiAgICAgIHR5cGU6ICdQT1NUJyxcclxuICAgICAgdXJsOiAncHJvZmlsZUluZm8nLFxyXG4gICAgICBkYXRhOiB7dXNlcjogdXNlcm5hbWV9LFxyXG4gICAgICBzdWNjZXNzOiBmdW5jdGlvbihkYXRhKSB7XHJcbiAgICAgICAgY29uc29sZS5sb2coJ2FqYXggZ2V0IHByb2ZpbGUgaW5mbyBzdWNjZXNzJyk7XHJcbiAgICAgICAgY29uc29sZS5sb2coJ2RhdGE6JywgSlNPTi5zdHJpbmdpZnkoZGF0YSkpO1xyXG4gICAgICAgIHRoaXMuc2V0U3RhdGUoe1xyXG4gICAgICAgICAgdXNlcm5hbWU6IGRhdGEudXNlci51c2VybmFtZVxyXG4gICAgICAgIH0pXHJcbiAgICAgIH0uYmluZCh0aGlzKVxyXG4gICAgfSk7XHJcbiAgfVxyXG5cclxuICBtYXplYnVpbGRlckNsaWNrKCkge1xyXG4gICAgdGhpcy5wcm9wcy5yb3V0ZXIucHVzaCh7cGF0aG5hbWU6ICcvbWF6ZWJ1aWxkZXInfSk7XHJcbiAgfVxyXG5cclxuICBnZXRNYXplQ2xpY2soKSB7XHJcbiAgICAkLmFqYXgoe1xyXG4gICAgICB0eXBlOiAnR0VUJyxcclxuICAgICAgdXJsOiAnL21hcHMnLFxyXG4gICAgICBzdWNjZXNzOiBmdW5jdGlvbihkYXRhKSB7XHJcbiAgICAgICAgY29uc29sZS5sb2coJ2FqYXggZ2V0IC9tYXBzIHN1Y2Nlc3MnKTtcclxuICAgICAgICBjb25zb2xlLmxvZygnZGF0YTonLCBKU09OLnN0cmluZ2lmeShkYXRhKSk7XHJcbiAgICAgIH1cclxuICAgIH0pO1xyXG4gIH1cclxuXHJcblxyXG4gIHJlbmRlcigpIHtcclxuICAgIHJldHVybiAoXHJcbiAgICAgIDxkaXY+XHJcbiAgICAgICAgPGRpdj5XZWxjb21lIHt0aGlzLnN0YXRlLnVzZXJuYW1lfTwvZGl2PlxyXG4gICAgICAgIDxidXR0b24gaWQ9XCJsb2dvdXRcIiBvbkNsaWNrPXt0aGlzLmxvZ291dC5iaW5kKHRoaXMpfT5Mb2cgT3V0PC9idXR0b24+XHJcbiAgICAgICAgPGRpdj5cclxuICAgICAgICAgIDxidXR0b24gaWQ9XCJtYXplYnVpbGRlclwiIG9uQ2xpY2s9e3RoaXMubWF6ZWJ1aWxkZXJDbGlja30+TWF6ZSBCdWlsZGVyPC9idXR0b24+XHJcbiAgICAgICAgICA8YnV0dG9uIGlkPVwiZ2V0bWF6ZXNcIiBvbkNsaWNrPXt0aGlzLmdldE1hemVDbGlja30+R2V0IE1hemVzIFdvdzwvYnV0dG9uPlxyXG4gICAgICAgIDwvZGl2PlxyXG4gICAgICA8L2Rpdj5cclxuICAgIClcclxuICB9XHJcbn1cclxuXHJcbndpbmRvdy5Qcm9maWxlUGFnZSA9IFByb2ZpbGVQYWdlOyJdfQ==