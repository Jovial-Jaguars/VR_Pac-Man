"use strict";

var _createClass = function () { function defineProperties(target, props) { for (var i = 0; i < props.length; i++) { var descriptor = props[i]; descriptor.enumerable = descriptor.enumerable || false; descriptor.configurable = true; if ("value" in descriptor) descriptor.writable = true; Object.defineProperty(target, descriptor.key, descriptor); } } return function (Constructor, protoProps, staticProps) { if (protoProps) defineProperties(Constructor.prototype, protoProps); if (staticProps) defineProperties(Constructor, staticProps); return Constructor; }; }();

function _classCallCheck(instance, Constructor) { if (!(instance instanceof Constructor)) { throw new TypeError("Cannot call a class as a function"); } }

function _possibleConstructorReturn(self, call) { if (!self) { throw new ReferenceError("this hasn't been initialised - super() hasn't been called"); } return call && (typeof call === "object" || typeof call === "function") ? call : self; }

function _inherits(subClass, superClass) { if (typeof superClass !== "function" && superClass !== null) { throw new TypeError("Super expression must either be null or a function, not " + typeof superClass); } subClass.prototype = Object.create(superClass && superClass.prototype, { constructor: { value: subClass, enumerable: false, writable: true, configurable: true } }); if (superClass) Object.setPrototypeOf ? Object.setPrototypeOf(subClass, superClass) : subClass.__proto__ = superClass; }

var MazeRunner = function (_React$Component) {
  _inherits(MazeRunner, _React$Component);

  function MazeRunner(props) {
    _classCallCheck(this, MazeRunner);

    return _possibleConstructorReturn(this, (MazeRunner.__proto__ || Object.getPrototypeOf(MazeRunner)).call(this, props));
  }

  _createClass(MazeRunner, [{
    key: "componentDidMount",
    value: function componentDidMount() {

      // Get the canvas element from our HTML above
      // window.addEventListener("load",function() {
      //     setTimeout(function(){
      //         // This hides the address bar:
      //         window.scrollTo(0, 1);
      //     }, 0);
      // });
      var obj = {};
      var checkObj;
      var that = this;
      var canvas = document.getElementById("renderCanvas");
      var score = 0;
      var canvas2;
      var pelletSound;
      var angleX = 0;
      var angleY = 0;
      var ball;
      var pelletRemover = 0;
      var inputVelocity;
      var sphereBody;
      var camera;
      var pellets = [];
      var pelletMeshes = [];
      var cameraFlag = false;
      var cam1, cam2;
      var posx = -250;
      var posz = -150;
      var ghost, ghostBody;
      var wall, pellet;
      var newInstanceWall, newInstanceSphere;
      var ghostxvelocity = 0;
      var ghostzvelocity = 25;
      var velocity;
      // Load the BABYLON 3D engine
      var engine = new BABYLON.Engine(canvas, true);
      // This begins the creation of a function that we will 'call' just after it's built
      var create = function create(scene, string) {
        var canvas = new BABYLON.ScreenSpaceCanvas2D(scene, {
          id: "ScreenCanvas",
          size: new BABYLON.Size(300, 100),
          backgroundFill: "#4040408F",
          backgroundRoundRadius: 50,
          children: [new BABYLON.Text2D(score.toString(), {
            id: "text",
            marginAlignment: "h: center, v:center",
            fontName: "20pt Arial"
          })]
        });
        return canvas;
      };
      var switchCamera = function switchCamera(cam) {
        if (scene.activeCameras[0].rotation) {
          cam.rotation = scene.activeCameras[0].rotation.clone();
        }
        cam.fov = scene.activeCameras[0].fov;
        cam.minZ = scene.activeCameras[0].minZ;
        cam.maxZ = scene.activeCameras[0].maxZ;

        if (scene.activeCameras[0].ellipsoid) {
          cam.ellipsoid = scene.activeCameras[0].ellipsoid.clone();
        }
        cam.checkCollisions = scene.activeCameras[0].checkCollisions;
        cam.applyGravity = scene.activeCameras[0].applyGravity;

        cam.speed = scene.activeCameras[0].speed;

        cam.postProcesses = scene.activeCameras[0].postProcesses;
        scene.activeCameras[0].postProcesses = [];
        scene.activeCameras[0].detachControl(canvas);
        if (scene.activeCameras[0].dispose) {
          scene.activeCameras[0].dispose();
        }
        var cool = scene.activeCameras.pop();
        scene.activeCameras.pop();
        scene.activeCameras.push(camera);
        scene.activeCameras.push(cool);

        scene.activeCameras[0].attachControl(canvas);
        cameraFlag = !cameraFlag;
      };
      var c2 = document.getElementsByClassName("camera-toggle")[0];
      c2.addEventListener("click", function () {
        //console.log(scene.activeCameras[0] instanceof BABYLON.VRDeviceOrientationFreeCamera);
        window.scrollTo(0, 1);
        if (scene.activeCameras[0] instanceof BABYLON.FreeCamera && !(scene.activeCameras[0] instanceof BABYLON.VRDeviceOrientationFreeCamera)) {
          camera = new BABYLON.VRDeviceOrientationFreeCamera("deviceOrientationCamera", scene.activeCameras[0].position, scene);
          switchCamera(camera);
          cam1 = parseFloat(Math.cos(camera.rotationQuaternion.toEulerAngles().y));
          cam2 = parseFloat(Math.sin(camera.rotationQuaternion.toEulerAngles().y));
        } else {
          //console.log('yes');
          camera = new BABYLON.FreeCamera("freeeCamera", scene.activeCameras[0].position, scene);
          switchCamera(camera);
        }
        return;
      });
      var mazemaker = function mazemaker(arr, scene, plane, camera, ball, walls) {
        var boxes = [];

        var x = -387;
        var z = 187;
        for (var i = 0; i < arr.length; i++) {
          for (var j = 0; j < arr[i].length; j++) {
            if (arr[i][j] === 1) {
              if (wall === undefined) {
                wall = BABYLON.Mesh.CreateBox("plane", 2, scene);
                wall.scaling.x = 12.5;
                wall.scaling.y = 100;
                wall.scaling.z = 12.5;
                wall.material = new BABYLON.StandardMaterial("texture1", scene);
                wall.material.emissiveTexture = new BABYLON.Texture('../assets/tron1.jpg', scene);
                createWallBody(wall.getBoundingInfo().boundingBox.center, new CANNON.Vec3(wall.scaling.x, wall.scaling.y, wall.scaling.z), 0);
              } else {
                newInstanceWall = wall.createInstance("i" + i * 16 + j);
                newInstanceWall.position.z = z;
                newInstanceWall.position.x = x;
                createWallBody(newInstanceWall.getBoundingInfo().boundingBox.center, new CANNON.Vec3(wall.scaling.x, wall.scaling.y, wall.scaling.z), 0);
              }
              walls.push(wall);
            } else if (arr[i][j] === 2) {
              if (pellet === undefined) {
                pellet = BABYLON.Mesh.CreateSphere("sphere", 20.0, 4.0, scene);
                pellet.position.z = z;
                pellet.position.x = x;
                pellet.position.y = 2;
                pellet.material = new BABYLON.StandardMaterial("wow", scene);
                pellet.material.diffuseColor = new BABYLON.Color3(0, 0.2, 0.7);
                pellet.material.emissiveColor = new BABYLON.Color3(0, .2, .7);
                var sphereBody = createSphereBody(pellet.getBoundingInfo().boundingBox.center, 4, pellet.uniqueId);
                pelletMeshes[pellet.uniqueId] = pellet;
              } else {
                newInstanceSphere = pellet.createInstance("i" + i * 16 + j);
                newInstanceSphere.position.z = z;
                newInstanceSphere.position.x = x;
                var sphereBody = createSphereBody(newInstanceSphere.getBoundingInfo().boundingBox.center, 4, newInstanceSphere.uniqueId);
                pelletMeshes[newInstanceSphere.uniqueId] = newInstanceSphere;
              }
              // var particleSystem = new BABYLON.ParticleSystem("particles", 2000, scene);

              // //Texture of each particle
              // particleSystem.particleTexture = new BABYLON.Texture("./flare.png", scene);

              // // Where the particles come from
              // particleSystem.emitter = sphere; // the starting object, the emitter

              // // Colors of all particles
              // particleSystem.color1 = new BABYLON.Color4(0.7, 0.8, 1.0, 1.0);
              // particleSystem.color2 = new BABYLON.Color4(0.2, 0.5, 1.0, 1.0);
              // particleSystem.colorDead = new BABYLON.Color4(0, 0, 0.2, 0.0);

              // // Size of each particle (random between...
              // particleSystem.minSize = 0.1;
              // particleSystem.maxSize = 0.5;

              // // Life time of each particle (random between...
              // particleSystem.minLifeTime = 0.3;
              // particleSystem.maxLifeTime = 1.5;

              // // Emission rate
              // particleSystem.emitRate = 1500;

              // // Blend mode : BLENDMODE_ONEONE, or BLENDMODE_STANDARD
              // particleSystem.blendMode = BABYLON.ParticleSystem.BLENDMODE_ONEONE;

              // // Set the gravity of all particles
              // particleSystem.gravity = new BABYLON.Vector3(0, -9.81, 0);

              // // Direction of each particle after it has been emitted
              // particleSystem.direction1 = new BABYLON.Vector3(-7, -8, 3);
              // particleSystem.direction2 = new BABYLON.Vector3(7, -8, -3);

              // // Angular speed, in radians
              // particleSystem.minAngularSpeed = 0;
              // particleSystem.maxAngularSpeed = Math.PI;

              // // Speed
              // particleSystem.minEmitPower = 1;
              // particleSystem.maxEmitPower = 3;
              // particleSystem.updateSpeed = 0.005;

              // // Start the particle system
              // particleSystem.start();

              // Fountain's animation
            } else if (arr[i][j] === 3) {
              posz = z;
              posx = x;
              //console.log('x:', camera.position.x, "z:", plane.position.z);
            }
            x += 25;
          }
          x = -387;
          z -= 25;
        }
        return boxes;
      };
      var createScene = function createScene() {

        // Now create a basic Babylon Scene object 
        var scene = new BABYLON.Scene(engine);
        scene.ambientColor = new BABYLON.Color3(0.3, 0.3, 0.3);
        //VRDeviceOrientationFreeCamera
        camera = new BABYLON.FreeCamera("camera1", new BABYLON.Vector3(0, 5, -10), scene);
        //camera.inputs.addGamepad();
        camera.setTarget(BABYLON.Vector3.Zero());
        camera.attachControl(canvas, true);
        ball = BABYLON.Mesh.CreateSphere("sphere", 20.0, 4.0, scene);
        ball.position.y = 5;
        ball.position.z = -250;
        ball.position.x = -125;
        ball.checkCollisions = true;
        ball.material = new BABYLON.StandardMaterial("wow", scene);
        ball.material.diffuseColor = new BABYLON.Color3(0, 0.2, 0.7);
        ball.material.emissiveColor = new BABYLON.Color3(0, .2, .7);
        scene.activeCameras.push(camera);
        //scene.fog = new t.FogExp2(0xD6F1FF, 0.0005);
        var skybox = BABYLON.Mesh.CreateBox("skyBox", 5000.0, scene);
        var skyboxMaterial = new BABYLON.StandardMaterial("skyBox", scene);
        skyboxMaterial.backFaceCulling = false;
        skyboxMaterial.reflectionTexture = new BABYLON.CubeTexture('assets/sky35/citysky', scene);
        skyboxMaterial.reflectionTexture.coordinatesMode = BABYLON.Texture.SKYBOX_MODE;
        skyboxMaterial.diffuseColor = new BABYLON.Color3(0, 0, 0);
        skyboxMaterial.specularColor = new BABYLON.Color3(0, 0, 0);
        skyboxMaterial.disableLighting = true;
        skybox.material = skyboxMaterial;
        skybox.infiniteDistance = true;
        skybox.renderingGroupId = 0;
        scene.fogMode = BABYLON.Scene.LINEAR;
        scene.fogDensity = 0.01;
        scene.fogStart = -400.0;
        scene.fogEnd = 400.0;
        scene.fogColor = new BABYLON.Color3(0.3, 0.9, 0.85);
        // BABYLON.SceneLoader.ImportMesh("", "../assets/", "ghostparent.babylon", scene, function (newMeshes, particleSystems, skeletons) {
        //   for (var i = 0; i < newMeshes.length; i++) {
        //     var ghosty = newMeshes[i];
        //     this.ghost = newMeshes[0];
        //     var light0 = new BABYLON.SpotLight("Spot0", new BABYLON.Vector3(0, 50, 0), new BABYLON.Vector3(0, -1, 0), 0.4, 3, scene);
        //     light0.parent = ghosty;
        //     if (ghosty.name === 'Plane') {
        //       ghosty.position.y = 50;
        //       ghosty.position.x = -200;
        //       ghosty.position.z = -10;
        //       ghosty.scaling.x = 20;
        //       ghosty.scaling.y = 10;
        //       ghosty.scaling.z = 20;

        //       ghosty.material = new BABYLON.StandardMaterial('ghosty', scene);
        //       ghosty.material.emissiveColor = new BABYLON.Color3(0.2, 0.4, 0.8);
        //     } else if (ghosty.name === 'Sphere' || ghosty.name === 'Sphere.001') {
        //       ghosty.material = new BABYLON.StandardMaterial('ghosty', scene);
        //       ghosty.material.emissiveColor = new BABYLON.Color3(1, 1, 1);
        //       ghosty.material.specularColor = new BABYLON.Color3(1, 1, 1);
        //       ghosty.material.diffuseColor = new BABYLON.Color3(0.8, 0.8, 0.8);
        //     } else if (ghosty.name === 'Sphere.002' || ghosty.name === 'Sphere.003') {
        //       ghosty.material = new BABYLON.StandardMaterial('ghosty', scene);
        //       ghosty.material.emissiveColor = new BABYLON.Color3(0, 0, 0);
        //       ghosty.material.specularColor = new BABYLON.Color3(1, 1, 1);
        //       ghosty.material.diffuseColor = new BABYLON.Color3(0.8, 0.8, 0.8);
        //     }

        //   }

        //   ghosty.material = new BABYLON.StandardMaterial("lol", scene);
        //   x.material.emissiveColor = new BABYLON.Color3(0.1, 0.8, 0.8);
        // }.bind(obj));
        var mm = new BABYLON.FreeCamera("minimap", new BABYLON.Vector3(0, 1000, 0), scene);
        mm.setTarget(new BABYLON.Vector3(0.1, 0.1, 0.1));
        // Activate the orthographic projection
        mm.mode = BABYLON.Camera.ORTHOGRAPHIC_CAMERA;
        mm.orthoLeft = -canvas.size / 2;
        mm.orthoRight = canvas.size / 2;
        mm.orthoTop = canvas.size / 2;
        mm.orthoBottom = -canvas.size / 2;

        mm.rotation.x = Math.PI / 2;

        var xstart = 0.8,
            // 80% from the left
        ystart = 0.75; // 75% from the bottom
        var width = 0.99 - xstart,
            // Almost until the right edge of the screen
        height = 1 - ystart; // Until the top edge of the screen

        mm.viewport = new BABYLON.Viewport(xstart, ystart, width, height);
        scene.activeCameras.push(mm);
        mm.layerMask = 1;
        camera.layerMask = 2;
        var light0 = new BABYLON.SpotLight("Spot0", new BABYLON.Vector3(0, 50, 0), new BABYLON.Vector3(0, -1, 0), 0.1, 3, scene);
        light0.diffuse = new BABYLON.Color3(1, 0, 0);
        light0.specular = new BABYLON.Color3(1, 1, 1);
        light0.parent = camera;
        var plane = BABYLON.Mesh.CreateBox("plane", 2, scene);
        plane.scaling.z = 200;
        plane.scaling.y = 100;
        plane.scaling.x = .2;
        plane.material = new BABYLON.StandardMaterial("texture1", scene);
        plane.material.diffuseColor = new BABYLON.Color3(0.2, 0.2, 0.8);
        plane.material.alpha = 0.2;
        createWallBody(plane.getBoundingInfo().boundingBox.center, new CANNON.Vec3(plane.scaling.x, plane.scaling.y, plane.scaling.z), 0);
        var walls = [];
        var arr = mazemaker(that.props.maze, scene, plane, scene.activeCamera, ball, walls);
        var plane2 = BABYLON.Mesh.CreateBox("plane", 2, scene);
        plane2.scaling.z = 200;
        plane2.scaling.y = 100;
        plane2.scaling.x = .2;
        plane2.position.x = -400;
        plane2.material = new BABYLON.StandardMaterial("grass.png", scene);
        plane2.material.diffuseColor = new BABYLON.Color3(0.2, 0.2, 0.8);
        plane2.material.alpha = 0.2;
        createWallBody(plane2.getBoundingInfo().boundingBox.center, new CANNON.Vec3(plane2.scaling.x, plane2.scaling.y, plane2.scaling.z), 0);
        var plane3 = BABYLON.MeshBuilder.CreateBox("plane", 2, scene);
        plane3.scaling.z = 400;
        plane3.scaling.y = 200;
        plane3.scaling.x = .2;
        plane3.rotation.y = Math.PI / 2;
        plane3.position.x = -200;
        plane3.position.z = 200;
        plane3.material = new BABYLON.StandardMaterial("texture1", scene);
        plane3.material.diffuseColor = new BABYLON.Color3(0.2, 0.2, 0.8);
        plane3.material.alpha = 0.2;
        createWallBody(plane3.getBoundingInfo().boundingBox.center, new CANNON.Vec3(plane3.scaling.x, plane3.scaling.y, plane3.scaling.z), 2);
        var plane4 = BABYLON.MeshBuilder.CreateBox("plane", 2, scene);
        plane4.scaling.z = 400;
        plane4.scaling.y = 200;
        plane4.scaling.x = 0.2;
        plane4.rotation.y = Math.PI / 2;
        plane4.position.x = -200;
        plane4.position.z = -200;
        plane4.material = new BABYLON.StandardMaterial("texture1", scene);
        plane4.material.diffuseColor = new BABYLON.Color3(0.2, 0.2, 0.8);
        plane4.material.alpha = 0.2;
        createWallBody(plane4.getBoundingInfo().boundingBox.center, new CANNON.Vec3(plane4.scaling.x, plane4.scaling.y, plane4.scaling.z), 2);

        var ground = BABYLON.Mesh.CreateGround("ground1", 1000, 1000, 2, scene);
        ground.material = new BABYLON.StandardMaterial("texture1", scene);
        ground.material.emissiveTexture = new BABYLON.Texture('../assets/ground2.jpg', scene);
        ground.material.emissiveTexture.uScale = 100.0;
        ground.material.emissiveTexture.vScale = 100.0;
        pelletSound = new BABYLON.Sound("pellet", "../assets/pellet.wav", scene);
        canvas2 = create(scene, score);
        return scene;
      }; // End of createScene function
      var createWorld = function createWorld() {
        var world = new CANNON.World();
        world.gravity.set(0, -50, 0);
        var mass = 5,
            radius = 1.25;
        var sphereShape = new CANNON.Sphere(radius); // Step 1
        sphereBody = new CANNON.Body({ mass: mass, shape: sphereShape }); // Step 2
        sphereBody.position.set(posx, 5, posz);
        sphereBody.rotation = new CANNON.Vec3();
        sphereBody.quaternion.setFromAxisAngle(new CANNON.Vec3(1, 0, 0), -Math.PI / 2);
        sphereBody.addEventListener('collide', function (e) {
          if (e.body.isPellet) {
            for (var p in pellets) {
              if (pellets[p] === pellets[e.body.pelletId]) {
                pelletMeshes[p].dispose();
                //world.remove(pellets[p]);
                pelletRemover = p;
                pelletSound.play();
                score++;
                canvas2.children[0].text = score.toString();
              }
            }
          }
        });
        world.add(sphereBody);
        var ghostShape = new CANNON.Sphere(10); // Step 1
        ghostBody = new CANNON.Body({ mass: 5, shape: ghostShape }); // Step 2
        ghostBody.position.set(-250, 5, -150);
        ghostBody.rotation = new CANNON.Vec3();
        ghostBody.quaternion.setFromAxisAngle(new CANNON.Vec3(1, 0, 0), -Math.PI / 2);
        ghostBody.addEventListener('collide', function (e) {
          ghostxvelocity = Math.floor(Math.random() * 50) - 25;
          ghostzvelocity = Math.floor(Math.random() * 50) - 25;
        });
        world.add(ghostBody);
        // sphereBody.addEventListener('collide', function(e){
        //   if(e.body.isCoin){
        //      //e.body.
        //     console.log("collided", e.body.coinID);
        //     for (c in coins){
        //       if (coins[c] === coins[e.body.coinID]){
        //         console.log("YEs please", coins[c]);
        //         coinMeshes[c].isVisible = false;

        //       }

        //     }
        //   }

        // });


        var groundShape = new CANNON.Plane();
        var groundBody = new CANNON.Body({ mass: 0, shape: groundShape });
        world.add(groundBody);
        groundBody.quaternion.setFromAxisAngle(new CANNON.Vec3(1, 0, 0), -Math.PI / 2);

        return world;
      };

      var createWallBody = function createWallBody(position, size, flag) {
        var boxShape = new CANNON.Box(size);
        var boxBody = new CANNON.Body({ shape: boxShape, mass: 0 });
        boxBody.position = position;
        if (flag === 1) {
          boxBody.quaternion.setFromAxisAngle(new CANNON.Vec3(0, 1, 0), -Math.PI / 2);
        } else if (flag === 2) {
          boxBody.quaternion.setFromAxisAngle(new CANNON.Vec3(0, 1, 0), Math.PI / 2);
        }
        world.add(boxBody);
      };

      var createSphereBody = function createSphereBody(position, radius, id) {
        var pelletShape = new CANNON.Sphere(radius);
        var pelletBody = new CANNON.Body({ mass: 0, shape: pelletShape });
        pelletBody.position = position;
        pelletBody.isPellet = true;
        pelletBody.collisionResponse = 0;
        pelletBody.pelletId = id;
        pellets[id] = pelletBody;
        world.add(pelletBody);
      };

      var world = createWorld();
      var scene = createScene();

      if (cameraFlag) {
        cam1 = parseFloat(Math.cos(camera.rotationQuaternion.toEulerAngles().y));
        cam2 = parseFloat(Math.sin(camera.rotationQuaternion.toEulerAngles().y));
      } else {
        cam1 = parseFloat(Math.cos(camera.rotation.y));
        cam2 = parseFloat(Math.sin(camera.rotation.y));
      }

      engine.runRenderLoop(function () {
        //console.log('count', obj.ghost);
        if (pelletRemover !== 0) {
          world.remove(pellets[pelletRemover]);
          pelletRemover = 0;
        }
        scene.render();
        world.step(1.0 / 60.0);
        if (cameraFlag && camera.rotationQuaternion !== undefined) {
          if (cam1 !== parseFloat(Math.cos(camera.rotationQuaternion.y)) || cam2 !== parseFloat(Math.sin(camera.rotationQuaternion.y))) {
            cam1 = parseFloat(Math.cos(camera.rotationQuaternion.toEulerAngles().y));
            cam2 = parseFloat(Math.sin(camera.rotationQuaternion.toEulerAngles().y));
            sphereBody.velocity.z = cam1 * 40;
            sphereBody.velocity.x = cam2 * 40;
          }
        } else {
          cam1 = parseFloat(Math.cos(camera.rotation.y));
          cam2 = parseFloat(Math.sin(camera.rotation.y));
          sphereBody.velocity.z = cam1 * 20;
          sphereBody.velocity.x = cam2 * 20;
        }

        ball.position.x = sphereBody.position.x;
        ball.position.y = sphereBody.position.y;
        ball.position.z = sphereBody.position.z;

        camera.position.x = sphereBody.position.x + .4;
        camera.position.y = sphereBody.position.y;
        camera.position.z = sphereBody.position.z;
        // console.log(ghost);
        // console.log(ghostBody)
        if (obj.ghost !== undefined) {
          obj.ghost.position.x = ghostBody.position.x;
          obj.ghost.position.y = ghostBody.position.y + 40;
          obj.ghost.position.z = ghostBody.position.z;
          ghostBody.velocity.z = ghostxvelocity;
          ghostBody.velocity.x = ghostzvelocity;
        }
        inputVelocity = sphereBody.velocity;
        var quatX = new CANNON.Quaternion();
        var quatY = new CANNON.Quaternion();
        quatX.setFromAxisAngle(new CANNON.Vec3(1, 0, 0), angleX);
        quatY.setFromAxisAngle(new CANNON.Vec3(0, 1, 0), angleY);
        var quaternion = quatY.mult(quatX);
        quaternion.normalize();

        var rotatedVelocity = quaternion.vmult(inputVelocity);
        sphereBody.velocity = rotatedVelocity;
      });
      window.addEventListener("resize", function () {
        engine.resize();
      });
    }
  }, {
    key: "render",
    value: function render() {
      return React.createElement(
        "div",
        { className: "canvas-container" },
        React.createElement("canvas", { id: "renderCanvas" }),
        React.createElement(
          "div",
          { className: "camera-toggle" },
          "Camera Toggle"
        )
      );
    }
  }]);

  return MazeRunner;
}(React.Component);

window.MazeRunner = MazeRunner;
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIi4uL2NvbXBvbmVudHMvbWF6ZVJ1bm5lci5qc3giXSwibmFtZXMiOlsiTWF6ZVJ1bm5lciIsInByb3BzIiwib2JqIiwiY2hlY2tPYmoiLCJ0aGF0IiwiY2FudmFzIiwiZG9jdW1lbnQiLCJnZXRFbGVtZW50QnlJZCIsInNjb3JlIiwiY2FudmFzMiIsInBlbGxldFNvdW5kIiwiYW5nbGVYIiwiYW5nbGVZIiwiYmFsbCIsInBlbGxldFJlbW92ZXIiLCJpbnB1dFZlbG9jaXR5Iiwic3BoZXJlQm9keSIsImNhbWVyYSIsInBlbGxldHMiLCJwZWxsZXRNZXNoZXMiLCJjYW1lcmFGbGFnIiwiY2FtMSIsImNhbTIiLCJwb3N4IiwicG9zeiIsImdob3N0IiwiZ2hvc3RCb2R5Iiwid2FsbCIsInBlbGxldCIsIm5ld0luc3RhbmNlV2FsbCIsIm5ld0luc3RhbmNlU3BoZXJlIiwiZ2hvc3R4dmVsb2NpdHkiLCJnaG9zdHp2ZWxvY2l0eSIsInZlbG9jaXR5IiwiZW5naW5lIiwiQkFCWUxPTiIsIkVuZ2luZSIsImNyZWF0ZSIsInNjZW5lIiwic3RyaW5nIiwiU2NyZWVuU3BhY2VDYW52YXMyRCIsImlkIiwic2l6ZSIsIlNpemUiLCJiYWNrZ3JvdW5kRmlsbCIsImJhY2tncm91bmRSb3VuZFJhZGl1cyIsImNoaWxkcmVuIiwiVGV4dDJEIiwidG9TdHJpbmciLCJtYXJnaW5BbGlnbm1lbnQiLCJmb250TmFtZSIsInN3aXRjaENhbWVyYSIsImNhbSIsImFjdGl2ZUNhbWVyYXMiLCJyb3RhdGlvbiIsImNsb25lIiwiZm92IiwibWluWiIsIm1heFoiLCJlbGxpcHNvaWQiLCJjaGVja0NvbGxpc2lvbnMiLCJhcHBseUdyYXZpdHkiLCJzcGVlZCIsInBvc3RQcm9jZXNzZXMiLCJkZXRhY2hDb250cm9sIiwiZGlzcG9zZSIsImNvb2wiLCJwb3AiLCJwdXNoIiwiYXR0YWNoQ29udHJvbCIsImMyIiwiZ2V0RWxlbWVudHNCeUNsYXNzTmFtZSIsImFkZEV2ZW50TGlzdGVuZXIiLCJ3aW5kb3ciLCJzY3JvbGxUbyIsIkZyZWVDYW1lcmEiLCJWUkRldmljZU9yaWVudGF0aW9uRnJlZUNhbWVyYSIsInBvc2l0aW9uIiwicGFyc2VGbG9hdCIsIk1hdGgiLCJjb3MiLCJyb3RhdGlvblF1YXRlcm5pb24iLCJ0b0V1bGVyQW5nbGVzIiwieSIsInNpbiIsIm1hemVtYWtlciIsImFyciIsInBsYW5lIiwid2FsbHMiLCJib3hlcyIsIngiLCJ6IiwiaSIsImxlbmd0aCIsImoiLCJ1bmRlZmluZWQiLCJNZXNoIiwiQ3JlYXRlQm94Iiwic2NhbGluZyIsIm1hdGVyaWFsIiwiU3RhbmRhcmRNYXRlcmlhbCIsImVtaXNzaXZlVGV4dHVyZSIsIlRleHR1cmUiLCJjcmVhdGVXYWxsQm9keSIsImdldEJvdW5kaW5nSW5mbyIsImJvdW5kaW5nQm94IiwiY2VudGVyIiwiQ0FOTk9OIiwiVmVjMyIsImNyZWF0ZUluc3RhbmNlIiwiQ3JlYXRlU3BoZXJlIiwiZGlmZnVzZUNvbG9yIiwiQ29sb3IzIiwiZW1pc3NpdmVDb2xvciIsImNyZWF0ZVNwaGVyZUJvZHkiLCJ1bmlxdWVJZCIsImNyZWF0ZVNjZW5lIiwiU2NlbmUiLCJhbWJpZW50Q29sb3IiLCJWZWN0b3IzIiwic2V0VGFyZ2V0IiwiWmVybyIsInNreWJveCIsInNreWJveE1hdGVyaWFsIiwiYmFja0ZhY2VDdWxsaW5nIiwicmVmbGVjdGlvblRleHR1cmUiLCJDdWJlVGV4dHVyZSIsImNvb3JkaW5hdGVzTW9kZSIsIlNLWUJPWF9NT0RFIiwic3BlY3VsYXJDb2xvciIsImRpc2FibGVMaWdodGluZyIsImluZmluaXRlRGlzdGFuY2UiLCJyZW5kZXJpbmdHcm91cElkIiwiZm9nTW9kZSIsIkxJTkVBUiIsImZvZ0RlbnNpdHkiLCJmb2dTdGFydCIsImZvZ0VuZCIsImZvZ0NvbG9yIiwibW0iLCJtb2RlIiwiQ2FtZXJhIiwiT1JUSE9HUkFQSElDX0NBTUVSQSIsIm9ydGhvTGVmdCIsIm9ydGhvUmlnaHQiLCJvcnRob1RvcCIsIm9ydGhvQm90dG9tIiwiUEkiLCJ4c3RhcnQiLCJ5c3RhcnQiLCJ3aWR0aCIsImhlaWdodCIsInZpZXdwb3J0IiwiVmlld3BvcnQiLCJsYXllck1hc2siLCJsaWdodDAiLCJTcG90TGlnaHQiLCJkaWZmdXNlIiwic3BlY3VsYXIiLCJwYXJlbnQiLCJhbHBoYSIsIm1hemUiLCJhY3RpdmVDYW1lcmEiLCJwbGFuZTIiLCJwbGFuZTMiLCJNZXNoQnVpbGRlciIsInBsYW5lNCIsImdyb3VuZCIsIkNyZWF0ZUdyb3VuZCIsInVTY2FsZSIsInZTY2FsZSIsIlNvdW5kIiwiY3JlYXRlV29ybGQiLCJ3b3JsZCIsIldvcmxkIiwiZ3Jhdml0eSIsInNldCIsIm1hc3MiLCJyYWRpdXMiLCJzcGhlcmVTaGFwZSIsIlNwaGVyZSIsIkJvZHkiLCJzaGFwZSIsInF1YXRlcm5pb24iLCJzZXRGcm9tQXhpc0FuZ2xlIiwiZSIsImJvZHkiLCJpc1BlbGxldCIsInAiLCJwZWxsZXRJZCIsInBsYXkiLCJ0ZXh0IiwiYWRkIiwiZ2hvc3RTaGFwZSIsImZsb29yIiwicmFuZG9tIiwiZ3JvdW5kU2hhcGUiLCJQbGFuZSIsImdyb3VuZEJvZHkiLCJmbGFnIiwiYm94U2hhcGUiLCJCb3giLCJib3hCb2R5IiwicGVsbGV0U2hhcGUiLCJwZWxsZXRCb2R5IiwiY29sbGlzaW9uUmVzcG9uc2UiLCJydW5SZW5kZXJMb29wIiwicmVtb3ZlIiwicmVuZGVyIiwic3RlcCIsInF1YXRYIiwiUXVhdGVybmlvbiIsInF1YXRZIiwibXVsdCIsIm5vcm1hbGl6ZSIsInJvdGF0ZWRWZWxvY2l0eSIsInZtdWx0IiwicmVzaXplIiwiUmVhY3QiLCJDb21wb25lbnQiXSwibWFwcGluZ3MiOiI7Ozs7Ozs7Ozs7SUFBTUEsVTs7O0FBQ0osc0JBQVlDLEtBQVosRUFBa0I7QUFBQTs7QUFBQSxtSEFDVkEsS0FEVTtBQUVqQjs7Ozt3Q0FFbUI7O0FBRXBCO0FBQ0U7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsVUFBSUMsTUFBSyxFQUFUO0FBQ0EsVUFBSUMsUUFBSjtBQUNBLFVBQUlDLE9BQU8sSUFBWDtBQUNBLFVBQUlDLFNBQVNDLFNBQVNDLGNBQVQsQ0FBd0IsY0FBeEIsQ0FBYjtBQUNBLFVBQUlDLFFBQVEsQ0FBWjtBQUNBLFVBQUlDLE9BQUo7QUFDQSxVQUFJQyxXQUFKO0FBQ0EsVUFBSUMsU0FBUyxDQUFiO0FBQ0EsVUFBSUMsU0FBUyxDQUFiO0FBQ0EsVUFBSUMsSUFBSjtBQUNBLFVBQUlDLGdCQUFnQixDQUFwQjtBQUNBLFVBQUlDLGFBQUo7QUFDQSxVQUFJQyxVQUFKO0FBQ0EsVUFBSUMsTUFBSjtBQUNBLFVBQUlDLFVBQVUsRUFBZDtBQUNBLFVBQUlDLGVBQWUsRUFBbkI7QUFDQSxVQUFJQyxhQUFhLEtBQWpCO0FBQ0EsVUFBSUMsSUFBSixFQUFVQyxJQUFWO0FBQ0EsVUFBSUMsT0FBTyxDQUFDLEdBQVo7QUFDQSxVQUFJQyxPQUFPLENBQUMsR0FBWjtBQUNBLFVBQUlDLEtBQUosRUFBV0MsU0FBWDtBQUNBLFVBQUlDLElBQUosRUFBVUMsTUFBVjtBQUNBLFVBQUlDLGVBQUosRUFBcUJDLGlCQUFyQjtBQUNBLFVBQUlDLGlCQUFpQixDQUFyQjtBQUNBLFVBQUlDLGlCQUFpQixFQUFyQjtBQUNBLFVBQUlDLFFBQUo7QUFDQTtBQUNBLFVBQUlDLFNBQVMsSUFBSUMsUUFBUUMsTUFBWixDQUFtQi9CLE1BQW5CLEVBQTJCLElBQTNCLENBQWI7QUFDQztBQUNELFVBQUlnQyxTQUFTLFNBQVRBLE1BQVMsQ0FBVUMsS0FBVixFQUFpQkMsTUFBakIsRUFBeUI7QUFDcEMsWUFBSWxDLFNBQVMsSUFBSThCLFFBQVFLLG1CQUFaLENBQWdDRixLQUFoQyxFQUF1QztBQUNsREcsY0FBSSxjQUQ4QztBQUVsREMsZ0JBQU0sSUFBSVAsUUFBUVEsSUFBWixDQUFpQixHQUFqQixFQUFzQixHQUF0QixDQUY0QztBQUdsREMsMEJBQWdCLFdBSGtDO0FBSWxEQyxpQ0FBdUIsRUFKMkI7QUFLbERDLG9CQUFVLENBQ1IsSUFBSVgsUUFBUVksTUFBWixDQUFtQnZDLE1BQU13QyxRQUFOLEVBQW5CLEVBQXFDO0FBQ25DUCxnQkFBSSxNQUQrQjtBQUVuQ1EsNkJBQWlCLHFCQUZrQjtBQUduQ0Msc0JBQVU7QUFIeUIsV0FBckMsQ0FEUTtBQUx3QyxTQUF2QyxDQUFiO0FBYUEsZUFBTzdDLE1BQVA7QUFDRCxPQWZEO0FBZ0JBLFVBQUk4QyxlQUFlLFNBQWZBLFlBQWUsQ0FBVUMsR0FBVixFQUFlO0FBQzlCLFlBQUlkLE1BQU1lLGFBQU4sQ0FBb0IsQ0FBcEIsRUFBdUJDLFFBQTNCLEVBQXFDO0FBQ2pDRixjQUFJRSxRQUFKLEdBQWVoQixNQUFNZSxhQUFOLENBQW9CLENBQXBCLEVBQXVCQyxRQUF2QixDQUFnQ0MsS0FBaEMsRUFBZjtBQUNIO0FBQ0RILFlBQUlJLEdBQUosR0FBVWxCLE1BQU1lLGFBQU4sQ0FBb0IsQ0FBcEIsRUFBdUJHLEdBQWpDO0FBQ0FKLFlBQUlLLElBQUosR0FBV25CLE1BQU1lLGFBQU4sQ0FBb0IsQ0FBcEIsRUFBdUJJLElBQWxDO0FBQ0FMLFlBQUlNLElBQUosR0FBV3BCLE1BQU1lLGFBQU4sQ0FBb0IsQ0FBcEIsRUFBdUJLLElBQWxDOztBQUVBLFlBQUlwQixNQUFNZSxhQUFOLENBQW9CLENBQXBCLEVBQXVCTSxTQUEzQixFQUFzQztBQUNsQ1AsY0FBSU8sU0FBSixHQUFnQnJCLE1BQU1lLGFBQU4sQ0FBb0IsQ0FBcEIsRUFBdUJNLFNBQXZCLENBQWlDSixLQUFqQyxFQUFoQjtBQUNIO0FBQ0RILFlBQUlRLGVBQUosR0FBc0J0QixNQUFNZSxhQUFOLENBQW9CLENBQXBCLEVBQXVCTyxlQUE3QztBQUNBUixZQUFJUyxZQUFKLEdBQW1CdkIsTUFBTWUsYUFBTixDQUFvQixDQUFwQixFQUF1QlEsWUFBMUM7O0FBRUFULFlBQUlVLEtBQUosR0FBWXhCLE1BQU1lLGFBQU4sQ0FBb0IsQ0FBcEIsRUFBdUJTLEtBQW5DOztBQUVBVixZQUFJVyxhQUFKLEdBQW9CekIsTUFBTWUsYUFBTixDQUFvQixDQUFwQixFQUF1QlUsYUFBM0M7QUFDQXpCLGNBQU1lLGFBQU4sQ0FBb0IsQ0FBcEIsRUFBdUJVLGFBQXZCLEdBQXVDLEVBQXZDO0FBQ0F6QixjQUFNZSxhQUFOLENBQW9CLENBQXBCLEVBQXVCVyxhQUF2QixDQUFxQzNELE1BQXJDO0FBQ0EsWUFBSWlDLE1BQU1lLGFBQU4sQ0FBb0IsQ0FBcEIsRUFBdUJZLE9BQTNCLEVBQW9DO0FBQ2xDM0IsZ0JBQU1lLGFBQU4sQ0FBb0IsQ0FBcEIsRUFBdUJZLE9BQXZCO0FBQ0Q7QUFDRCxZQUFJQyxPQUFPNUIsTUFBTWUsYUFBTixDQUFvQmMsR0FBcEIsRUFBWDtBQUNBN0IsY0FBTWUsYUFBTixDQUFvQmMsR0FBcEI7QUFDQTdCLGNBQU1lLGFBQU4sQ0FBb0JlLElBQXBCLENBQXlCbkQsTUFBekI7QUFDQXFCLGNBQU1lLGFBQU4sQ0FBb0JlLElBQXBCLENBQXlCRixJQUF6Qjs7QUFHQTVCLGNBQU1lLGFBQU4sQ0FBb0IsQ0FBcEIsRUFBdUJnQixhQUF2QixDQUFxQ2hFLE1BQXJDO0FBQ0FlLHFCQUFhLENBQUNBLFVBQWQ7QUFFSCxPQS9CRDtBQWdDQSxVQUFJa0QsS0FBS2hFLFNBQVNpRSxzQkFBVCxDQUFnQyxlQUFoQyxFQUFpRCxDQUFqRCxDQUFUO0FBQ0FELFNBQUdFLGdCQUFILENBQW9CLE9BQXBCLEVBQTZCLFlBQVk7QUFDdkM7QUFDQUMsZUFBT0MsUUFBUCxDQUFnQixDQUFoQixFQUFrQixDQUFsQjtBQUNBLFlBQUlwQyxNQUFNZSxhQUFOLENBQW9CLENBQXBCLGFBQWtDbEIsUUFBUXdDLFVBQTFDLElBQXdELEVBQUVyQyxNQUFNZSxhQUFOLENBQW9CLENBQXBCLGFBQWtDbEIsUUFBUXlDLDZCQUE1QyxDQUE1RCxFQUF3STtBQUN0STNELG1CQUFTLElBQUlrQixRQUFReUMsNkJBQVosQ0FBMEMseUJBQTFDLEVBQXFFdEMsTUFBTWUsYUFBTixDQUFvQixDQUFwQixFQUF1QndCLFFBQTVGLEVBQXNHdkMsS0FBdEcsQ0FBVDtBQUNBYSx1QkFBYWxDLE1BQWI7QUFDQUksaUJBQU95RCxXQUFXQyxLQUFLQyxHQUFMLENBQVMvRCxPQUFPZ0Usa0JBQVAsQ0FBMEJDLGFBQTFCLEdBQTBDQyxDQUFuRCxDQUFYLENBQVA7QUFDQTdELGlCQUFPd0QsV0FBV0MsS0FBS0ssR0FBTCxDQUFTbkUsT0FBT2dFLGtCQUFQLENBQTBCQyxhQUExQixHQUEwQ0MsQ0FBbkQsQ0FBWCxDQUFQO0FBQ0QsU0FMRCxNQUtPO0FBQ0w7QUFDQWxFLG1CQUFTLElBQUlrQixRQUFRd0MsVUFBWixDQUF1QixhQUF2QixFQUFzQ3JDLE1BQU1lLGFBQU4sQ0FBb0IsQ0FBcEIsRUFBdUJ3QixRQUE3RCxFQUF1RXZDLEtBQXZFLENBQVQ7QUFDQWEsdUJBQWFsQyxNQUFiO0FBQ0Q7QUFDRDtBQUNDLE9BZEg7QUFlRixVQUFJb0UsWUFBWSxTQUFaQSxTQUFZLENBQVNDLEdBQVQsRUFBY2hELEtBQWQsRUFBcUJpRCxLQUFyQixFQUE0QnRFLE1BQTVCLEVBQW9DSixJQUFwQyxFQUEwQzJFLEtBQTFDLEVBQWlEO0FBQy9ELFlBQUlDLFFBQVEsRUFBWjs7QUFFQSxZQUFJQyxJQUFJLENBQUMsR0FBVDtBQUNBLFlBQUlDLElBQUksR0FBUjtBQUNBLGFBQUssSUFBSUMsSUFBSSxDQUFiLEVBQWdCQSxJQUFJTixJQUFJTyxNQUF4QixFQUFnQ0QsR0FBaEMsRUFBcUM7QUFDbkMsZUFBSyxJQUFJRSxJQUFJLENBQWIsRUFBZ0JBLElBQUlSLElBQUlNLENBQUosRUFBT0MsTUFBM0IsRUFBbUNDLEdBQW5DLEVBQXdDO0FBQ3RDLGdCQUFJUixJQUFJTSxDQUFKLEVBQU9FLENBQVAsTUFBYyxDQUFsQixFQUFxQjtBQUNuQixrQkFBSW5FLFNBQVNvRSxTQUFiLEVBQXdCO0FBQ3RCcEUsdUJBQU9RLFFBQVE2RCxJQUFSLENBQWFDLFNBQWIsQ0FBdUIsT0FBdkIsRUFBZ0MsQ0FBaEMsRUFBbUMzRCxLQUFuQyxDQUFQO0FBQ0FYLHFCQUFLdUUsT0FBTCxDQUFhUixDQUFiLEdBQWlCLElBQWpCO0FBQ0EvRCxxQkFBS3VFLE9BQUwsQ0FBYWYsQ0FBYixHQUFpQixHQUFqQjtBQUNBeEQscUJBQUt1RSxPQUFMLENBQWFQLENBQWIsR0FBaUIsSUFBakI7QUFDQWhFLHFCQUFLd0UsUUFBTCxHQUFnQixJQUFJaEUsUUFBUWlFLGdCQUFaLENBQTZCLFVBQTdCLEVBQXlDOUQsS0FBekMsQ0FBaEI7QUFDQVgscUJBQUt3RSxRQUFMLENBQWNFLGVBQWQsR0FBZ0MsSUFBSWxFLFFBQVFtRSxPQUFaLENBQW9CLHFCQUFwQixFQUEyQ2hFLEtBQTNDLENBQWhDO0FBQ0FpRSwrQkFBZTVFLEtBQUs2RSxlQUFMLEdBQXVCQyxXQUF2QixDQUFtQ0MsTUFBbEQsRUFBMEQsSUFBSUMsT0FBT0MsSUFBWCxDQUFnQmpGLEtBQUt1RSxPQUFMLENBQWFSLENBQTdCLEVBQWdDL0QsS0FBS3VFLE9BQUwsQ0FBYWYsQ0FBN0MsRUFBZ0R4RCxLQUFLdUUsT0FBTCxDQUFhUCxDQUE3RCxDQUExRCxFQUEySCxDQUEzSDtBQUNELGVBUkQsTUFRTztBQUNMOUQsa0NBQWtCRixLQUFLa0YsY0FBTCxDQUFvQixNQUFPakIsSUFBRyxFQUFWLEdBQWdCRSxDQUFwQyxDQUFsQjtBQUNBakUsZ0NBQWdCZ0QsUUFBaEIsQ0FBeUJjLENBQXpCLEdBQTZCQSxDQUE3QjtBQUNBOUQsZ0NBQWdCZ0QsUUFBaEIsQ0FBeUJhLENBQXpCLEdBQTZCQSxDQUE3QjtBQUNBYSwrQkFBZTFFLGdCQUFnQjJFLGVBQWhCLEdBQWtDQyxXQUFsQyxDQUE4Q0MsTUFBN0QsRUFBcUUsSUFBSUMsT0FBT0MsSUFBWCxDQUFnQmpGLEtBQUt1RSxPQUFMLENBQWFSLENBQTdCLEVBQWdDL0QsS0FBS3VFLE9BQUwsQ0FBYWYsQ0FBN0MsRUFBZ0R4RCxLQUFLdUUsT0FBTCxDQUFhUCxDQUE3RCxDQUFyRSxFQUFzSSxDQUF0STtBQUNEO0FBQ0RILG9CQUFNcEIsSUFBTixDQUFXekMsSUFBWDtBQUNELGFBaEJELE1BZ0JPLElBQUkyRCxJQUFJTSxDQUFKLEVBQU9FLENBQVAsTUFBYyxDQUFsQixFQUFxQjtBQUMxQixrQkFBR2xFLFdBQVdtRSxTQUFkLEVBQXlCO0FBQ3ZCbkUseUJBQVNPLFFBQVE2RCxJQUFSLENBQWFjLFlBQWIsQ0FBMEIsUUFBMUIsRUFBb0MsSUFBcEMsRUFBMEMsR0FBMUMsRUFBK0N4RSxLQUEvQyxDQUFUO0FBQ0FWLHVCQUFPaUQsUUFBUCxDQUFnQmMsQ0FBaEIsR0FBb0JBLENBQXBCO0FBQ0EvRCx1QkFBT2lELFFBQVAsQ0FBZ0JhLENBQWhCLEdBQW9CQSxDQUFwQjtBQUNBOUQsdUJBQU9pRCxRQUFQLENBQWdCTSxDQUFoQixHQUFvQixDQUFwQjtBQUNBdkQsdUJBQU91RSxRQUFQLEdBQWtCLElBQUloRSxRQUFRaUUsZ0JBQVosQ0FBNkIsS0FBN0IsRUFBb0M5RCxLQUFwQyxDQUFsQjtBQUNBVix1QkFBT3VFLFFBQVAsQ0FBZ0JZLFlBQWhCLEdBQStCLElBQUk1RSxRQUFRNkUsTUFBWixDQUFtQixDQUFuQixFQUFzQixHQUF0QixFQUEyQixHQUEzQixDQUEvQjtBQUNBcEYsdUJBQU91RSxRQUFQLENBQWdCYyxhQUFoQixHQUFnQyxJQUFJOUUsUUFBUTZFLE1BQVosQ0FBbUIsQ0FBbkIsRUFBc0IsRUFBdEIsRUFBMEIsRUFBMUIsQ0FBaEM7QUFDQSxvQkFBSWhHLGFBQWFrRyxpQkFBaUJ0RixPQUFPNEUsZUFBUCxHQUF5QkMsV0FBekIsQ0FBcUNDLE1BQXRELEVBQThELENBQTlELEVBQWlFOUUsT0FBT3VGLFFBQXhFLENBQWpCO0FBQ0FoRyw2QkFBYVMsT0FBT3VGLFFBQXBCLElBQWdDdkYsTUFBaEM7QUFDRCxlQVZELE1BVU87QUFDTEUsb0NBQW9CRixPQUFPaUYsY0FBUCxDQUFzQixNQUFPakIsSUFBRyxFQUFWLEdBQWdCRSxDQUF0QyxDQUFwQjtBQUNBaEUsa0NBQWtCK0MsUUFBbEIsQ0FBMkJjLENBQTNCLEdBQStCQSxDQUEvQjtBQUNBN0Qsa0NBQWtCK0MsUUFBbEIsQ0FBMkJhLENBQTNCLEdBQStCQSxDQUEvQjtBQUNBLG9CQUFJMUUsYUFBYWtHLGlCQUFpQnBGLGtCQUFrQjBFLGVBQWxCLEdBQW9DQyxXQUFwQyxDQUFnREMsTUFBakUsRUFBeUUsQ0FBekUsRUFBNEU1RSxrQkFBa0JxRixRQUE5RixDQUFqQjtBQUNBaEcsNkJBQWFXLGtCQUFrQnFGLFFBQS9CLElBQTJDckYsaUJBQTNDO0FBQ0Q7QUFDRDs7QUFFQTtBQUNBOztBQUVBO0FBQ0E7O0FBRUE7QUFDQTtBQUNBO0FBQ0E7O0FBRUE7QUFDQTtBQUNBOztBQUVBO0FBQ0E7QUFDQTs7QUFFQTtBQUNBOztBQUVBO0FBQ0E7O0FBRUE7QUFDQTs7QUFFQTtBQUNBO0FBQ0E7O0FBRUE7QUFDQTtBQUNBOztBQUVBO0FBQ0E7QUFDQTtBQUNBOztBQUVBO0FBQ0E7O0FBRUE7QUFDRCxhQWpFTSxNQWlFQSxJQUFJd0QsSUFBSU0sQ0FBSixFQUFPRSxDQUFQLE1BQWMsQ0FBbEIsRUFBcUI7QUFDMUJ0RSxxQkFBT21FLENBQVA7QUFDQXBFLHFCQUFPbUUsQ0FBUDtBQUNBO0FBQ0Q7QUFDREEsaUJBQUssRUFBTDtBQUNEO0FBQ0RBLGNBQUksQ0FBQyxHQUFMO0FBQ0FDLGVBQUssRUFBTDtBQUNEO0FBQ0QsZUFBT0YsS0FBUDtBQUNELE9BbkdEO0FBb0dBLFVBQUkyQixjQUFjLFNBQWRBLFdBQWMsR0FBWTs7QUFFNUI7QUFDQSxZQUFJOUUsUUFBUSxJQUFJSCxRQUFRa0YsS0FBWixDQUFrQm5GLE1BQWxCLENBQVo7QUFDQUksY0FBTWdGLFlBQU4sR0FBcUIsSUFBSW5GLFFBQVE2RSxNQUFaLENBQW1CLEdBQW5CLEVBQXdCLEdBQXhCLEVBQTZCLEdBQTdCLENBQXJCO0FBQ0E7QUFDQS9GLGlCQUFTLElBQUlrQixRQUFRd0MsVUFBWixDQUF1QixTQUF2QixFQUFrQyxJQUFJeEMsUUFBUW9GLE9BQVosQ0FBb0IsQ0FBcEIsRUFBdUIsQ0FBdkIsRUFBMEIsQ0FBQyxFQUEzQixDQUFsQyxFQUFrRWpGLEtBQWxFLENBQVQ7QUFDQTtBQUNBckIsZUFBT3VHLFNBQVAsQ0FBaUJyRixRQUFRb0YsT0FBUixDQUFnQkUsSUFBaEIsRUFBakI7QUFDQXhHLGVBQU9vRCxhQUFQLENBQXFCaEUsTUFBckIsRUFBNkIsSUFBN0I7QUFDQVEsZUFBT3NCLFFBQVE2RCxJQUFSLENBQWFjLFlBQWIsQ0FBMEIsUUFBMUIsRUFBb0MsSUFBcEMsRUFBMEMsR0FBMUMsRUFBK0N4RSxLQUEvQyxDQUFQO0FBQ0F6QixhQUFLZ0UsUUFBTCxDQUFjTSxDQUFkLEdBQWtCLENBQWxCO0FBQ0F0RSxhQUFLZ0UsUUFBTCxDQUFjYyxDQUFkLEdBQWtCLENBQUMsR0FBbkI7QUFDQTlFLGFBQUtnRSxRQUFMLENBQWNhLENBQWQsR0FBa0IsQ0FBQyxHQUFuQjtBQUNBN0UsYUFBSytDLGVBQUwsR0FBdUIsSUFBdkI7QUFDQS9DLGFBQUtzRixRQUFMLEdBQWdCLElBQUloRSxRQUFRaUUsZ0JBQVosQ0FBNkIsS0FBN0IsRUFBb0M5RCxLQUFwQyxDQUFoQjtBQUNBekIsYUFBS3NGLFFBQUwsQ0FBY1ksWUFBZCxHQUE2QixJQUFJNUUsUUFBUTZFLE1BQVosQ0FBbUIsQ0FBbkIsRUFBc0IsR0FBdEIsRUFBMkIsR0FBM0IsQ0FBN0I7QUFDQW5HLGFBQUtzRixRQUFMLENBQWNjLGFBQWQsR0FBOEIsSUFBSTlFLFFBQVE2RSxNQUFaLENBQW1CLENBQW5CLEVBQXNCLEVBQXRCLEVBQTBCLEVBQTFCLENBQTlCO0FBQ0ExRSxjQUFNZSxhQUFOLENBQW9CZSxJQUFwQixDQUF5Qm5ELE1BQXpCO0FBQ0E7QUFDQSxZQUFJeUcsU0FBU3ZGLFFBQVE2RCxJQUFSLENBQWFDLFNBQWIsQ0FBdUIsUUFBdkIsRUFBaUMsTUFBakMsRUFBeUMzRCxLQUF6QyxDQUFiO0FBQ0EsWUFBSXFGLGlCQUFpQixJQUFJeEYsUUFBUWlFLGdCQUFaLENBQTZCLFFBQTdCLEVBQXVDOUQsS0FBdkMsQ0FBckI7QUFDQXFGLHVCQUFlQyxlQUFmLEdBQWlDLEtBQWpDO0FBQ0FELHVCQUFlRSxpQkFBZixHQUFtQyxJQUFJMUYsUUFBUTJGLFdBQVosQ0FBd0Isc0JBQXhCLEVBQWdEeEYsS0FBaEQsQ0FBbkM7QUFDQXFGLHVCQUFlRSxpQkFBZixDQUFpQ0UsZUFBakMsR0FBbUQ1RixRQUFRbUUsT0FBUixDQUFnQjBCLFdBQW5FO0FBQ0FMLHVCQUFlWixZQUFmLEdBQThCLElBQUk1RSxRQUFRNkUsTUFBWixDQUFtQixDQUFuQixFQUFzQixDQUF0QixFQUF5QixDQUF6QixDQUE5QjtBQUNBVyx1QkFBZU0sYUFBZixHQUErQixJQUFJOUYsUUFBUTZFLE1BQVosQ0FBbUIsQ0FBbkIsRUFBc0IsQ0FBdEIsRUFBeUIsQ0FBekIsQ0FBL0I7QUFDQVcsdUJBQWVPLGVBQWYsR0FBaUMsSUFBakM7QUFDQVIsZUFBT3ZCLFFBQVAsR0FBa0J3QixjQUFsQjtBQUNBRCxlQUFPUyxnQkFBUCxHQUEwQixJQUExQjtBQUNBVCxlQUFPVSxnQkFBUCxHQUEwQixDQUExQjtBQUNBOUYsY0FBTStGLE9BQU4sR0FBZ0JsRyxRQUFRa0YsS0FBUixDQUFjaUIsTUFBOUI7QUFDQWhHLGNBQU1pRyxVQUFOLEdBQW1CLElBQW5CO0FBQ0FqRyxjQUFNa0csUUFBTixHQUFpQixDQUFDLEtBQWxCO0FBQ0FsRyxjQUFNbUcsTUFBTixHQUFlLEtBQWY7QUFDQW5HLGNBQU1vRyxRQUFOLEdBQWlCLElBQUl2RyxRQUFRNkUsTUFBWixDQUFtQixHQUFuQixFQUF3QixHQUF4QixFQUE2QixJQUE3QixDQUFqQjtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBOztBQUVBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBOztBQUVBOztBQUVBO0FBQ0E7QUFDQTtBQUNBLFlBQUkyQixLQUFLLElBQUl4RyxRQUFRd0MsVUFBWixDQUF1QixTQUF2QixFQUFrQyxJQUFJeEMsUUFBUW9GLE9BQVosQ0FBb0IsQ0FBcEIsRUFBc0IsSUFBdEIsRUFBMkIsQ0FBM0IsQ0FBbEMsRUFBaUVqRixLQUFqRSxDQUFUO0FBQ0FxRyxXQUFHbkIsU0FBSCxDQUFhLElBQUlyRixRQUFRb0YsT0FBWixDQUFvQixHQUFwQixFQUF3QixHQUF4QixFQUE0QixHQUE1QixDQUFiO0FBQ0E7QUFDQW9CLFdBQUdDLElBQUgsR0FBVXpHLFFBQVEwRyxNQUFSLENBQWVDLG1CQUF6QjtBQUNBSCxXQUFHSSxTQUFILEdBQWUsQ0FBQzFJLE9BQU9xQyxJQUFSLEdBQWEsQ0FBNUI7QUFDQWlHLFdBQUdLLFVBQUgsR0FBZ0IzSSxPQUFPcUMsSUFBUCxHQUFZLENBQTVCO0FBQ0FpRyxXQUFHTSxRQUFILEdBQWU1SSxPQUFPcUMsSUFBUCxHQUFZLENBQTNCO0FBQ0FpRyxXQUFHTyxXQUFILEdBQWlCLENBQUM3SSxPQUFPcUMsSUFBUixHQUFhLENBQTlCOztBQUVBaUcsV0FBR3JGLFFBQUgsQ0FBWW9DLENBQVosR0FBZ0JYLEtBQUtvRSxFQUFMLEdBQVEsQ0FBeEI7O0FBRUEsWUFBSUMsU0FBUyxHQUFiO0FBQUEsWUFBa0I7QUFDZEMsaUJBQVMsSUFEYixDQWhGNEIsQ0FpRlQ7QUFDbkIsWUFBSUMsUUFBUSxPQUFLRixNQUFqQjtBQUFBLFlBQXlCO0FBQ3JCRyxpQkFBUyxJQUFFRixNQURmLENBbEY0QixDQW1GSjs7QUFFeEJWLFdBQUdhLFFBQUgsR0FBYyxJQUFJckgsUUFBUXNILFFBQVosQ0FDVkwsTUFEVSxFQUVWQyxNQUZVLEVBR1ZDLEtBSFUsRUFJVkMsTUFKVSxDQUFkO0FBTUFqSCxjQUFNZSxhQUFOLENBQW9CZSxJQUFwQixDQUF5QnVFLEVBQXpCO0FBQ0FBLFdBQUdlLFNBQUgsR0FBZSxDQUFmO0FBQ0F6SSxlQUFPeUksU0FBUCxHQUFtQixDQUFuQjtBQUNBLFlBQUlDLFNBQVMsSUFBSXhILFFBQVF5SCxTQUFaLENBQXNCLE9BQXRCLEVBQStCLElBQUl6SCxRQUFRb0YsT0FBWixDQUFvQixDQUFwQixFQUF1QixFQUF2QixFQUEyQixDQUEzQixDQUEvQixFQUE4RCxJQUFJcEYsUUFBUW9GLE9BQVosQ0FBb0IsQ0FBcEIsRUFBdUIsQ0FBQyxDQUF4QixFQUEyQixDQUEzQixDQUE5RCxFQUE2RixHQUE3RixFQUFrRyxDQUFsRyxFQUFxR2pGLEtBQXJHLENBQWI7QUFDQXFILGVBQU9FLE9BQVAsR0FBaUIsSUFBSTFILFFBQVE2RSxNQUFaLENBQW1CLENBQW5CLEVBQXNCLENBQXRCLEVBQXlCLENBQXpCLENBQWpCO0FBQ0EyQyxlQUFPRyxRQUFQLEdBQWtCLElBQUkzSCxRQUFRNkUsTUFBWixDQUFtQixDQUFuQixFQUFzQixDQUF0QixFQUF5QixDQUF6QixDQUFsQjtBQUNBMkMsZUFBT0ksTUFBUCxHQUFnQjlJLE1BQWhCO0FBQ0EsWUFBSXNFLFFBQVFwRCxRQUFRNkQsSUFBUixDQUFhQyxTQUFiLENBQXVCLE9BQXZCLEVBQWdDLENBQWhDLEVBQW1DM0QsS0FBbkMsQ0FBWjtBQUNBaUQsY0FBTVcsT0FBTixDQUFjUCxDQUFkLEdBQWtCLEdBQWxCO0FBQ0FKLGNBQU1XLE9BQU4sQ0FBY2YsQ0FBZCxHQUFrQixHQUFsQjtBQUNBSSxjQUFNVyxPQUFOLENBQWNSLENBQWQsR0FBa0IsRUFBbEI7QUFDQUgsY0FBTVksUUFBTixHQUFpQixJQUFJaEUsUUFBUWlFLGdCQUFaLENBQTZCLFVBQTdCLEVBQXlDOUQsS0FBekMsQ0FBakI7QUFDQWlELGNBQU1ZLFFBQU4sQ0FBZVksWUFBZixHQUE4QixJQUFJNUUsUUFBUTZFLE1BQVosQ0FBbUIsR0FBbkIsRUFBd0IsR0FBeEIsRUFBNkIsR0FBN0IsQ0FBOUI7QUFDQXpCLGNBQU1ZLFFBQU4sQ0FBZTZELEtBQWYsR0FBdUIsR0FBdkI7QUFDQXpELHVCQUFlaEIsTUFBTWlCLGVBQU4sR0FBd0JDLFdBQXhCLENBQW9DQyxNQUFuRCxFQUEyRCxJQUFJQyxPQUFPQyxJQUFYLENBQWdCckIsTUFBTVcsT0FBTixDQUFjUixDQUE5QixFQUFpQ0gsTUFBTVcsT0FBTixDQUFjZixDQUEvQyxFQUFrREksTUFBTVcsT0FBTixDQUFjUCxDQUFoRSxDQUEzRCxFQUErSCxDQUEvSDtBQUNBLFlBQUlILFFBQVEsRUFBWjtBQUNBLFlBQUlGLE1BQU1ELFVBQVVqRixLQUFLSCxLQUFMLENBQVdnSyxJQUFyQixFQUEyQjNILEtBQTNCLEVBQWtDaUQsS0FBbEMsRUFBeUNqRCxNQUFNNEgsWUFBL0MsRUFBNkRySixJQUE3RCxFQUFtRTJFLEtBQW5FLENBQVY7QUFDQSxZQUFJMkUsU0FBU2hJLFFBQVE2RCxJQUFSLENBQWFDLFNBQWIsQ0FBdUIsT0FBdkIsRUFBZ0MsQ0FBaEMsRUFBbUMzRCxLQUFuQyxDQUFiO0FBQ0E2SCxlQUFPakUsT0FBUCxDQUFlUCxDQUFmLEdBQW1CLEdBQW5CO0FBQ0F3RSxlQUFPakUsT0FBUCxDQUFlZixDQUFmLEdBQW1CLEdBQW5CO0FBQ0FnRixlQUFPakUsT0FBUCxDQUFlUixDQUFmLEdBQW1CLEVBQW5CO0FBQ0F5RSxlQUFPdEYsUUFBUCxDQUFnQmEsQ0FBaEIsR0FBb0IsQ0FBQyxHQUFyQjtBQUNBeUUsZUFBT2hFLFFBQVAsR0FBa0IsSUFBSWhFLFFBQVFpRSxnQkFBWixDQUE2QixXQUE3QixFQUEwQzlELEtBQTFDLENBQWxCO0FBQ0E2SCxlQUFPaEUsUUFBUCxDQUFnQlksWUFBaEIsR0FBK0IsSUFBSTVFLFFBQVE2RSxNQUFaLENBQW1CLEdBQW5CLEVBQXdCLEdBQXhCLEVBQTZCLEdBQTdCLENBQS9CO0FBQ0FtRCxlQUFPaEUsUUFBUCxDQUFnQjZELEtBQWhCLEdBQXdCLEdBQXhCO0FBQ0F6RCx1QkFBZTRELE9BQU8zRCxlQUFQLEdBQXlCQyxXQUF6QixDQUFxQ0MsTUFBcEQsRUFBNEQsSUFBSUMsT0FBT0MsSUFBWCxDQUFnQnVELE9BQU9qRSxPQUFQLENBQWVSLENBQS9CLEVBQWtDeUUsT0FBT2pFLE9BQVAsQ0FBZWYsQ0FBakQsRUFBb0RnRixPQUFPakUsT0FBUCxDQUFlUCxDQUFuRSxDQUE1RCxFQUFtSSxDQUFuSTtBQUNBLFlBQUl5RSxTQUFTakksUUFBUWtJLFdBQVIsQ0FBb0JwRSxTQUFwQixDQUE4QixPQUE5QixFQUF1QyxDQUF2QyxFQUEwQzNELEtBQTFDLENBQWI7QUFDQThILGVBQU9sRSxPQUFQLENBQWVQLENBQWYsR0FBbUIsR0FBbkI7QUFDQXlFLGVBQU9sRSxPQUFQLENBQWVmLENBQWYsR0FBbUIsR0FBbkI7QUFDQWlGLGVBQU9sRSxPQUFQLENBQWVSLENBQWYsR0FBbUIsRUFBbkI7QUFDQTBFLGVBQU85RyxRQUFQLENBQWdCNkIsQ0FBaEIsR0FBb0JKLEtBQUtvRSxFQUFMLEdBQVEsQ0FBNUI7QUFDQWlCLGVBQU92RixRQUFQLENBQWdCYSxDQUFoQixHQUFvQixDQUFDLEdBQXJCO0FBQ0EwRSxlQUFPdkYsUUFBUCxDQUFnQmMsQ0FBaEIsR0FBb0IsR0FBcEI7QUFDQXlFLGVBQU9qRSxRQUFQLEdBQWtCLElBQUloRSxRQUFRaUUsZ0JBQVosQ0FBNkIsVUFBN0IsRUFBeUM5RCxLQUF6QyxDQUFsQjtBQUNBOEgsZUFBT2pFLFFBQVAsQ0FBZ0JZLFlBQWhCLEdBQStCLElBQUk1RSxRQUFRNkUsTUFBWixDQUFtQixHQUFuQixFQUF3QixHQUF4QixFQUE2QixHQUE3QixDQUEvQjtBQUNBb0QsZUFBT2pFLFFBQVAsQ0FBZ0I2RCxLQUFoQixHQUF3QixHQUF4QjtBQUNBekQsdUJBQWU2RCxPQUFPNUQsZUFBUCxHQUF5QkMsV0FBekIsQ0FBcUNDLE1BQXBELEVBQTRELElBQUlDLE9BQU9DLElBQVgsQ0FBZ0J3RCxPQUFPbEUsT0FBUCxDQUFlUixDQUEvQixFQUFrQzBFLE9BQU9sRSxPQUFQLENBQWVmLENBQWpELEVBQW9EaUYsT0FBT2xFLE9BQVAsQ0FBZVAsQ0FBbkUsQ0FBNUQsRUFBbUksQ0FBbkk7QUFDQSxZQUFJMkUsU0FBU25JLFFBQVFrSSxXQUFSLENBQW9CcEUsU0FBcEIsQ0FBOEIsT0FBOUIsRUFBdUMsQ0FBdkMsRUFBMEMzRCxLQUExQyxDQUFiO0FBQ0FnSSxlQUFPcEUsT0FBUCxDQUFlUCxDQUFmLEdBQW1CLEdBQW5CO0FBQ0EyRSxlQUFPcEUsT0FBUCxDQUFlZixDQUFmLEdBQW1CLEdBQW5CO0FBQ0FtRixlQUFPcEUsT0FBUCxDQUFlUixDQUFmLEdBQW1CLEdBQW5CO0FBQ0E0RSxlQUFPaEgsUUFBUCxDQUFnQjZCLENBQWhCLEdBQW9CSixLQUFLb0UsRUFBTCxHQUFRLENBQTVCO0FBQ0FtQixlQUFPekYsUUFBUCxDQUFnQmEsQ0FBaEIsR0FBb0IsQ0FBQyxHQUFyQjtBQUNBNEUsZUFBT3pGLFFBQVAsQ0FBZ0JjLENBQWhCLEdBQW9CLENBQUMsR0FBckI7QUFDQTJFLGVBQU9uRSxRQUFQLEdBQWtCLElBQUloRSxRQUFRaUUsZ0JBQVosQ0FBNkIsVUFBN0IsRUFBeUM5RCxLQUF6QyxDQUFsQjtBQUNBZ0ksZUFBT25FLFFBQVAsQ0FBZ0JZLFlBQWhCLEdBQStCLElBQUk1RSxRQUFRNkUsTUFBWixDQUFtQixHQUFuQixFQUF3QixHQUF4QixFQUE2QixHQUE3QixDQUEvQjtBQUNBc0QsZUFBT25FLFFBQVAsQ0FBZ0I2RCxLQUFoQixHQUF3QixHQUF4QjtBQUNBekQsdUJBQWUrRCxPQUFPOUQsZUFBUCxHQUF5QkMsV0FBekIsQ0FBcUNDLE1BQXBELEVBQTRELElBQUlDLE9BQU9DLElBQVgsQ0FBZ0IwRCxPQUFPcEUsT0FBUCxDQUFlUixDQUEvQixFQUFrQzRFLE9BQU9wRSxPQUFQLENBQWVmLENBQWpELEVBQW9EbUYsT0FBT3BFLE9BQVAsQ0FBZVAsQ0FBbkUsQ0FBNUQsRUFBbUksQ0FBbkk7O0FBRUEsWUFBSTRFLFNBQVNwSSxRQUFRNkQsSUFBUixDQUFhd0UsWUFBYixDQUEwQixTQUExQixFQUFxQyxJQUFyQyxFQUEyQyxJQUEzQyxFQUFpRCxDQUFqRCxFQUFvRGxJLEtBQXBELENBQWI7QUFDQWlJLGVBQU9wRSxRQUFQLEdBQWtCLElBQUloRSxRQUFRaUUsZ0JBQVosQ0FBNkIsVUFBN0IsRUFBeUM5RCxLQUF6QyxDQUFsQjtBQUNBaUksZUFBT3BFLFFBQVAsQ0FBZ0JFLGVBQWhCLEdBQWtDLElBQUlsRSxRQUFRbUUsT0FBWixDQUFvQix1QkFBcEIsRUFBNkNoRSxLQUE3QyxDQUFsQztBQUNBaUksZUFBT3BFLFFBQVAsQ0FBZ0JFLGVBQWhCLENBQWdDb0UsTUFBaEMsR0FBeUMsS0FBekM7QUFDQUYsZUFBT3BFLFFBQVAsQ0FBZ0JFLGVBQWhCLENBQWdDcUUsTUFBaEMsR0FBeUMsS0FBekM7QUFDQWhLLHNCQUFjLElBQUl5QixRQUFRd0ksS0FBWixDQUFrQixRQUFsQixFQUE0QixzQkFBNUIsRUFBb0RySSxLQUFwRCxDQUFkO0FBQ0E3QixrQkFBVTRCLE9BQU9DLEtBQVAsRUFBYzlCLEtBQWQsQ0FBVjtBQUNBLGVBQU84QixLQUFQO0FBRUQsT0FySkQsQ0ExTW9CLENBK1ZoQjtBQUNKLFVBQUlzSSxjQUFjLFNBQWRBLFdBQWMsR0FBVTtBQUMxQixZQUFJQyxRQUFRLElBQUlsRSxPQUFPbUUsS0FBWCxFQUFaO0FBQ0FELGNBQU1FLE9BQU4sQ0FBY0MsR0FBZCxDQUFrQixDQUFsQixFQUFvQixDQUFDLEVBQXJCLEVBQXdCLENBQXhCO0FBQ0EsWUFBSUMsT0FBTyxDQUFYO0FBQUEsWUFBY0MsU0FBUyxJQUF2QjtBQUNBLFlBQUlDLGNBQWMsSUFBSXhFLE9BQU95RSxNQUFYLENBQWtCRixNQUFsQixDQUFsQixDQUowQixDQUltQjtBQUM3Q2xLLHFCQUFhLElBQUkyRixPQUFPMEUsSUFBWCxDQUFnQixFQUFDSixNQUFNQSxJQUFQLEVBQWFLLE9BQU9ILFdBQXBCLEVBQWhCLENBQWIsQ0FMMEIsQ0FLc0M7QUFDaEVuSyxtQkFBVzZELFFBQVgsQ0FBb0JtRyxHQUFwQixDQUF3QnpKLElBQXhCLEVBQTZCLENBQTdCLEVBQStCQyxJQUEvQjtBQUNBUixtQkFBV3NDLFFBQVgsR0FBc0IsSUFBSXFELE9BQU9DLElBQVgsRUFBdEI7QUFDQTVGLG1CQUFXdUssVUFBWCxDQUFzQkMsZ0JBQXRCLENBQXVDLElBQUk3RSxPQUFPQyxJQUFYLENBQWdCLENBQWhCLEVBQWtCLENBQWxCLEVBQW9CLENBQXBCLENBQXZDLEVBQThELENBQUM3QixLQUFLb0UsRUFBTixHQUFTLENBQXZFO0FBQ0FuSSxtQkFBV3dELGdCQUFYLENBQTRCLFNBQTVCLEVBQXVDLFVBQVNpSCxDQUFULEVBQVc7QUFDL0MsY0FBR0EsRUFBRUMsSUFBRixDQUFPQyxRQUFWLEVBQW1CO0FBQ2pCLGlCQUFLLElBQUlDLENBQVQsSUFBYzFLLE9BQWQsRUFBc0I7QUFDcEIsa0JBQUlBLFFBQVEwSyxDQUFSLE1BQWUxSyxRQUFRdUssRUFBRUMsSUFBRixDQUFPRyxRQUFmLENBQW5CLEVBQTRDO0FBQzFDMUssNkJBQWF5SyxDQUFiLEVBQWdCM0gsT0FBaEI7QUFDQTtBQUNBbkQsZ0NBQWdCOEssQ0FBaEI7QUFDQWxMLDRCQUFZb0wsSUFBWjtBQUNBdEw7QUFDQUMsd0JBQVFxQyxRQUFSLENBQWlCLENBQWpCLEVBQW9CaUosSUFBcEIsR0FBMkJ2TCxNQUFNd0MsUUFBTixFQUEzQjtBQUNEO0FBQ0Y7QUFDRjtBQUNGLFNBYkY7QUFjQTZILGNBQU1tQixHQUFOLENBQVVoTCxVQUFWO0FBQ0EsWUFBSWlMLGFBQWEsSUFBSXRGLE9BQU95RSxNQUFYLENBQWtCLEVBQWxCLENBQWpCLENBeEIwQixDQXdCYztBQUN4QzFKLG9CQUFZLElBQUlpRixPQUFPMEUsSUFBWCxDQUFnQixFQUFDSixNQUFNLENBQVAsRUFBVUssT0FBT1csVUFBakIsRUFBaEIsQ0FBWixDQXpCMEIsQ0F5QmlDO0FBQzNEdkssa0JBQVVtRCxRQUFWLENBQW1CbUcsR0FBbkIsQ0FBdUIsQ0FBQyxHQUF4QixFQUE0QixDQUE1QixFQUE4QixDQUFDLEdBQS9CO0FBQ0F0SixrQkFBVTRCLFFBQVYsR0FBcUIsSUFBSXFELE9BQU9DLElBQVgsRUFBckI7QUFDQWxGLGtCQUFVNkosVUFBVixDQUFxQkMsZ0JBQXJCLENBQXNDLElBQUk3RSxPQUFPQyxJQUFYLENBQWdCLENBQWhCLEVBQWtCLENBQWxCLEVBQW9CLENBQXBCLENBQXRDLEVBQTZELENBQUM3QixLQUFLb0UsRUFBTixHQUFTLENBQXRFO0FBQ0F6SCxrQkFBVThDLGdCQUFWLENBQTJCLFNBQTNCLEVBQXNDLFVBQVNpSCxDQUFULEVBQVc7QUFDaEQxSiwyQkFBaUJnRCxLQUFLbUgsS0FBTCxDQUFXbkgsS0FBS29ILE1BQUwsS0FBZ0IsRUFBM0IsSUFBaUMsRUFBbEQ7QUFDQW5LLDJCQUFpQitDLEtBQUttSCxLQUFMLENBQVduSCxLQUFLb0gsTUFBTCxLQUFnQixFQUEzQixJQUFpQyxFQUFsRDtBQUNDLFNBSEY7QUFJQXRCLGNBQU1tQixHQUFOLENBQVV0SyxTQUFWO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTs7QUFFQTs7QUFFQTtBQUNBOztBQUVBOzs7QUFJRSxZQUFJMEssY0FBYyxJQUFJekYsT0FBTzBGLEtBQVgsRUFBbEI7QUFDQSxZQUFJQyxhQUFhLElBQUkzRixPQUFPMEUsSUFBWCxDQUFnQixFQUFFSixNQUFNLENBQVIsRUFBV0ssT0FBT2MsV0FBbEIsRUFBaEIsQ0FBakI7QUFDQXZCLGNBQU1tQixHQUFOLENBQVVNLFVBQVY7QUFDQUEsbUJBQVdmLFVBQVgsQ0FBc0JDLGdCQUF0QixDQUF1QyxJQUFJN0UsT0FBT0MsSUFBWCxDQUFnQixDQUFoQixFQUFrQixDQUFsQixFQUFvQixDQUFwQixDQUF2QyxFQUE4RCxDQUFDN0IsS0FBS29FLEVBQU4sR0FBUyxDQUF2RTs7QUFFSixlQUFPMEIsS0FBUDtBQUNELE9BMURDOztBQTRERSxVQUFJdEUsaUJBQWlCLFNBQWpCQSxjQUFpQixDQUFTMUIsUUFBVCxFQUFtQm5DLElBQW5CLEVBQXlCNkosSUFBekIsRUFBOEI7QUFDakQsWUFBSUMsV0FBVyxJQUFJN0YsT0FBTzhGLEdBQVgsQ0FBZS9KLElBQWYsQ0FBZjtBQUNBLFlBQUlnSyxVQUFVLElBQUkvRixPQUFPMEUsSUFBWCxDQUFnQixFQUFDQyxPQUFPa0IsUUFBUixFQUFrQnZCLE1BQUssQ0FBdkIsRUFBaEIsQ0FBZDtBQUNBeUIsZ0JBQVE3SCxRQUFSLEdBQW1CQSxRQUFuQjtBQUNBLFlBQUcwSCxTQUFTLENBQVosRUFBZTtBQUNiRyxrQkFBUW5CLFVBQVIsQ0FBbUJDLGdCQUFuQixDQUFvQyxJQUFJN0UsT0FBT0MsSUFBWCxDQUFnQixDQUFoQixFQUFrQixDQUFsQixFQUFvQixDQUFwQixDQUFwQyxFQUEyRCxDQUFDN0IsS0FBS29FLEVBQU4sR0FBUyxDQUFwRTtBQUNELFNBRkQsTUFFTyxJQUFHb0QsU0FBUyxDQUFaLEVBQWU7QUFDcEJHLGtCQUFRbkIsVUFBUixDQUFtQkMsZ0JBQW5CLENBQW9DLElBQUk3RSxPQUFPQyxJQUFYLENBQWdCLENBQWhCLEVBQWtCLENBQWxCLEVBQW9CLENBQXBCLENBQXBDLEVBQTJEN0IsS0FBS29FLEVBQUwsR0FBUSxDQUFuRTtBQUNEO0FBQ0QwQixjQUFNbUIsR0FBTixDQUFVVSxPQUFWO0FBQ0EsT0FWRjs7QUFZQSxVQUFJeEYsbUJBQW1CLFNBQW5CQSxnQkFBbUIsQ0FBU3JDLFFBQVQsRUFBbUJxRyxNQUFuQixFQUEyQnpJLEVBQTNCLEVBQThCO0FBQ25ELFlBQUlrSyxjQUFjLElBQUloRyxPQUFPeUUsTUFBWCxDQUFrQkYsTUFBbEIsQ0FBbEI7QUFDQSxZQUFJMEIsYUFBYSxJQUFJakcsT0FBTzBFLElBQVgsQ0FBZ0IsRUFBQ0osTUFBTSxDQUFQLEVBQVVLLE9BQU9xQixXQUFqQixFQUFoQixDQUFqQjtBQUNBQyxtQkFBVy9ILFFBQVgsR0FBc0JBLFFBQXRCO0FBQ0ErSCxtQkFBV2pCLFFBQVgsR0FBc0IsSUFBdEI7QUFDQWlCLG1CQUFXQyxpQkFBWCxHQUErQixDQUEvQjtBQUNBRCxtQkFBV2YsUUFBWCxHQUFzQnBKLEVBQXRCO0FBQ0F2QixnQkFBUXVCLEVBQVIsSUFBY21LLFVBQWQ7QUFDQS9CLGNBQU1tQixHQUFOLENBQVVZLFVBQVY7QUFDQSxPQVRGOztBQVlBLFVBQUkvQixRQUFRRCxhQUFaO0FBQ0EsVUFBSXRJLFFBQVE4RSxhQUFaOztBQUVBLFVBQUdoRyxVQUFILEVBQWU7QUFDYkMsZUFBT3lELFdBQVdDLEtBQUtDLEdBQUwsQ0FBUy9ELE9BQU9nRSxrQkFBUCxDQUEwQkMsYUFBMUIsR0FBMENDLENBQW5ELENBQVgsQ0FBUDtBQUNBN0QsZUFBT3dELFdBQVdDLEtBQUtLLEdBQUwsQ0FBU25FLE9BQU9nRSxrQkFBUCxDQUEwQkMsYUFBMUIsR0FBMENDLENBQW5ELENBQVgsQ0FBUDtBQUNELE9BSEQsTUFHTztBQUNMOUQsZUFBT3lELFdBQVdDLEtBQUtDLEdBQUwsQ0FBUy9ELE9BQU9xQyxRQUFQLENBQWdCNkIsQ0FBekIsQ0FBWCxDQUFQO0FBQ0E3RCxlQUFPd0QsV0FBV0MsS0FBS0ssR0FBTCxDQUFTbkUsT0FBT3FDLFFBQVAsQ0FBZ0I2QixDQUF6QixDQUFYLENBQVA7QUFDRDs7QUFFRGpELGFBQU80SyxhQUFQLENBQXFCLFlBQVk7QUFDL0I7QUFDQSxZQUFHaE0sa0JBQWtCLENBQXJCLEVBQXdCO0FBQ3RCK0osZ0JBQU1rQyxNQUFOLENBQWE3TCxRQUFRSixhQUFSLENBQWI7QUFDQUEsMEJBQWdCLENBQWhCO0FBQ0Q7QUFDRHdCLGNBQU0wSyxNQUFOO0FBQ0FuQyxjQUFNb0MsSUFBTixDQUFXLE1BQUksSUFBZjtBQUNBLFlBQUk3TCxjQUFjSCxPQUFPZ0Usa0JBQVAsS0FBNkJjLFNBQS9DLEVBQTBEO0FBQ3hELGNBQUkxRSxTQUFTeUQsV0FBV0MsS0FBS0MsR0FBTCxDQUFTL0QsT0FBT2dFLGtCQUFQLENBQTBCRSxDQUFuQyxDQUFYLENBQVQsSUFBOEQ3RCxTQUFTd0QsV0FBV0MsS0FBS0ssR0FBTCxDQUFTbkUsT0FBT2dFLGtCQUFQLENBQTBCRSxDQUFuQyxDQUFYLENBQTNFLEVBQThIO0FBQzVIOUQsbUJBQU95RCxXQUFXQyxLQUFLQyxHQUFMLENBQVMvRCxPQUFPZ0Usa0JBQVAsQ0FBMEJDLGFBQTFCLEdBQTBDQyxDQUFuRCxDQUFYLENBQVA7QUFDQTdELG1CQUFPd0QsV0FBV0MsS0FBS0ssR0FBTCxDQUFTbkUsT0FBT2dFLGtCQUFQLENBQTBCQyxhQUExQixHQUEwQ0MsQ0FBbkQsQ0FBWCxDQUFQO0FBQ0FuRSx1QkFBV2lCLFFBQVgsQ0FBb0IwRCxDQUFwQixHQUF3QnRFLE9BQU0sRUFBOUI7QUFDQUwsdUJBQVdpQixRQUFYLENBQW9CeUQsQ0FBcEIsR0FBd0JwRSxPQUFNLEVBQTlCO0FBQ0Q7QUFDRixTQVBELE1BT087QUFDSEQsaUJBQU95RCxXQUFXQyxLQUFLQyxHQUFMLENBQVMvRCxPQUFPcUMsUUFBUCxDQUFnQjZCLENBQXpCLENBQVgsQ0FBUDtBQUNBN0QsaUJBQU93RCxXQUFXQyxLQUFLSyxHQUFMLENBQVNuRSxPQUFPcUMsUUFBUCxDQUFnQjZCLENBQXpCLENBQVgsQ0FBUDtBQUNBbkUscUJBQVdpQixRQUFYLENBQW9CMEQsQ0FBcEIsR0FBd0J0RSxPQUFNLEVBQTlCO0FBQ0FMLHFCQUFXaUIsUUFBWCxDQUFvQnlELENBQXBCLEdBQXdCcEUsT0FBTSxFQUE5QjtBQUNIOztBQUVEVCxhQUFLZ0UsUUFBTCxDQUFjYSxDQUFkLEdBQWtCMUUsV0FBVzZELFFBQVgsQ0FBb0JhLENBQXRDO0FBQ0E3RSxhQUFLZ0UsUUFBTCxDQUFjTSxDQUFkLEdBQWtCbkUsV0FBVzZELFFBQVgsQ0FBb0JNLENBQXRDO0FBQ0F0RSxhQUFLZ0UsUUFBTCxDQUFjYyxDQUFkLEdBQWtCM0UsV0FBVzZELFFBQVgsQ0FBb0JjLENBQXRDOztBQUVBMUUsZUFBTzRELFFBQVAsQ0FBZ0JhLENBQWhCLEdBQW9CMUUsV0FBVzZELFFBQVgsQ0FBb0JhLENBQXBCLEdBQXdCLEVBQTVDO0FBQ0F6RSxlQUFPNEQsUUFBUCxDQUFnQk0sQ0FBaEIsR0FBb0JuRSxXQUFXNkQsUUFBWCxDQUFvQk0sQ0FBeEM7QUFDQWxFLGVBQU80RCxRQUFQLENBQWdCYyxDQUFoQixHQUFvQjNFLFdBQVc2RCxRQUFYLENBQW9CYyxDQUF4QztBQUNBO0FBQ0E7QUFDQSxZQUFHekYsSUFBSXVCLEtBQUosS0FBY3NFLFNBQWpCLEVBQTRCO0FBQzFCN0YsY0FBSXVCLEtBQUosQ0FBVW9ELFFBQVYsQ0FBbUJhLENBQW5CLEdBQXVCaEUsVUFBVW1ELFFBQVYsQ0FBbUJhLENBQTFDO0FBQ0F4RixjQUFJdUIsS0FBSixDQUFVb0QsUUFBVixDQUFtQk0sQ0FBbkIsR0FBdUJ6RCxVQUFVbUQsUUFBVixDQUFtQk0sQ0FBbkIsR0FBdUIsRUFBOUM7QUFDQWpGLGNBQUl1QixLQUFKLENBQVVvRCxRQUFWLENBQW1CYyxDQUFuQixHQUF1QmpFLFVBQVVtRCxRQUFWLENBQW1CYyxDQUExQztBQUNBakUsb0JBQVVPLFFBQVYsQ0FBbUIwRCxDQUFuQixHQUF1QjVELGNBQXZCO0FBQ0FMLG9CQUFVTyxRQUFWLENBQW1CeUQsQ0FBbkIsR0FBdUIxRCxjQUF2QjtBQUNEO0FBQ0RqQix3QkFBZ0JDLFdBQVdpQixRQUEzQjtBQUNFLFlBQUlpTCxRQUFRLElBQUl2RyxPQUFPd0csVUFBWCxFQUFaO0FBQ0EsWUFBSUMsUUFBUSxJQUFJekcsT0FBT3dHLFVBQVgsRUFBWjtBQUNBRCxjQUFNMUIsZ0JBQU4sQ0FBdUIsSUFBSTdFLE9BQU9DLElBQVgsQ0FBZ0IsQ0FBaEIsRUFBa0IsQ0FBbEIsRUFBb0IsQ0FBcEIsQ0FBdkIsRUFBK0NqRyxNQUEvQztBQUNBeU0sY0FBTTVCLGdCQUFOLENBQXVCLElBQUk3RSxPQUFPQyxJQUFYLENBQWdCLENBQWhCLEVBQWtCLENBQWxCLEVBQW9CLENBQXBCLENBQXZCLEVBQStDaEcsTUFBL0M7QUFDQSxZQUFJMkssYUFBYTZCLE1BQU1DLElBQU4sQ0FBV0gsS0FBWCxDQUFqQjtBQUNBM0IsbUJBQVcrQixTQUFYOztBQUlBLFlBQUlDLGtCQUFrQmhDLFdBQVdpQyxLQUFYLENBQWlCek0sYUFBakIsQ0FBdEI7QUFDQUMsbUJBQVdpQixRQUFYLEdBQXNCc0wsZUFBdEI7QUFFSCxPQW5ERDtBQW9EQTlJLGFBQU9ELGdCQUFQLENBQXdCLFFBQXhCLEVBQWtDLFlBQVk7QUFDNUN0QyxlQUFPdUwsTUFBUDtBQUNELE9BRkQ7QUFHRDs7OzZCQUlRO0FBQ1AsYUFDUTtBQUFBO0FBQUEsVUFBSyxXQUFVLGtCQUFmO0FBQ0Esd0NBQVEsSUFBRyxjQUFYLEdBREE7QUFFQTtBQUFBO0FBQUEsWUFBSyxXQUFVLGVBQWY7QUFBQTtBQUFBO0FBRkEsT0FEUjtBQUtEOzs7O0VBcmdCc0JDLE1BQU1DLFM7O0FBd2dCL0JsSixPQUFPekUsVUFBUCxHQUFvQkEsVUFBcEIiLCJmaWxlIjoibWF6ZVJ1bm5lci5qcyIsInNvdXJjZXNDb250ZW50IjpbImNsYXNzIE1hemVSdW5uZXIgZXh0ZW5kcyBSZWFjdC5Db21wb25lbnQge1xyXG4gIGNvbnN0cnVjdG9yKHByb3BzKXtcclxuICAgIHN1cGVyKHByb3BzKTtcclxuICB9XHJcblxyXG4gIGNvbXBvbmVudERpZE1vdW50KCkge1xyXG4gICAgXHJcbiAgLy8gR2V0IHRoZSBjYW52YXMgZWxlbWVudCBmcm9tIG91ciBIVE1MIGFib3ZlXHJcbiAgICAvLyB3aW5kb3cuYWRkRXZlbnRMaXN0ZW5lcihcImxvYWRcIixmdW5jdGlvbigpIHtcclxuICAgIC8vICAgICBzZXRUaW1lb3V0KGZ1bmN0aW9uKCl7XHJcbiAgICAvLyAgICAgICAgIC8vIFRoaXMgaGlkZXMgdGhlIGFkZHJlc3MgYmFyOlxyXG4gICAgLy8gICAgICAgICB3aW5kb3cuc2Nyb2xsVG8oMCwgMSk7XHJcbiAgICAvLyAgICAgfSwgMCk7XHJcbiAgICAvLyB9KTtcclxuICAgIHZhciBvYmo9IHt9O1xyXG4gICAgdmFyIGNoZWNrT2JqO1xyXG4gICAgdmFyIHRoYXQgPSB0aGlzO1xyXG4gICAgdmFyIGNhbnZhcyA9IGRvY3VtZW50LmdldEVsZW1lbnRCeUlkKFwicmVuZGVyQ2FudmFzXCIpO1xyXG4gICAgdmFyIHNjb3JlID0gMDtcclxuICAgIHZhciBjYW52YXMyO1xyXG4gICAgdmFyIHBlbGxldFNvdW5kO1xyXG4gICAgdmFyIGFuZ2xlWCA9IDA7XHJcbiAgICB2YXIgYW5nbGVZID0gMDtcclxuICAgIHZhciBiYWxsO1xyXG4gICAgdmFyIHBlbGxldFJlbW92ZXIgPSAwO1xyXG4gICAgdmFyIGlucHV0VmVsb2NpdHk7XHJcbiAgICB2YXIgc3BoZXJlQm9keTtcclxuICAgIHZhciBjYW1lcmE7XHJcbiAgICB2YXIgcGVsbGV0cyA9IFtdO1xyXG4gICAgdmFyIHBlbGxldE1lc2hlcyA9IFtdO1xyXG4gICAgdmFyIGNhbWVyYUZsYWcgPSBmYWxzZTtcclxuICAgIHZhciBjYW0xLCBjYW0yO1xyXG4gICAgdmFyIHBvc3ggPSAtMjUwO1xyXG4gICAgdmFyIHBvc3ogPSAtMTUwO1xyXG4gICAgdmFyIGdob3N0LCBnaG9zdEJvZHk7XHJcbiAgICB2YXIgd2FsbCwgcGVsbGV0O1xyXG4gICAgdmFyIG5ld0luc3RhbmNlV2FsbCwgbmV3SW5zdGFuY2VTcGhlcmU7XHJcbiAgICB2YXIgZ2hvc3R4dmVsb2NpdHkgPSAwO1xyXG4gICAgdmFyIGdob3N0enZlbG9jaXR5ID0gMjU7XHJcbiAgICB2YXIgdmVsb2NpdHk7XHJcbiAgICAvLyBMb2FkIHRoZSBCQUJZTE9OIDNEIGVuZ2luZVxyXG4gICAgdmFyIGVuZ2luZSA9IG5ldyBCQUJZTE9OLkVuZ2luZShjYW52YXMsIHRydWUpO1xyXG4gICAgIC8vIFRoaXMgYmVnaW5zIHRoZSBjcmVhdGlvbiBvZiBhIGZ1bmN0aW9uIHRoYXQgd2Ugd2lsbCAnY2FsbCcganVzdCBhZnRlciBpdCdzIGJ1aWx0XHJcbiAgICB2YXIgY3JlYXRlID0gZnVuY3Rpb24gKHNjZW5lLCBzdHJpbmcpIHtcclxuICAgICAgdmFyIGNhbnZhcyA9IG5ldyBCQUJZTE9OLlNjcmVlblNwYWNlQ2FudmFzMkQoc2NlbmUsIHtcclxuICAgICAgICBpZDogXCJTY3JlZW5DYW52YXNcIixcclxuICAgICAgICBzaXplOiBuZXcgQkFCWUxPTi5TaXplKDMwMCwgMTAwKSxcclxuICAgICAgICBiYWNrZ3JvdW5kRmlsbDogXCIjNDA0MDQwOEZcIixcclxuICAgICAgICBiYWNrZ3JvdW5kUm91bmRSYWRpdXM6IDUwLFxyXG4gICAgICAgIGNoaWxkcmVuOiBbXHJcbiAgICAgICAgICBuZXcgQkFCWUxPTi5UZXh0MkQoc2NvcmUudG9TdHJpbmcoKSwge1xyXG4gICAgICAgICAgICBpZDogXCJ0ZXh0XCIsXHJcbiAgICAgICAgICAgIG1hcmdpbkFsaWdubWVudDogXCJoOiBjZW50ZXIsIHY6Y2VudGVyXCIsXHJcbiAgICAgICAgICAgIGZvbnROYW1lOiBcIjIwcHQgQXJpYWxcIixcclxuICAgICAgICAgIH0pXHJcbiAgICAgICAgXVxyXG4gICAgICB9KTtcclxuICAgICAgcmV0dXJuIGNhbnZhcztcclxuICAgIH07XHJcbiAgICB2YXIgc3dpdGNoQ2FtZXJhID0gZnVuY3Rpb24gKGNhbSkge1xyXG4gICAgICAgIGlmIChzY2VuZS5hY3RpdmVDYW1lcmFzWzBdLnJvdGF0aW9uKSB7XHJcbiAgICAgICAgICAgIGNhbS5yb3RhdGlvbiA9IHNjZW5lLmFjdGl2ZUNhbWVyYXNbMF0ucm90YXRpb24uY2xvbmUoKTtcclxuICAgICAgICB9XHJcbiAgICAgICAgY2FtLmZvdiA9IHNjZW5lLmFjdGl2ZUNhbWVyYXNbMF0uZm92O1xyXG4gICAgICAgIGNhbS5taW5aID0gc2NlbmUuYWN0aXZlQ2FtZXJhc1swXS5taW5aO1xyXG4gICAgICAgIGNhbS5tYXhaID0gc2NlbmUuYWN0aXZlQ2FtZXJhc1swXS5tYXhaO1xyXG5cclxuICAgICAgICBpZiAoc2NlbmUuYWN0aXZlQ2FtZXJhc1swXS5lbGxpcHNvaWQpIHtcclxuICAgICAgICAgICAgY2FtLmVsbGlwc29pZCA9IHNjZW5lLmFjdGl2ZUNhbWVyYXNbMF0uZWxsaXBzb2lkLmNsb25lKCk7XHJcbiAgICAgICAgfVxyXG4gICAgICAgIGNhbS5jaGVja0NvbGxpc2lvbnMgPSBzY2VuZS5hY3RpdmVDYW1lcmFzWzBdLmNoZWNrQ29sbGlzaW9ucztcclxuICAgICAgICBjYW0uYXBwbHlHcmF2aXR5ID0gc2NlbmUuYWN0aXZlQ2FtZXJhc1swXS5hcHBseUdyYXZpdHk7XHJcblxyXG4gICAgICAgIGNhbS5zcGVlZCA9IHNjZW5lLmFjdGl2ZUNhbWVyYXNbMF0uc3BlZWQ7XHJcblxyXG4gICAgICAgIGNhbS5wb3N0UHJvY2Vzc2VzID0gc2NlbmUuYWN0aXZlQ2FtZXJhc1swXS5wb3N0UHJvY2Vzc2VzO1xyXG4gICAgICAgIHNjZW5lLmFjdGl2ZUNhbWVyYXNbMF0ucG9zdFByb2Nlc3NlcyA9IFtdO1xyXG4gICAgICAgIHNjZW5lLmFjdGl2ZUNhbWVyYXNbMF0uZGV0YWNoQ29udHJvbChjYW52YXMpO1xyXG4gICAgICAgIGlmIChzY2VuZS5hY3RpdmVDYW1lcmFzWzBdLmRpc3Bvc2UpIHtcclxuICAgICAgICAgIHNjZW5lLmFjdGl2ZUNhbWVyYXNbMF0uZGlzcG9zZSgpO1xyXG4gICAgICAgIH1cclxuICAgICAgICB2YXIgY29vbCA9IHNjZW5lLmFjdGl2ZUNhbWVyYXMucG9wKCk7XHJcbiAgICAgICAgc2NlbmUuYWN0aXZlQ2FtZXJhcy5wb3AoKTtcclxuICAgICAgICBzY2VuZS5hY3RpdmVDYW1lcmFzLnB1c2goY2FtZXJhKTtcclxuICAgICAgICBzY2VuZS5hY3RpdmVDYW1lcmFzLnB1c2goY29vbCk7XHJcblxyXG5cclxuICAgICAgICBzY2VuZS5hY3RpdmVDYW1lcmFzWzBdLmF0dGFjaENvbnRyb2woY2FudmFzKTtcclxuICAgICAgICBjYW1lcmFGbGFnID0gIWNhbWVyYUZsYWc7XHJcblxyXG4gICAgfTtcclxuICAgIHZhciBjMiA9IGRvY3VtZW50LmdldEVsZW1lbnRzQnlDbGFzc05hbWUoXCJjYW1lcmEtdG9nZ2xlXCIpWzBdO1xyXG4gICAgYzIuYWRkRXZlbnRMaXN0ZW5lcihcImNsaWNrXCIsIGZ1bmN0aW9uICgpIHtcclxuICAgICAgLy9jb25zb2xlLmxvZyhzY2VuZS5hY3RpdmVDYW1lcmFzWzBdIGluc3RhbmNlb2YgQkFCWUxPTi5WUkRldmljZU9yaWVudGF0aW9uRnJlZUNhbWVyYSk7XHJcbiAgICAgIHdpbmRvdy5zY3JvbGxUbygwLDEpO1xyXG4gICAgICBpZiAoc2NlbmUuYWN0aXZlQ2FtZXJhc1swXSBpbnN0YW5jZW9mIEJBQllMT04uRnJlZUNhbWVyYSAmJiAhKHNjZW5lLmFjdGl2ZUNhbWVyYXNbMF0gaW5zdGFuY2VvZiBCQUJZTE9OLlZSRGV2aWNlT3JpZW50YXRpb25GcmVlQ2FtZXJhKSkge1xyXG4gICAgICAgIGNhbWVyYSA9IG5ldyBCQUJZTE9OLlZSRGV2aWNlT3JpZW50YXRpb25GcmVlQ2FtZXJhKFwiZGV2aWNlT3JpZW50YXRpb25DYW1lcmFcIiwgc2NlbmUuYWN0aXZlQ2FtZXJhc1swXS5wb3NpdGlvbiwgc2NlbmUpO1xyXG4gICAgICAgIHN3aXRjaENhbWVyYShjYW1lcmEpO1xyXG4gICAgICAgIGNhbTEgPSBwYXJzZUZsb2F0KE1hdGguY29zKGNhbWVyYS5yb3RhdGlvblF1YXRlcm5pb24udG9FdWxlckFuZ2xlcygpLnkpKTtcclxuICAgICAgICBjYW0yID0gcGFyc2VGbG9hdChNYXRoLnNpbihjYW1lcmEucm90YXRpb25RdWF0ZXJuaW9uLnRvRXVsZXJBbmdsZXMoKS55KSk7XHJcbiAgICAgIH0gZWxzZSB7XHJcbiAgICAgICAgLy9jb25zb2xlLmxvZygneWVzJyk7XHJcbiAgICAgICAgY2FtZXJhID0gbmV3IEJBQllMT04uRnJlZUNhbWVyYShcImZyZWVlQ2FtZXJhXCIsIHNjZW5lLmFjdGl2ZUNhbWVyYXNbMF0ucG9zaXRpb24sIHNjZW5lKTtcclxuICAgICAgICBzd2l0Y2hDYW1lcmEoY2FtZXJhKTtcclxuICAgICAgfVxyXG4gICAgICByZXR1cm47XHJcbiAgICAgIH0pO1xyXG4gIHZhciBtYXplbWFrZXIgPSBmdW5jdGlvbihhcnIsIHNjZW5lLCBwbGFuZSwgY2FtZXJhLCBiYWxsLCB3YWxscykge1xyXG4gICAgdmFyIGJveGVzID0gW107XHJcblxyXG4gICAgdmFyIHggPSAtMzg3O1xyXG4gICAgdmFyIHogPSAxODc7XHJcbiAgICBmb3IgKHZhciBpID0gMDsgaSA8IGFyci5sZW5ndGg7IGkrKykge1xyXG4gICAgICBmb3IgKHZhciBqID0gMDsgaiA8IGFycltpXS5sZW5ndGg7IGorKykge1xyXG4gICAgICAgIGlmIChhcnJbaV1bal0gPT09IDEpIHtcclxuICAgICAgICAgIGlmICh3YWxsID09PSB1bmRlZmluZWQpIHtcclxuICAgICAgICAgICAgd2FsbCA9IEJBQllMT04uTWVzaC5DcmVhdGVCb3goXCJwbGFuZVwiLCAyLCBzY2VuZSk7XHJcbiAgICAgICAgICAgIHdhbGwuc2NhbGluZy54ID0gMTIuNTtcclxuICAgICAgICAgICAgd2FsbC5zY2FsaW5nLnkgPSAxMDA7XHJcbiAgICAgICAgICAgIHdhbGwuc2NhbGluZy56ID0gMTIuNTtcclxuICAgICAgICAgICAgd2FsbC5tYXRlcmlhbCA9IG5ldyBCQUJZTE9OLlN0YW5kYXJkTWF0ZXJpYWwoXCJ0ZXh0dXJlMVwiLCBzY2VuZSk7XHJcbiAgICAgICAgICAgIHdhbGwubWF0ZXJpYWwuZW1pc3NpdmVUZXh0dXJlID0gbmV3IEJBQllMT04uVGV4dHVyZSgnLi4vYXNzZXRzL3Ryb24xLmpwZycsIHNjZW5lKTtcclxuICAgICAgICAgICAgY3JlYXRlV2FsbEJvZHkod2FsbC5nZXRCb3VuZGluZ0luZm8oKS5ib3VuZGluZ0JveC5jZW50ZXIsIG5ldyBDQU5OT04uVmVjMyh3YWxsLnNjYWxpbmcueCwgd2FsbC5zY2FsaW5nLnksIHdhbGwuc2NhbGluZy56KSwgMCk7XHJcbiAgICAgICAgICB9IGVsc2Uge1xyXG4gICAgICAgICAgICBuZXdJbnN0YW5jZVdhbGwgPSB3YWxsLmNyZWF0ZUluc3RhbmNlKFwiaVwiICsgKGkgKjE2KSArIGopO1xyXG4gICAgICAgICAgICBuZXdJbnN0YW5jZVdhbGwucG9zaXRpb24ueiA9IHo7IFxyXG4gICAgICAgICAgICBuZXdJbnN0YW5jZVdhbGwucG9zaXRpb24ueCA9IHg7IFxyXG4gICAgICAgICAgICBjcmVhdGVXYWxsQm9keShuZXdJbnN0YW5jZVdhbGwuZ2V0Qm91bmRpbmdJbmZvKCkuYm91bmRpbmdCb3guY2VudGVyLCBuZXcgQ0FOTk9OLlZlYzMod2FsbC5zY2FsaW5nLngsIHdhbGwuc2NhbGluZy55LCB3YWxsLnNjYWxpbmcueiksIDApO1xyXG4gICAgICAgICAgfVxyXG4gICAgICAgICAgd2FsbHMucHVzaCh3YWxsKTtcclxuICAgICAgICB9IGVsc2UgaWYgKGFycltpXVtqXSA9PT0gMikge1xyXG4gICAgICAgICAgaWYocGVsbGV0ID09PSB1bmRlZmluZWQpIHtcclxuICAgICAgICAgICAgcGVsbGV0ID0gQkFCWUxPTi5NZXNoLkNyZWF0ZVNwaGVyZShcInNwaGVyZVwiLCAyMC4wLCA0LjAsIHNjZW5lKTtcclxuICAgICAgICAgICAgcGVsbGV0LnBvc2l0aW9uLnogPSB6O1xyXG4gICAgICAgICAgICBwZWxsZXQucG9zaXRpb24ueCA9IHg7IFxyXG4gICAgICAgICAgICBwZWxsZXQucG9zaXRpb24ueSA9IDI7IFxyXG4gICAgICAgICAgICBwZWxsZXQubWF0ZXJpYWwgPSBuZXcgQkFCWUxPTi5TdGFuZGFyZE1hdGVyaWFsKFwid293XCIsIHNjZW5lKTtcclxuICAgICAgICAgICAgcGVsbGV0Lm1hdGVyaWFsLmRpZmZ1c2VDb2xvciA9IG5ldyBCQUJZTE9OLkNvbG9yMygwLCAwLjIsIDAuNyk7XHJcbiAgICAgICAgICAgIHBlbGxldC5tYXRlcmlhbC5lbWlzc2l2ZUNvbG9yID0gbmV3IEJBQllMT04uQ29sb3IzKDAsIC4yLCAuNyk7XHJcbiAgICAgICAgICAgIHZhciBzcGhlcmVCb2R5ID0gY3JlYXRlU3BoZXJlQm9keShwZWxsZXQuZ2V0Qm91bmRpbmdJbmZvKCkuYm91bmRpbmdCb3guY2VudGVyLCA0LCBwZWxsZXQudW5pcXVlSWQpO1xyXG4gICAgICAgICAgICBwZWxsZXRNZXNoZXNbcGVsbGV0LnVuaXF1ZUlkXSA9IHBlbGxldDtcclxuICAgICAgICAgIH0gZWxzZSB7XHJcbiAgICAgICAgICAgIG5ld0luc3RhbmNlU3BoZXJlID0gcGVsbGV0LmNyZWF0ZUluc3RhbmNlKFwiaVwiICsgKGkgKjE2KSArIGopO1xyXG4gICAgICAgICAgICBuZXdJbnN0YW5jZVNwaGVyZS5wb3NpdGlvbi56ID0gejsgXHJcbiAgICAgICAgICAgIG5ld0luc3RhbmNlU3BoZXJlLnBvc2l0aW9uLnggPSB4OyBcclxuICAgICAgICAgICAgdmFyIHNwaGVyZUJvZHkgPSBjcmVhdGVTcGhlcmVCb2R5KG5ld0luc3RhbmNlU3BoZXJlLmdldEJvdW5kaW5nSW5mbygpLmJvdW5kaW5nQm94LmNlbnRlciwgNCwgbmV3SW5zdGFuY2VTcGhlcmUudW5pcXVlSWQpO1xyXG4gICAgICAgICAgICBwZWxsZXRNZXNoZXNbbmV3SW5zdGFuY2VTcGhlcmUudW5pcXVlSWRdID0gbmV3SW5zdGFuY2VTcGhlcmU7XHJcbiAgICAgICAgICB9XHJcbiAgICAgICAgICAvLyB2YXIgcGFydGljbGVTeXN0ZW0gPSBuZXcgQkFCWUxPTi5QYXJ0aWNsZVN5c3RlbShcInBhcnRpY2xlc1wiLCAyMDAwLCBzY2VuZSk7XHJcblxyXG4gICAgICAgICAgLy8gLy9UZXh0dXJlIG9mIGVhY2ggcGFydGljbGVcclxuICAgICAgICAgIC8vIHBhcnRpY2xlU3lzdGVtLnBhcnRpY2xlVGV4dHVyZSA9IG5ldyBCQUJZTE9OLlRleHR1cmUoXCIuL2ZsYXJlLnBuZ1wiLCBzY2VuZSk7XHJcblxyXG4gICAgICAgICAgLy8gLy8gV2hlcmUgdGhlIHBhcnRpY2xlcyBjb21lIGZyb21cclxuICAgICAgICAgIC8vIHBhcnRpY2xlU3lzdGVtLmVtaXR0ZXIgPSBzcGhlcmU7IC8vIHRoZSBzdGFydGluZyBvYmplY3QsIHRoZSBlbWl0dGVyXHJcblxyXG4gICAgICAgICAgLy8gLy8gQ29sb3JzIG9mIGFsbCBwYXJ0aWNsZXNcclxuICAgICAgICAgIC8vIHBhcnRpY2xlU3lzdGVtLmNvbG9yMSA9IG5ldyBCQUJZTE9OLkNvbG9yNCgwLjcsIDAuOCwgMS4wLCAxLjApO1xyXG4gICAgICAgICAgLy8gcGFydGljbGVTeXN0ZW0uY29sb3IyID0gbmV3IEJBQllMT04uQ29sb3I0KDAuMiwgMC41LCAxLjAsIDEuMCk7XHJcbiAgICAgICAgICAvLyBwYXJ0aWNsZVN5c3RlbS5jb2xvckRlYWQgPSBuZXcgQkFCWUxPTi5Db2xvcjQoMCwgMCwgMC4yLCAwLjApO1xyXG5cclxuICAgICAgICAgIC8vIC8vIFNpemUgb2YgZWFjaCBwYXJ0aWNsZSAocmFuZG9tIGJldHdlZW4uLi5cclxuICAgICAgICAgIC8vIHBhcnRpY2xlU3lzdGVtLm1pblNpemUgPSAwLjE7XHJcbiAgICAgICAgICAvLyBwYXJ0aWNsZVN5c3RlbS5tYXhTaXplID0gMC41O1xyXG5cclxuICAgICAgICAgIC8vIC8vIExpZmUgdGltZSBvZiBlYWNoIHBhcnRpY2xlIChyYW5kb20gYmV0d2Vlbi4uLlxyXG4gICAgICAgICAgLy8gcGFydGljbGVTeXN0ZW0ubWluTGlmZVRpbWUgPSAwLjM7XHJcbiAgICAgICAgICAvLyBwYXJ0aWNsZVN5c3RlbS5tYXhMaWZlVGltZSA9IDEuNTtcclxuXHJcbiAgICAgICAgICAvLyAvLyBFbWlzc2lvbiByYXRlXHJcbiAgICAgICAgICAvLyBwYXJ0aWNsZVN5c3RlbS5lbWl0UmF0ZSA9IDE1MDA7XHJcblxyXG4gICAgICAgICAgLy8gLy8gQmxlbmQgbW9kZSA6IEJMRU5ETU9ERV9PTkVPTkUsIG9yIEJMRU5ETU9ERV9TVEFOREFSRFxyXG4gICAgICAgICAgLy8gcGFydGljbGVTeXN0ZW0uYmxlbmRNb2RlID0gQkFCWUxPTi5QYXJ0aWNsZVN5c3RlbS5CTEVORE1PREVfT05FT05FO1xyXG5cclxuICAgICAgICAgIC8vIC8vIFNldCB0aGUgZ3Jhdml0eSBvZiBhbGwgcGFydGljbGVzXHJcbiAgICAgICAgICAvLyBwYXJ0aWNsZVN5c3RlbS5ncmF2aXR5ID0gbmV3IEJBQllMT04uVmVjdG9yMygwLCAtOS44MSwgMCk7XHJcblxyXG4gICAgICAgICAgLy8gLy8gRGlyZWN0aW9uIG9mIGVhY2ggcGFydGljbGUgYWZ0ZXIgaXQgaGFzIGJlZW4gZW1pdHRlZFxyXG4gICAgICAgICAgLy8gcGFydGljbGVTeXN0ZW0uZGlyZWN0aW9uMSA9IG5ldyBCQUJZTE9OLlZlY3RvcjMoLTcsIC04LCAzKTtcclxuICAgICAgICAgIC8vIHBhcnRpY2xlU3lzdGVtLmRpcmVjdGlvbjIgPSBuZXcgQkFCWUxPTi5WZWN0b3IzKDcsIC04LCAtMyk7XHJcblxyXG4gICAgICAgICAgLy8gLy8gQW5ndWxhciBzcGVlZCwgaW4gcmFkaWFuc1xyXG4gICAgICAgICAgLy8gcGFydGljbGVTeXN0ZW0ubWluQW5ndWxhclNwZWVkID0gMDtcclxuICAgICAgICAgIC8vIHBhcnRpY2xlU3lzdGVtLm1heEFuZ3VsYXJTcGVlZCA9IE1hdGguUEk7XHJcblxyXG4gICAgICAgICAgLy8gLy8gU3BlZWRcclxuICAgICAgICAgIC8vIHBhcnRpY2xlU3lzdGVtLm1pbkVtaXRQb3dlciA9IDE7XHJcbiAgICAgICAgICAvLyBwYXJ0aWNsZVN5c3RlbS5tYXhFbWl0UG93ZXIgPSAzO1xyXG4gICAgICAgICAgLy8gcGFydGljbGVTeXN0ZW0udXBkYXRlU3BlZWQgPSAwLjAwNTtcclxuXHJcbiAgICAgICAgICAvLyAvLyBTdGFydCB0aGUgcGFydGljbGUgc3lzdGVtXHJcbiAgICAgICAgICAvLyBwYXJ0aWNsZVN5c3RlbS5zdGFydCgpO1xyXG5cclxuICAgICAgICAgIC8vIEZvdW50YWluJ3MgYW5pbWF0aW9uXHJcbiAgICAgICAgfSBlbHNlIGlmIChhcnJbaV1bal0gPT09IDMpIHtcclxuICAgICAgICAgIHBvc3ogPSB6OyBcclxuICAgICAgICAgIHBvc3ggPSB4OyBcclxuICAgICAgICAgIC8vY29uc29sZS5sb2coJ3g6JywgY2FtZXJhLnBvc2l0aW9uLngsIFwiejpcIiwgcGxhbmUucG9zaXRpb24ueik7XHJcbiAgICAgICAgfVxyXG4gICAgICAgIHggKz0gMjU7XHJcbiAgICAgIH1cclxuICAgICAgeCA9IC0zODc7XHJcbiAgICAgIHogLT0gMjU7XHJcbiAgICB9XHJcbiAgICByZXR1cm4gYm94ZXM7XHJcbiAgfTtcclxuICB2YXIgY3JlYXRlU2NlbmUgPSBmdW5jdGlvbiAoKSB7XHJcblxyXG4gICAgLy8gTm93IGNyZWF0ZSBhIGJhc2ljIEJhYnlsb24gU2NlbmUgb2JqZWN0IFxyXG4gICAgdmFyIHNjZW5lID0gbmV3IEJBQllMT04uU2NlbmUoZW5naW5lKTtcclxuICAgIHNjZW5lLmFtYmllbnRDb2xvciA9IG5ldyBCQUJZTE9OLkNvbG9yMygwLjMsIDAuMywgMC4zKTtcclxuICAgIC8vVlJEZXZpY2VPcmllbnRhdGlvbkZyZWVDYW1lcmFcclxuICAgIGNhbWVyYSA9IG5ldyBCQUJZTE9OLkZyZWVDYW1lcmEoXCJjYW1lcmExXCIsIG5ldyBCQUJZTE9OLlZlY3RvcjMoMCwgNSwgLTEwKSwgc2NlbmUpO1xyXG4gICAgLy9jYW1lcmEuaW5wdXRzLmFkZEdhbWVwYWQoKTtcclxuICAgIGNhbWVyYS5zZXRUYXJnZXQoQkFCWUxPTi5WZWN0b3IzLlplcm8oKSk7XHJcbiAgICBjYW1lcmEuYXR0YWNoQ29udHJvbChjYW52YXMsIHRydWUpO1xyXG4gICAgYmFsbCA9IEJBQllMT04uTWVzaC5DcmVhdGVTcGhlcmUoXCJzcGhlcmVcIiwgMjAuMCwgNC4wLCBzY2VuZSk7XHJcbiAgICBiYWxsLnBvc2l0aW9uLnkgPSA1O1xyXG4gICAgYmFsbC5wb3NpdGlvbi56ID0gLTI1MDtcclxuICAgIGJhbGwucG9zaXRpb24ueCA9IC0xMjU7IFxyXG4gICAgYmFsbC5jaGVja0NvbGxpc2lvbnMgPSB0cnVlO1xyXG4gICAgYmFsbC5tYXRlcmlhbCA9IG5ldyBCQUJZTE9OLlN0YW5kYXJkTWF0ZXJpYWwoXCJ3b3dcIiwgc2NlbmUpO1xyXG4gICAgYmFsbC5tYXRlcmlhbC5kaWZmdXNlQ29sb3IgPSBuZXcgQkFCWUxPTi5Db2xvcjMoMCwgMC4yLCAwLjcpO1xyXG4gICAgYmFsbC5tYXRlcmlhbC5lbWlzc2l2ZUNvbG9yID0gbmV3IEJBQllMT04uQ29sb3IzKDAsIC4yLCAuNyk7XHJcbiAgICBzY2VuZS5hY3RpdmVDYW1lcmFzLnB1c2goY2FtZXJhKTtcclxuICAgIC8vc2NlbmUuZm9nID0gbmV3IHQuRm9nRXhwMigweEQ2RjFGRiwgMC4wMDA1KTtcclxuICAgIHZhciBza3lib3ggPSBCQUJZTE9OLk1lc2guQ3JlYXRlQm94KFwic2t5Qm94XCIsIDUwMDAuMCwgc2NlbmUpO1xyXG4gICAgdmFyIHNreWJveE1hdGVyaWFsID0gbmV3IEJBQllMT04uU3RhbmRhcmRNYXRlcmlhbChcInNreUJveFwiLCBzY2VuZSk7XHJcbiAgICBza3lib3hNYXRlcmlhbC5iYWNrRmFjZUN1bGxpbmcgPSBmYWxzZTtcclxuICAgIHNreWJveE1hdGVyaWFsLnJlZmxlY3Rpb25UZXh0dXJlID0gbmV3IEJBQllMT04uQ3ViZVRleHR1cmUoJ2Fzc2V0cy9za3kzNS9jaXR5c2t5Jywgc2NlbmUpO1xyXG4gICAgc2t5Ym94TWF0ZXJpYWwucmVmbGVjdGlvblRleHR1cmUuY29vcmRpbmF0ZXNNb2RlID0gQkFCWUxPTi5UZXh0dXJlLlNLWUJPWF9NT0RFO1xyXG4gICAgc2t5Ym94TWF0ZXJpYWwuZGlmZnVzZUNvbG9yID0gbmV3IEJBQllMT04uQ29sb3IzKDAsIDAsIDApO1xyXG4gICAgc2t5Ym94TWF0ZXJpYWwuc3BlY3VsYXJDb2xvciA9IG5ldyBCQUJZTE9OLkNvbG9yMygwLCAwLCAwKTtcclxuICAgIHNreWJveE1hdGVyaWFsLmRpc2FibGVMaWdodGluZyA9IHRydWU7XHJcbiAgICBza3lib3gubWF0ZXJpYWwgPSBza3lib3hNYXRlcmlhbDtcclxuICAgIHNreWJveC5pbmZpbml0ZURpc3RhbmNlID0gdHJ1ZTtcclxuICAgIHNreWJveC5yZW5kZXJpbmdHcm91cElkID0gMDtcclxuICAgIHNjZW5lLmZvZ01vZGUgPSBCQUJZTE9OLlNjZW5lLkxJTkVBUjtcclxuICAgIHNjZW5lLmZvZ0RlbnNpdHkgPSAwLjAxO1xyXG4gICAgc2NlbmUuZm9nU3RhcnQgPSAtNDAwLjA7XHJcbiAgICBzY2VuZS5mb2dFbmQgPSA0MDAuMDtcclxuICAgIHNjZW5lLmZvZ0NvbG9yID0gbmV3IEJBQllMT04uQ29sb3IzKDAuMywgMC45LCAwLjg1KTtcclxuICAgIC8vIEJBQllMT04uU2NlbmVMb2FkZXIuSW1wb3J0TWVzaChcIlwiLCBcIi4uL2Fzc2V0cy9cIiwgXCJnaG9zdHBhcmVudC5iYWJ5bG9uXCIsIHNjZW5lLCBmdW5jdGlvbiAobmV3TWVzaGVzLCBwYXJ0aWNsZVN5c3RlbXMsIHNrZWxldG9ucykge1xyXG4gICAgLy8gICBmb3IgKHZhciBpID0gMDsgaSA8IG5ld01lc2hlcy5sZW5ndGg7IGkrKykge1xyXG4gICAgLy8gICAgIHZhciBnaG9zdHkgPSBuZXdNZXNoZXNbaV07XHJcbiAgICAvLyAgICAgdGhpcy5naG9zdCA9IG5ld01lc2hlc1swXTtcclxuICAgIC8vICAgICB2YXIgbGlnaHQwID0gbmV3IEJBQllMT04uU3BvdExpZ2h0KFwiU3BvdDBcIiwgbmV3IEJBQllMT04uVmVjdG9yMygwLCA1MCwgMCksIG5ldyBCQUJZTE9OLlZlY3RvcjMoMCwgLTEsIDApLCAwLjQsIDMsIHNjZW5lKTtcclxuICAgIC8vICAgICBsaWdodDAucGFyZW50ID0gZ2hvc3R5O1xyXG4gICAgLy8gICAgIGlmIChnaG9zdHkubmFtZSA9PT0gJ1BsYW5lJykge1xyXG4gICAgLy8gICAgICAgZ2hvc3R5LnBvc2l0aW9uLnkgPSA1MDtcclxuICAgIC8vICAgICAgIGdob3N0eS5wb3NpdGlvbi54ID0gLTIwMDtcclxuICAgIC8vICAgICAgIGdob3N0eS5wb3NpdGlvbi56ID0gLTEwO1xyXG4gICAgLy8gICAgICAgZ2hvc3R5LnNjYWxpbmcueCA9IDIwO1xyXG4gICAgLy8gICAgICAgZ2hvc3R5LnNjYWxpbmcueSA9IDEwO1xyXG4gICAgLy8gICAgICAgZ2hvc3R5LnNjYWxpbmcueiA9IDIwO1xyXG5cclxuICAgIC8vICAgICAgIGdob3N0eS5tYXRlcmlhbCA9IG5ldyBCQUJZTE9OLlN0YW5kYXJkTWF0ZXJpYWwoJ2dob3N0eScsIHNjZW5lKTtcclxuICAgIC8vICAgICAgIGdob3N0eS5tYXRlcmlhbC5lbWlzc2l2ZUNvbG9yID0gbmV3IEJBQllMT04uQ29sb3IzKDAuMiwgMC40LCAwLjgpO1xyXG4gICAgLy8gICAgIH0gZWxzZSBpZiAoZ2hvc3R5Lm5hbWUgPT09ICdTcGhlcmUnIHx8IGdob3N0eS5uYW1lID09PSAnU3BoZXJlLjAwMScpIHtcclxuICAgIC8vICAgICAgIGdob3N0eS5tYXRlcmlhbCA9IG5ldyBCQUJZTE9OLlN0YW5kYXJkTWF0ZXJpYWwoJ2dob3N0eScsIHNjZW5lKTtcclxuICAgIC8vICAgICAgIGdob3N0eS5tYXRlcmlhbC5lbWlzc2l2ZUNvbG9yID0gbmV3IEJBQllMT04uQ29sb3IzKDEsIDEsIDEpO1xyXG4gICAgLy8gICAgICAgZ2hvc3R5Lm1hdGVyaWFsLnNwZWN1bGFyQ29sb3IgPSBuZXcgQkFCWUxPTi5Db2xvcjMoMSwgMSwgMSk7XHJcbiAgICAvLyAgICAgICBnaG9zdHkubWF0ZXJpYWwuZGlmZnVzZUNvbG9yID0gbmV3IEJBQllMT04uQ29sb3IzKDAuOCwgMC44LCAwLjgpO1xyXG4gICAgLy8gICAgIH0gZWxzZSBpZiAoZ2hvc3R5Lm5hbWUgPT09ICdTcGhlcmUuMDAyJyB8fCBnaG9zdHkubmFtZSA9PT0gJ1NwaGVyZS4wMDMnKSB7XHJcbiAgICAvLyAgICAgICBnaG9zdHkubWF0ZXJpYWwgPSBuZXcgQkFCWUxPTi5TdGFuZGFyZE1hdGVyaWFsKCdnaG9zdHknLCBzY2VuZSk7XHJcbiAgICAvLyAgICAgICBnaG9zdHkubWF0ZXJpYWwuZW1pc3NpdmVDb2xvciA9IG5ldyBCQUJZTE9OLkNvbG9yMygwLCAwLCAwKTtcclxuICAgIC8vICAgICAgIGdob3N0eS5tYXRlcmlhbC5zcGVjdWxhckNvbG9yID0gbmV3IEJBQllMT04uQ29sb3IzKDEsIDEsIDEpO1xyXG4gICAgLy8gICAgICAgZ2hvc3R5Lm1hdGVyaWFsLmRpZmZ1c2VDb2xvciA9IG5ldyBCQUJZTE9OLkNvbG9yMygwLjgsIDAuOCwgMC44KTtcclxuICAgIC8vICAgICB9XHJcbiAgICAgICAgIFxyXG4gICAgLy8gICB9XHJcbiAgICAgIFxyXG4gICAgLy8gICBnaG9zdHkubWF0ZXJpYWwgPSBuZXcgQkFCWUxPTi5TdGFuZGFyZE1hdGVyaWFsKFwibG9sXCIsIHNjZW5lKTtcclxuICAgIC8vICAgeC5tYXRlcmlhbC5lbWlzc2l2ZUNvbG9yID0gbmV3IEJBQllMT04uQ29sb3IzKDAuMSwgMC44LCAwLjgpO1xyXG4gICAgLy8gfS5iaW5kKG9iaikpO1xyXG4gICAgdmFyIG1tID0gbmV3IEJBQllMT04uRnJlZUNhbWVyYShcIm1pbmltYXBcIiwgbmV3IEJBQllMT04uVmVjdG9yMygwLDEwMDAsMCksIHNjZW5lKTtcclxuICAgIG1tLnNldFRhcmdldChuZXcgQkFCWUxPTi5WZWN0b3IzKDAuMSwwLjEsMC4xKSk7XHJcbiAgICAvLyBBY3RpdmF0ZSB0aGUgb3J0aG9ncmFwaGljIHByb2plY3Rpb25cclxuICAgIG1tLm1vZGUgPSBCQUJZTE9OLkNhbWVyYS5PUlRIT0dSQVBISUNfQ0FNRVJBO1xyXG4gICAgbW0ub3J0aG9MZWZ0ID0gLWNhbnZhcy5zaXplLzI7XHJcbiAgICBtbS5vcnRob1JpZ2h0ID0gY2FudmFzLnNpemUvMjtcclxuICAgIG1tLm9ydGhvVG9wID0gIGNhbnZhcy5zaXplLzI7XHJcbiAgICBtbS5vcnRob0JvdHRvbSA9IC1jYW52YXMuc2l6ZS8yO1xyXG5cclxuICAgIG1tLnJvdGF0aW9uLnggPSBNYXRoLlBJLzI7XHJcblxyXG4gICAgdmFyIHhzdGFydCA9IDAuOCwgLy8gODAlIGZyb20gdGhlIGxlZnRcclxuICAgICAgICB5c3RhcnQgPSAwLjc1OyAvLyA3NSUgZnJvbSB0aGUgYm90dG9tXHJcbiAgICB2YXIgd2lkdGggPSAwLjk5LXhzdGFydCwgLy8gQWxtb3N0IHVudGlsIHRoZSByaWdodCBlZGdlIG9mIHRoZSBzY3JlZW5cclxuICAgICAgICBoZWlnaHQgPSAxLXlzdGFydDsgIC8vIFVudGlsIHRoZSB0b3AgZWRnZSBvZiB0aGUgc2NyZWVuXHJcblxyXG4gICAgbW0udmlld3BvcnQgPSBuZXcgQkFCWUxPTi5WaWV3cG9ydChcclxuICAgICAgICB4c3RhcnQsXHJcbiAgICAgICAgeXN0YXJ0LFxyXG4gICAgICAgIHdpZHRoLFxyXG4gICAgICAgIGhlaWdodFxyXG4gICAgICAgICk7XHJcbiAgICBzY2VuZS5hY3RpdmVDYW1lcmFzLnB1c2gobW0pO1xyXG4gICAgbW0ubGF5ZXJNYXNrID0gMTtcclxuICAgIGNhbWVyYS5sYXllck1hc2sgPSAyO1xyXG4gICAgdmFyIGxpZ2h0MCA9IG5ldyBCQUJZTE9OLlNwb3RMaWdodChcIlNwb3QwXCIsIG5ldyBCQUJZTE9OLlZlY3RvcjMoMCwgNTAsIDApLCBuZXcgQkFCWUxPTi5WZWN0b3IzKDAsIC0xLCAwKSwgMC4xLCAzLCBzY2VuZSk7XHJcbiAgICBsaWdodDAuZGlmZnVzZSA9IG5ldyBCQUJZTE9OLkNvbG9yMygxLCAwLCAwKTtcclxuICAgIGxpZ2h0MC5zcGVjdWxhciA9IG5ldyBCQUJZTE9OLkNvbG9yMygxLCAxLCAxKTtcclxuICAgIGxpZ2h0MC5wYXJlbnQgPSBjYW1lcmE7XHJcbiAgICB2YXIgcGxhbmUgPSBCQUJZTE9OLk1lc2guQ3JlYXRlQm94KFwicGxhbmVcIiwgMiwgc2NlbmUpO1xyXG4gICAgcGxhbmUuc2NhbGluZy56ID0gMjAwO1xyXG4gICAgcGxhbmUuc2NhbGluZy55ID0gMTAwO1xyXG4gICAgcGxhbmUuc2NhbGluZy54ID0gLjI7XHJcbiAgICBwbGFuZS5tYXRlcmlhbCA9IG5ldyBCQUJZTE9OLlN0YW5kYXJkTWF0ZXJpYWwoXCJ0ZXh0dXJlMVwiLCBzY2VuZSk7XHJcbiAgICBwbGFuZS5tYXRlcmlhbC5kaWZmdXNlQ29sb3IgPSBuZXcgQkFCWUxPTi5Db2xvcjMoMC4yLCAwLjIsIDAuOCk7XHJcbiAgICBwbGFuZS5tYXRlcmlhbC5hbHBoYSA9IDAuMjtcclxuICAgIGNyZWF0ZVdhbGxCb2R5KHBsYW5lLmdldEJvdW5kaW5nSW5mbygpLmJvdW5kaW5nQm94LmNlbnRlciwgbmV3IENBTk5PTi5WZWMzKHBsYW5lLnNjYWxpbmcueCwgcGxhbmUuc2NhbGluZy55LCBwbGFuZS5zY2FsaW5nLnopLCAwKTtcclxuICAgIHZhciB3YWxscyA9IFtdO1xyXG4gICAgdmFyIGFyciA9IG1hemVtYWtlcih0aGF0LnByb3BzLm1hemUsIHNjZW5lLCBwbGFuZSwgc2NlbmUuYWN0aXZlQ2FtZXJhLCBiYWxsLCB3YWxscyk7XHJcbiAgICB2YXIgcGxhbmUyID0gQkFCWUxPTi5NZXNoLkNyZWF0ZUJveChcInBsYW5lXCIsIDIsIHNjZW5lKTtcclxuICAgIHBsYW5lMi5zY2FsaW5nLnogPSAyMDA7XHJcbiAgICBwbGFuZTIuc2NhbGluZy55ID0gMTAwO1xyXG4gICAgcGxhbmUyLnNjYWxpbmcueCA9IC4yO1xyXG4gICAgcGxhbmUyLnBvc2l0aW9uLnggPSAtNDAwOyBcclxuICAgIHBsYW5lMi5tYXRlcmlhbCA9IG5ldyBCQUJZTE9OLlN0YW5kYXJkTWF0ZXJpYWwoXCJncmFzcy5wbmdcIiwgc2NlbmUpO1xyXG4gICAgcGxhbmUyLm1hdGVyaWFsLmRpZmZ1c2VDb2xvciA9IG5ldyBCQUJZTE9OLkNvbG9yMygwLjIsIDAuMiwgMC44KTtcclxuICAgIHBsYW5lMi5tYXRlcmlhbC5hbHBoYSA9IDAuMjtcclxuICAgIGNyZWF0ZVdhbGxCb2R5KHBsYW5lMi5nZXRCb3VuZGluZ0luZm8oKS5ib3VuZGluZ0JveC5jZW50ZXIsIG5ldyBDQU5OT04uVmVjMyhwbGFuZTIuc2NhbGluZy54LCBwbGFuZTIuc2NhbGluZy55LCBwbGFuZTIuc2NhbGluZy56KSwgMCk7XHJcbiAgICB2YXIgcGxhbmUzID0gQkFCWUxPTi5NZXNoQnVpbGRlci5DcmVhdGVCb3goXCJwbGFuZVwiLCAyLCBzY2VuZSk7XHJcbiAgICBwbGFuZTMuc2NhbGluZy56ID0gNDAwO1xyXG4gICAgcGxhbmUzLnNjYWxpbmcueSA9IDIwMDtcclxuICAgIHBsYW5lMy5zY2FsaW5nLnggPSAuMjtcclxuICAgIHBsYW5lMy5yb3RhdGlvbi55ID0gTWF0aC5QSS8yO1xyXG4gICAgcGxhbmUzLnBvc2l0aW9uLnggPSAtMjAwOyBcclxuICAgIHBsYW5lMy5wb3NpdGlvbi56ID0gMjAwO1xyXG4gICAgcGxhbmUzLm1hdGVyaWFsID0gbmV3IEJBQllMT04uU3RhbmRhcmRNYXRlcmlhbChcInRleHR1cmUxXCIsIHNjZW5lKTtcclxuICAgIHBsYW5lMy5tYXRlcmlhbC5kaWZmdXNlQ29sb3IgPSBuZXcgQkFCWUxPTi5Db2xvcjMoMC4yLCAwLjIsIDAuOCk7XHJcbiAgICBwbGFuZTMubWF0ZXJpYWwuYWxwaGEgPSAwLjI7XHJcbiAgICBjcmVhdGVXYWxsQm9keShwbGFuZTMuZ2V0Qm91bmRpbmdJbmZvKCkuYm91bmRpbmdCb3guY2VudGVyLCBuZXcgQ0FOTk9OLlZlYzMocGxhbmUzLnNjYWxpbmcueCwgcGxhbmUzLnNjYWxpbmcueSwgcGxhbmUzLnNjYWxpbmcueiksIDIpO1xyXG4gICAgdmFyIHBsYW5lNCA9IEJBQllMT04uTWVzaEJ1aWxkZXIuQ3JlYXRlQm94KFwicGxhbmVcIiwgMiwgc2NlbmUpO1xyXG4gICAgcGxhbmU0LnNjYWxpbmcueiA9IDQwMDtcclxuICAgIHBsYW5lNC5zY2FsaW5nLnkgPSAyMDA7XHJcbiAgICBwbGFuZTQuc2NhbGluZy54ID0gMC4yO1xyXG4gICAgcGxhbmU0LnJvdGF0aW9uLnkgPSBNYXRoLlBJLzI7XHJcbiAgICBwbGFuZTQucG9zaXRpb24ueCA9IC0yMDA7IFxyXG4gICAgcGxhbmU0LnBvc2l0aW9uLnogPSAtMjAwO1xyXG4gICAgcGxhbmU0Lm1hdGVyaWFsID0gbmV3IEJBQllMT04uU3RhbmRhcmRNYXRlcmlhbChcInRleHR1cmUxXCIsIHNjZW5lKTtcclxuICAgIHBsYW5lNC5tYXRlcmlhbC5kaWZmdXNlQ29sb3IgPSBuZXcgQkFCWUxPTi5Db2xvcjMoMC4yLCAwLjIsIDAuOCk7XHJcbiAgICBwbGFuZTQubWF0ZXJpYWwuYWxwaGEgPSAwLjI7XHJcbiAgICBjcmVhdGVXYWxsQm9keShwbGFuZTQuZ2V0Qm91bmRpbmdJbmZvKCkuYm91bmRpbmdCb3guY2VudGVyLCBuZXcgQ0FOTk9OLlZlYzMocGxhbmU0LnNjYWxpbmcueCwgcGxhbmU0LnNjYWxpbmcueSwgcGxhbmU0LnNjYWxpbmcueiksIDIpO1xyXG5cclxuICAgIHZhciBncm91bmQgPSBCQUJZTE9OLk1lc2guQ3JlYXRlR3JvdW5kKFwiZ3JvdW5kMVwiLCAxMDAwLCAxMDAwLCAyLCBzY2VuZSk7XHJcbiAgICBncm91bmQubWF0ZXJpYWwgPSBuZXcgQkFCWUxPTi5TdGFuZGFyZE1hdGVyaWFsKFwidGV4dHVyZTFcIiwgc2NlbmUpO1xyXG4gICAgZ3JvdW5kLm1hdGVyaWFsLmVtaXNzaXZlVGV4dHVyZSA9IG5ldyBCQUJZTE9OLlRleHR1cmUoJy4uL2Fzc2V0cy9ncm91bmQyLmpwZycsIHNjZW5lKTtcclxuICAgIGdyb3VuZC5tYXRlcmlhbC5lbWlzc2l2ZVRleHR1cmUudVNjYWxlID0gMTAwLjA7XHJcbiAgICBncm91bmQubWF0ZXJpYWwuZW1pc3NpdmVUZXh0dXJlLnZTY2FsZSA9IDEwMC4wO1xyXG4gICAgcGVsbGV0U291bmQgPSBuZXcgQkFCWUxPTi5Tb3VuZChcInBlbGxldFwiLCBcIi4uL2Fzc2V0cy9wZWxsZXQud2F2XCIsIHNjZW5lKTtcclxuICAgIGNhbnZhczIgPSBjcmVhdGUoc2NlbmUsIHNjb3JlKTtcclxuICAgIHJldHVybiBzY2VuZTtcclxuXHJcbiAgfTsgIC8vIEVuZCBvZiBjcmVhdGVTY2VuZSBmdW5jdGlvblxyXG4gIHZhciBjcmVhdGVXb3JsZCA9IGZ1bmN0aW9uKCl7XHJcbiAgICB2YXIgd29ybGQgPSBuZXcgQ0FOTk9OLldvcmxkKCk7XHJcbiAgICB3b3JsZC5ncmF2aXR5LnNldCgwLC01MCwwKTtcclxuICAgIHZhciBtYXNzID0gNSwgcmFkaXVzID0gMS4yNTtcclxuICAgIHZhciBzcGhlcmVTaGFwZSA9IG5ldyBDQU5OT04uU3BoZXJlKHJhZGl1cyk7IC8vIFN0ZXAgMVxyXG4gICAgc3BoZXJlQm9keSA9IG5ldyBDQU5OT04uQm9keSh7bWFzczogbWFzcywgc2hhcGU6IHNwaGVyZVNoYXBlfSk7IC8vIFN0ZXAgMlxyXG4gICAgc3BoZXJlQm9keS5wb3NpdGlvbi5zZXQocG9zeCw1LHBvc3opO1xyXG4gICAgc3BoZXJlQm9keS5yb3RhdGlvbiA9IG5ldyBDQU5OT04uVmVjMygpO1xyXG4gICAgc3BoZXJlQm9keS5xdWF0ZXJuaW9uLnNldEZyb21BeGlzQW5nbGUobmV3IENBTk5PTi5WZWMzKDEsMCwwKSwtTWF0aC5QSS8yKTsgIFxyXG4gICAgc3BoZXJlQm9keS5hZGRFdmVudExpc3RlbmVyKCdjb2xsaWRlJywgZnVuY3Rpb24oZSl7XHJcbiAgICAgICBpZihlLmJvZHkuaXNQZWxsZXQpe1xyXG4gICAgICAgICBmb3IgKHZhciBwIGluIHBlbGxldHMpe1xyXG4gICAgICAgICAgIGlmIChwZWxsZXRzW3BdID09PSBwZWxsZXRzW2UuYm9keS5wZWxsZXRJZF0pe1xyXG4gICAgICAgICAgICAgcGVsbGV0TWVzaGVzW3BdLmRpc3Bvc2UoKTtcclxuICAgICAgICAgICAgIC8vd29ybGQucmVtb3ZlKHBlbGxldHNbcF0pO1xyXG4gICAgICAgICAgICAgcGVsbGV0UmVtb3ZlciA9IHA7XHJcbiAgICAgICAgICAgICBwZWxsZXRTb3VuZC5wbGF5KCk7XHJcbiAgICAgICAgICAgICBzY29yZSsrO1xyXG4gICAgICAgICAgICAgY2FudmFzMi5jaGlsZHJlblswXS50ZXh0ID0gc2NvcmUudG9TdHJpbmcoKTtcclxuICAgICAgICAgICB9XHJcbiAgICAgICAgIH1cclxuICAgICAgIH1cclxuICAgICB9KTtcclxuICAgIHdvcmxkLmFkZChzcGhlcmVCb2R5KTtcclxuICAgIHZhciBnaG9zdFNoYXBlID0gbmV3IENBTk5PTi5TcGhlcmUoMTApOyAvLyBTdGVwIDFcclxuICAgIGdob3N0Qm9keSA9IG5ldyBDQU5OT04uQm9keSh7bWFzczogNSwgc2hhcGU6IGdob3N0U2hhcGV9KTsgLy8gU3RlcCAyXHJcbiAgICBnaG9zdEJvZHkucG9zaXRpb24uc2V0KC0yNTAsNSwtMTUwKTtcclxuICAgIGdob3N0Qm9keS5yb3RhdGlvbiA9IG5ldyBDQU5OT04uVmVjMygpO1xyXG4gICAgZ2hvc3RCb2R5LnF1YXRlcm5pb24uc2V0RnJvbUF4aXNBbmdsZShuZXcgQ0FOTk9OLlZlYzMoMSwwLDApLC1NYXRoLlBJLzIpOyAgXHJcbiAgICBnaG9zdEJvZHkuYWRkRXZlbnRMaXN0ZW5lcignY29sbGlkZScsIGZ1bmN0aW9uKGUpe1xyXG4gICAgIGdob3N0eHZlbG9jaXR5ID0gTWF0aC5mbG9vcihNYXRoLnJhbmRvbSgpICogNTApIC0gMjU7XHJcbiAgICAgZ2hvc3R6dmVsb2NpdHkgPSBNYXRoLmZsb29yKE1hdGgucmFuZG9tKCkgKiA1MCkgLSAyNTtcclxuICAgICB9KTtcclxuICAgIHdvcmxkLmFkZChnaG9zdEJvZHkpO1xyXG4gICAgLy8gc3BoZXJlQm9keS5hZGRFdmVudExpc3RlbmVyKCdjb2xsaWRlJywgZnVuY3Rpb24oZSl7XHJcbiAgICAvLyAgIGlmKGUuYm9keS5pc0NvaW4pe1xyXG4gICAgLy8gICAgICAvL2UuYm9keS5cclxuICAgIC8vICAgICBjb25zb2xlLmxvZyhcImNvbGxpZGVkXCIsIGUuYm9keS5jb2luSUQpO1xyXG4gICAgLy8gICAgIGZvciAoYyBpbiBjb2lucyl7XHJcbiAgICAvLyAgICAgICBpZiAoY29pbnNbY10gPT09IGNvaW5zW2UuYm9keS5jb2luSURdKXtcclxuICAgIC8vICAgICAgICAgY29uc29sZS5sb2coXCJZRXMgcGxlYXNlXCIsIGNvaW5zW2NdKTtcclxuICAgIC8vICAgICAgICAgY29pbk1lc2hlc1tjXS5pc1Zpc2libGUgPSBmYWxzZTtcclxuICAgICAgICAgICBcclxuICAgIC8vICAgICAgIH1cclxuXHJcbiAgICAvLyAgICAgfVxyXG4gICAgLy8gICB9XHJcbiAgICAgIFxyXG4gICAgLy8gfSk7XHJcbiAgICAgICAgICBcclxuICAgICAgXHJcblxyXG4gICAgICB2YXIgZ3JvdW5kU2hhcGUgPSBuZXcgQ0FOTk9OLlBsYW5lKCk7XHJcbiAgICAgIHZhciBncm91bmRCb2R5ID0gbmV3IENBTk5PTi5Cb2R5KHsgbWFzczogMCwgc2hhcGU6IGdyb3VuZFNoYXBlIH0pO1xyXG4gICAgICB3b3JsZC5hZGQoZ3JvdW5kQm9keSk7XHJcbiAgICAgIGdyb3VuZEJvZHkucXVhdGVybmlvbi5zZXRGcm9tQXhpc0FuZ2xlKG5ldyBDQU5OT04uVmVjMygxLDAsMCksLU1hdGguUEkvMik7ICBcclxuXHJcbiAgcmV0dXJuIHdvcmxkO1xyXG59O1xyXG5cclxuICAgIHZhciBjcmVhdGVXYWxsQm9keSA9IGZ1bmN0aW9uKHBvc2l0aW9uLCBzaXplLCBmbGFnKXsgIFxyXG4gICAgICB2YXIgYm94U2hhcGUgPSBuZXcgQ0FOTk9OLkJveChzaXplKTtcclxuICAgICAgdmFyIGJveEJvZHkgPSBuZXcgQ0FOTk9OLkJvZHkoe3NoYXBlOiBib3hTaGFwZSwgbWFzczowfSk7XHJcbiAgICAgIGJveEJvZHkucG9zaXRpb24gPSBwb3NpdGlvbjtcclxuICAgICAgaWYoZmxhZyA9PT0gMSkge1xyXG4gICAgICAgIGJveEJvZHkucXVhdGVybmlvbi5zZXRGcm9tQXhpc0FuZ2xlKG5ldyBDQU5OT04uVmVjMygwLDEsMCksLU1hdGguUEkvMik7ICBcclxuICAgICAgfSBlbHNlIGlmKGZsYWcgPT09IDIpIHtcclxuICAgICAgICBib3hCb2R5LnF1YXRlcm5pb24uc2V0RnJvbUF4aXNBbmdsZShuZXcgQ0FOTk9OLlZlYzMoMCwxLDApLE1hdGguUEkvMik7IFxyXG4gICAgICB9XHJcbiAgICAgIHdvcmxkLmFkZChib3hCb2R5KTsgXHJcbiAgICAgfTtcclxuXHJcbiAgICB2YXIgY3JlYXRlU3BoZXJlQm9keSA9IGZ1bmN0aW9uKHBvc2l0aW9uLCByYWRpdXMsIGlkKXsgIFxyXG4gICAgICB2YXIgcGVsbGV0U2hhcGUgPSBuZXcgQ0FOTk9OLlNwaGVyZShyYWRpdXMpO1xyXG4gICAgICB2YXIgcGVsbGV0Qm9keSA9IG5ldyBDQU5OT04uQm9keSh7bWFzczogMCwgc2hhcGU6IHBlbGxldFNoYXBlfSk7XHJcbiAgICAgIHBlbGxldEJvZHkucG9zaXRpb24gPSBwb3NpdGlvbjtcclxuICAgICAgcGVsbGV0Qm9keS5pc1BlbGxldCA9IHRydWU7XHJcbiAgICAgIHBlbGxldEJvZHkuY29sbGlzaW9uUmVzcG9uc2UgPSAwO1xyXG4gICAgICBwZWxsZXRCb2R5LnBlbGxldElkID0gaWQ7XHJcbiAgICAgIHBlbGxldHNbaWRdID0gcGVsbGV0Qm9keTtcclxuICAgICAgd29ybGQuYWRkKHBlbGxldEJvZHkpOyBcclxuICAgICB9O1xyXG5cclxuXHJcbiAgICB2YXIgd29ybGQgPSBjcmVhdGVXb3JsZCgpOyAgICAgXHJcbiAgICB2YXIgc2NlbmUgPSBjcmVhdGVTY2VuZSgpO1xyXG4gICAgXHJcbiAgICBpZihjYW1lcmFGbGFnKSB7XHJcbiAgICAgIGNhbTEgPSBwYXJzZUZsb2F0KE1hdGguY29zKGNhbWVyYS5yb3RhdGlvblF1YXRlcm5pb24udG9FdWxlckFuZ2xlcygpLnkpKTtcclxuICAgICAgY2FtMiA9IHBhcnNlRmxvYXQoTWF0aC5zaW4oY2FtZXJhLnJvdGF0aW9uUXVhdGVybmlvbi50b0V1bGVyQW5nbGVzKCkueSkpO1xyXG4gICAgfSBlbHNlIHtcclxuICAgICAgY2FtMSA9IHBhcnNlRmxvYXQoTWF0aC5jb3MoY2FtZXJhLnJvdGF0aW9uLnkpKTtcclxuICAgICAgY2FtMiA9IHBhcnNlRmxvYXQoTWF0aC5zaW4oY2FtZXJhLnJvdGF0aW9uLnkpKTtcclxuICAgIH1cclxuXHJcbiAgICBlbmdpbmUucnVuUmVuZGVyTG9vcChmdW5jdGlvbiAoKSB7XHJcbiAgICAgIC8vY29uc29sZS5sb2coJ2NvdW50Jywgb2JqLmdob3N0KTtcclxuICAgICAgaWYocGVsbGV0UmVtb3ZlciAhPT0gMCkge1xyXG4gICAgICAgIHdvcmxkLnJlbW92ZShwZWxsZXRzW3BlbGxldFJlbW92ZXJdKTtcclxuICAgICAgICBwZWxsZXRSZW1vdmVyID0gMDtcclxuICAgICAgfVxyXG4gICAgICBzY2VuZS5yZW5kZXIoKTtcclxuICAgICAgd29ybGQuc3RlcCgxLjAvNjAuMCk7XHJcbiAgICAgIGlmIChjYW1lcmFGbGFnICYmIGNhbWVyYS5yb3RhdGlvblF1YXRlcm5pb24gIT09dW5kZWZpbmVkKSB7XHJcbiAgICAgICAgaWYgKGNhbTEgIT09IHBhcnNlRmxvYXQoTWF0aC5jb3MoY2FtZXJhLnJvdGF0aW9uUXVhdGVybmlvbi55KSkgfHwgY2FtMiAhPT0gcGFyc2VGbG9hdChNYXRoLnNpbihjYW1lcmEucm90YXRpb25RdWF0ZXJuaW9uLnkpKSkge1xyXG4gICAgICAgICAgY2FtMSA9IHBhcnNlRmxvYXQoTWF0aC5jb3MoY2FtZXJhLnJvdGF0aW9uUXVhdGVybmlvbi50b0V1bGVyQW5nbGVzKCkueSkpO1xyXG4gICAgICAgICAgY2FtMiA9IHBhcnNlRmxvYXQoTWF0aC5zaW4oY2FtZXJhLnJvdGF0aW9uUXVhdGVybmlvbi50b0V1bGVyQW5nbGVzKCkueSkpOyAgIFxyXG4gICAgICAgICAgc3BoZXJlQm9keS52ZWxvY2l0eS56ID0gY2FtMSogNDA7XHJcbiAgICAgICAgICBzcGhlcmVCb2R5LnZlbG9jaXR5LnggPSBjYW0yKiA0MDtcclxuICAgICAgICB9XHJcbiAgICAgIH0gZWxzZSB7XHJcbiAgICAgICAgICBjYW0xID0gcGFyc2VGbG9hdChNYXRoLmNvcyhjYW1lcmEucm90YXRpb24ueSkpO1xyXG4gICAgICAgICAgY2FtMiA9IHBhcnNlRmxvYXQoTWF0aC5zaW4oY2FtZXJhLnJvdGF0aW9uLnkpKTsgICBcclxuICAgICAgICAgIHNwaGVyZUJvZHkudmVsb2NpdHkueiA9IGNhbTEqIDIwO1xyXG4gICAgICAgICAgc3BoZXJlQm9keS52ZWxvY2l0eS54ID0gY2FtMiogMjA7XHJcbiAgICAgIH1cclxuICAgICAgXHJcbiAgICAgIGJhbGwucG9zaXRpb24ueCA9IHNwaGVyZUJvZHkucG9zaXRpb24ueDsgXHJcbiAgICAgIGJhbGwucG9zaXRpb24ueSA9IHNwaGVyZUJvZHkucG9zaXRpb24ueTsgXHJcbiAgICAgIGJhbGwucG9zaXRpb24ueiA9IHNwaGVyZUJvZHkucG9zaXRpb24uejsgXHJcblxyXG4gICAgICBjYW1lcmEucG9zaXRpb24ueCA9IHNwaGVyZUJvZHkucG9zaXRpb24ueCArIC40O1xyXG4gICAgICBjYW1lcmEucG9zaXRpb24ueSA9IHNwaGVyZUJvZHkucG9zaXRpb24ueVxyXG4gICAgICBjYW1lcmEucG9zaXRpb24ueiA9IHNwaGVyZUJvZHkucG9zaXRpb24uejtcclxuICAgICAgLy8gY29uc29sZS5sb2coZ2hvc3QpO1xyXG4gICAgICAvLyBjb25zb2xlLmxvZyhnaG9zdEJvZHkpXHJcbiAgICAgIGlmKG9iai5naG9zdCAhPT0gdW5kZWZpbmVkKSB7XHJcbiAgICAgICAgb2JqLmdob3N0LnBvc2l0aW9uLnggPSBnaG9zdEJvZHkucG9zaXRpb24ueDtcclxuICAgICAgICBvYmouZ2hvc3QucG9zaXRpb24ueSA9IGdob3N0Qm9keS5wb3NpdGlvbi55ICsgNDA7XHJcbiAgICAgICAgb2JqLmdob3N0LnBvc2l0aW9uLnogPSBnaG9zdEJvZHkucG9zaXRpb24uejtcclxuICAgICAgICBnaG9zdEJvZHkudmVsb2NpdHkueiA9IGdob3N0eHZlbG9jaXR5O1xyXG4gICAgICAgIGdob3N0Qm9keS52ZWxvY2l0eS54ID0gZ2hvc3R6dmVsb2NpdHk7XHJcbiAgICAgIH0gIFxyXG4gICAgICBpbnB1dFZlbG9jaXR5ID0gc3BoZXJlQm9keS52ZWxvY2l0eTtcclxuICAgICAgICB2YXIgcXVhdFggPSBuZXcgQ0FOTk9OLlF1YXRlcm5pb24oKTtcclxuICAgICAgICB2YXIgcXVhdFkgPSBuZXcgQ0FOTk9OLlF1YXRlcm5pb24oKTtcclxuICAgICAgICBxdWF0WC5zZXRGcm9tQXhpc0FuZ2xlKG5ldyBDQU5OT04uVmVjMygxLDAsMCksIGFuZ2xlWCk7XHJcbiAgICAgICAgcXVhdFkuc2V0RnJvbUF4aXNBbmdsZShuZXcgQ0FOTk9OLlZlYzMoMCwxLDApLCBhbmdsZVkpO1xyXG4gICAgICAgIHZhciBxdWF0ZXJuaW9uID0gcXVhdFkubXVsdChxdWF0WCk7XHJcbiAgICAgICAgcXVhdGVybmlvbi5ub3JtYWxpemUoKTtcclxuICAgICAgICBcclxuICAgICAgICBcclxuICAgICAgICBcclxuICAgICAgICB2YXIgcm90YXRlZFZlbG9jaXR5ID0gcXVhdGVybmlvbi52bXVsdChpbnB1dFZlbG9jaXR5KTtcclxuICAgICAgICBzcGhlcmVCb2R5LnZlbG9jaXR5ID0gcm90YXRlZFZlbG9jaXR5O1xyXG4gICAgICAgIFxyXG4gICAgfSk7XHJcbiAgICB3aW5kb3cuYWRkRXZlbnRMaXN0ZW5lcihcInJlc2l6ZVwiLCBmdW5jdGlvbiAoKSB7XHJcbiAgICAgIGVuZ2luZS5yZXNpemUoKTtcclxuICAgIH0pO1xyXG4gIH1cclxuXHJcblxyXG5cclxuICByZW5kZXIoKSB7XHJcbiAgICByZXR1cm4gKFxyXG4gICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImNhbnZhcy1jb250YWluZXJcIj5cclxuICAgICAgICAgICAgPGNhbnZhcyBpZD1cInJlbmRlckNhbnZhc1wiPjwvY2FudmFzPlxyXG4gICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImNhbWVyYS10b2dnbGVcIj5DYW1lcmEgVG9nZ2xlPC9kaXY+XHJcbiAgICAgICAgICAgIDwvZGl2Pik7XHJcbiAgfVxyXG59XHJcblxyXG53aW5kb3cuTWF6ZVJ1bm5lciA9IE1hemVSdW5uZXI7Il19