"use strict";

var SignupForm = function SignupForm(props) {
  return React.createElement(
    "form",
    { id: "signupForm" },
    React.createElement(
      "div",
      null,
      React.createElement(
        "label",
        null,
        "Username:"
      ),
      React.createElement("input", { type: "text", name: "username", id: "signup-username" })
    ),
    React.createElement(
      "div",
      null,
      React.createElement(
        "label",
        null,
        "Email:"
      ),
      React.createElement("input", { type: "text", name: "email" })
    ),
    React.createElement(
      "div",
      null,
      React.createElement(
        "label",
        null,
        "Password:"
      ),
      React.createElement("input", { type: "text", name: "password" })
    ),
    React.createElement(
      "div",
      null,
      React.createElement("input", { type: "submit", value: "Sign Up", onClick: props.signupFormSubmit })
    )
  );
};

window.SignupForm = SignupForm;
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIi4uL2NvbXBvbmVudHMvc2lnbnVwLmpzeCJdLCJuYW1lcyI6WyJTaWdudXBGb3JtIiwicHJvcHMiLCJzaWdudXBGb3JtU3VibWl0Iiwid2luZG93Il0sIm1hcHBpbmdzIjoiOztBQUFBLElBQUlBLGFBQWEsU0FBYkEsVUFBYSxDQUFDQyxLQUFEO0FBQUEsU0FDZjtBQUFBO0FBQUEsTUFBTSxJQUFHLFlBQVQ7QUFDRTtBQUFBO0FBQUE7QUFDRTtBQUFBO0FBQUE7QUFBQTtBQUFBLE9BREY7QUFFRSxxQ0FBTyxNQUFLLE1BQVosRUFBbUIsTUFBSyxVQUF4QixFQUFtQyxJQUFHLGlCQUF0QztBQUZGLEtBREY7QUFLRTtBQUFBO0FBQUE7QUFDRTtBQUFBO0FBQUE7QUFBQTtBQUFBLE9BREY7QUFFRSxxQ0FBTyxNQUFLLE1BQVosRUFBbUIsTUFBSyxPQUF4QjtBQUZGLEtBTEY7QUFVRTtBQUFBO0FBQUE7QUFDRTtBQUFBO0FBQUE7QUFBQTtBQUFBLE9BREY7QUFFRSxxQ0FBTyxNQUFLLE1BQVosRUFBbUIsTUFBSyxVQUF4QjtBQUZGLEtBVkY7QUFjRTtBQUFBO0FBQUE7QUFDRSxxQ0FBTyxNQUFLLFFBQVosRUFBcUIsT0FBTSxTQUEzQixFQUFxQyxTQUFTQSxNQUFNQyxnQkFBcEQ7QUFERjtBQWRGLEdBRGU7QUFBQSxDQUFqQjs7QUF1QkFDLE9BQU9ILFVBQVAsR0FBb0JBLFVBQXBCIiwiZmlsZSI6InNpZ251cC5qcyIsInNvdXJjZXNDb250ZW50IjpbInZhciBTaWdudXBGb3JtID0gKHByb3BzKSA9PiAoXHJcbiAgPGZvcm0gaWQ9XCJzaWdudXBGb3JtXCI+XHJcbiAgICA8ZGl2PlxyXG4gICAgICA8bGFiZWw+VXNlcm5hbWU6PC9sYWJlbD5cclxuICAgICAgPGlucHV0IHR5cGU9XCJ0ZXh0XCIgbmFtZT1cInVzZXJuYW1lXCIgaWQ9XCJzaWdudXAtdXNlcm5hbWVcIi8+XHJcbiAgICA8L2Rpdj5cclxuICAgIDxkaXY+XHJcbiAgICAgIDxsYWJlbD5FbWFpbDo8L2xhYmVsPlxyXG4gICAgICA8aW5wdXQgdHlwZT1cInRleHRcIiBuYW1lPVwiZW1haWxcIi8+XHJcbiAgICA8L2Rpdj5cclxuXHJcbiAgICA8ZGl2PlxyXG4gICAgICA8bGFiZWw+UGFzc3dvcmQ6PC9sYWJlbD5cclxuICAgICAgPGlucHV0IHR5cGU9XCJ0ZXh0XCIgbmFtZT1cInBhc3N3b3JkXCIvPlxyXG4gICAgPC9kaXY+XHJcbiAgICA8ZGl2PlxyXG4gICAgICA8aW5wdXQgdHlwZT1cInN1Ym1pdFwiIHZhbHVlPVwiU2lnbiBVcFwiIG9uQ2xpY2s9e3Byb3BzLnNpZ251cEZvcm1TdWJtaXR9Lz5cclxuICAgIDwvZGl2PlxyXG4gIDwvZm9ybT5cclxuXHJcbik7XHJcblxyXG5cclxud2luZG93LlNpZ251cEZvcm0gPSBTaWdudXBGb3JtOyJdfQ==