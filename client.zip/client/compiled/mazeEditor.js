"use strict";

var MazeEditor = function MazeEditor(props) {
  return React.createElement(
    "div",
    { className: "maze-editor" },
    React.createElement(
      "div",
      { className: "side-bar" },
      React.createElement(
        "h3",
        null,
        "Defaults"
      ),
      React.createElement(
        "table",
        { className: "default1", onClick: props.clickLevel.bind(undefined, props.def) },
        props.def.map(function (curr, indy) {
          return React.createElement(
            "tr",
            { className: "tablerow" },
            curr.map(function (num, index, arr) {
              if (num === 0) {
                return React.createElement("td", { className: "block1" });
              } else if (num === 1) {
                return React.createElement("td", { className: "block2" });
              } else if (num === 2) {
                return React.createElement("td", { className: "block3" });
              } else if (num === 3) {
                return React.createElement("td", { className: "block4" });
              }
            })
          );
        })
      )
    ),
    React.createElement(
      "div",
      { className: "legend" },
      React.createElement(
        "h3",
        null,
        "Legend"
      ),
      React.createElement(
        "table",
        { className: "legend-table" },
        React.createElement(
          "tr",
          { className: "legend-table-row", onClick: props.clickLegend.bind(undefined, 1) },
          React.createElement("td", { className: "legend-block1" }),
          React.createElement(
            "td",
            { className: "legend-empty" },
            "Empty"
          )
        ),
        React.createElement(
          "tr",
          { className: "legend-table-row", onClick: props.clickLegend.bind(undefined, 2) },
          React.createElement("td", { className: "legend-block2" }),
          React.createElement(
            "td",
            { className: "legend-block" },
            "block"
          )
        ),
        React.createElement(
          "tr",
          { className: "legend-table-row", onClick: props.clickLegend.bind(undefined, 3) },
          React.createElement("td", { className: "legend-block3" }),
          React.createElement(
            "td",
            { className: "legend-pellet" },
            "Pellet"
          )
        )
      )
    ),
    React.createElement(
      "table",
      { className: "maze-editor-table" },
      props.maze.map(function (curr, indy) {
        return React.createElement(
          "tr",
          { className: "maze-editor-row" },
          curr.map(function (num, index, arr) {
            if (num === 0) {
              return React.createElement("td", { className: "element", onDragEnter: props.click.bind(undefined, indy, index), onMouseDown: props.click.bind(undefined, indy, index) });
            } else if (num === 1) {
              return React.createElement("td", { className: "elemental", onDragEnter: props.click.bind(undefined, indy, index), onMouseDown: props.click.bind(undefined, indy, index) });
            } else if (num === 2) {
              return React.createElement("td", { className: "dot", onDragEnter: props.click.bind(undefined, indy, index), onMouseDown: props.click.bind(undefined, indy, index) });
            } else if (num === 3) {
              return React.createElement("td", { className: "pacman", onDragEnter: props.click.bind(undefined, indy, index), onMouseDown: props.click.bind(undefined, indy, index) });
            }
          })
        );
      })
    ),
    React.createElement(
      "button",
      { className: "button", onClick: props.amaze },
      "Maze"
    ),
    React.createElement(
      "button",
      { className: "button", onClick: props.saveMaze },
      "Save Maze!"
    )
  );
};

// PropTypes tell other developers what `props` a component expects
// Warnings will be shown in the console when the defined rules are violated
MazeEditor.propTypes = {
  maze: React.PropTypes.array.isRequired
};

// In the ES6 spec, files are "modules" and do not share a top-level scope.
// `var` declarations will only exist globally where explicitly defined.
window.MazeEditor = MazeEditor;
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIi4uL2NvbXBvbmVudHMvbWF6ZUVkaXRvci5qc3giXSwibmFtZXMiOlsiTWF6ZUVkaXRvciIsInByb3BzIiwiY2xpY2tMZXZlbCIsImJpbmQiLCJkZWYiLCJtYXAiLCJjdXJyIiwiaW5keSIsIm51bSIsImluZGV4IiwiYXJyIiwiY2xpY2tMZWdlbmQiLCJtYXplIiwiY2xpY2siLCJhbWF6ZSIsInNhdmVNYXplIiwicHJvcFR5cGVzIiwiUmVhY3QiLCJQcm9wVHlwZXMiLCJhcnJheSIsImlzUmVxdWlyZWQiLCJ3aW5kb3ciXSwibWFwcGluZ3MiOiI7O0FBQUEsSUFBSUEsYUFBYSxTQUFiQSxVQUFhLENBQUNDLEtBQUQ7QUFBQSxTQUNmO0FBQUE7QUFBQSxNQUFLLFdBQVcsYUFBaEI7QUFDRTtBQUFBO0FBQUEsUUFBSyxXQUFVLFVBQWY7QUFDRTtBQUFBO0FBQUE7QUFBQTtBQUFBLE9BREY7QUFFRTtBQUFBO0FBQUEsVUFBTyxXQUFVLFVBQWpCLEVBQTRCLFNBQVNBLE1BQU1DLFVBQU4sQ0FBaUJDLElBQWpCLFlBQTRCRixNQUFNRyxHQUFsQyxDQUFyQztBQUdFSCxjQUFNRyxHQUFOLENBQVVDLEdBQVYsQ0FBYyxVQUFDQyxJQUFELEVBQU9DLElBQVA7QUFBQSxpQkFDWjtBQUFBO0FBQUEsY0FBSSxXQUFVLFVBQWQ7QUFDQ0QsaUJBQUtELEdBQUwsQ0FBUyxVQUFDRyxHQUFELEVBQU1DLEtBQU4sRUFBYUMsR0FBYixFQUFxQjtBQUM3QixrQkFBSUYsUUFBUSxDQUFaLEVBQWU7QUFDYix1QkFBUSw0QkFBSSxXQUFVLFFBQWQsR0FBUjtBQUNELGVBRkQsTUFFTyxJQUFJQSxRQUFRLENBQVosRUFBZTtBQUNwQix1QkFBUSw0QkFBSSxXQUFVLFFBQWQsR0FBUjtBQUNELGVBRk0sTUFFQSxJQUFJQSxRQUFRLENBQVosRUFBZTtBQUNwQix1QkFBUSw0QkFBSSxXQUFVLFFBQWQsR0FBUjtBQUNELGVBRk0sTUFFQSxJQUFJQSxRQUFRLENBQVosRUFBZTtBQUNwQix1QkFBUSw0QkFBSSxXQUFVLFFBQWQsR0FBUjtBQUNEO0FBQ0YsYUFWQTtBQURELFdBRFk7QUFBQSxTQUFkO0FBSEY7QUFGRixLQURGO0FBeUJFO0FBQUE7QUFBQSxRQUFLLFdBQVUsUUFBZjtBQUNBO0FBQUE7QUFBQTtBQUFBO0FBQUEsT0FEQTtBQUVFO0FBQUE7QUFBQSxVQUFPLFdBQVUsY0FBakI7QUFDRTtBQUFBO0FBQUEsWUFBSSxXQUFVLGtCQUFkLEVBQWlDLFNBQVNQLE1BQU1VLFdBQU4sQ0FBa0JSLElBQWxCLFlBQTZCLENBQTdCLENBQTFDO0FBQ0Usc0NBQUksV0FBVSxlQUFkLEdBREY7QUFFRTtBQUFBO0FBQUEsY0FBSSxXQUFVLGNBQWQ7QUFBQTtBQUFBO0FBRkYsU0FERjtBQUtFO0FBQUE7QUFBQSxZQUFJLFdBQVUsa0JBQWQsRUFBaUMsU0FBU0YsTUFBTVUsV0FBTixDQUFrQlIsSUFBbEIsWUFBNkIsQ0FBN0IsQ0FBMUM7QUFDRSxzQ0FBSSxXQUFVLGVBQWQsR0FERjtBQUVFO0FBQUE7QUFBQSxjQUFJLFdBQVUsY0FBZDtBQUFBO0FBQUE7QUFGRixTQUxGO0FBU0U7QUFBQTtBQUFBLFlBQUksV0FBVSxrQkFBZCxFQUFpQyxTQUFTRixNQUFNVSxXQUFOLENBQWtCUixJQUFsQixZQUE2QixDQUE3QixDQUExQztBQUNFLHNDQUFJLFdBQVUsZUFBZCxHQURGO0FBRUU7QUFBQTtBQUFBLGNBQUksV0FBVSxlQUFkO0FBQUE7QUFBQTtBQUZGO0FBVEY7QUFGRixLQXpCRjtBQTBDRTtBQUFBO0FBQUEsUUFBTyxXQUFVLG1CQUFqQjtBQUVFRixZQUFNVyxJQUFOLENBQVdQLEdBQVgsQ0FBZSxVQUFDQyxJQUFELEVBQU9DLElBQVA7QUFBQSxlQUNiO0FBQUE7QUFBQSxZQUFJLFdBQVUsaUJBQWQ7QUFDQUQsZUFBS0QsR0FBTCxDQUFTLFVBQUNHLEdBQUQsRUFBTUMsS0FBTixFQUFhQyxHQUFiLEVBQXFCO0FBQzVCLGdCQUFJRixRQUFRLENBQVosRUFBZTtBQUNiLHFCQUFRLDRCQUFJLFdBQVUsU0FBZCxFQUF3QixhQUFjUCxNQUFNWSxLQUFOLENBQVlWLElBQVosWUFBdUJJLElBQXZCLEVBQTZCRSxLQUE3QixDQUF0QyxFQUEyRSxhQUFhUixNQUFNWSxLQUFOLENBQVlWLElBQVosWUFBdUJJLElBQXZCLEVBQTZCRSxLQUE3QixDQUF4RixHQUFSO0FBQ0QsYUFGRCxNQUVPLElBQUlELFFBQVEsQ0FBWixFQUFlO0FBQ3BCLHFCQUFRLDRCQUFJLFdBQVUsV0FBZCxFQUEwQixhQUFjUCxNQUFNWSxLQUFOLENBQVlWLElBQVosWUFBdUJJLElBQXZCLEVBQTZCRSxLQUE3QixDQUF4QyxFQUE2RSxhQUFhUixNQUFNWSxLQUFOLENBQVlWLElBQVosWUFBdUJJLElBQXZCLEVBQTZCRSxLQUE3QixDQUExRixHQUFSO0FBQ0QsYUFGTSxNQUVBLElBQUlELFFBQVEsQ0FBWixFQUFlO0FBQ3BCLHFCQUFRLDRCQUFJLFdBQVUsS0FBZCxFQUFvQixhQUFhUCxNQUFNWSxLQUFOLENBQVlWLElBQVosWUFBdUJJLElBQXZCLEVBQTZCRSxLQUE3QixDQUFqQyxFQUFzRSxhQUFhUixNQUFNWSxLQUFOLENBQVlWLElBQVosWUFBdUJJLElBQXZCLEVBQTZCRSxLQUE3QixDQUFuRixHQUFSO0FBQ0QsYUFGTSxNQUVBLElBQUlELFFBQVEsQ0FBWixFQUFlO0FBQ3BCLHFCQUFRLDRCQUFJLFdBQVUsUUFBZCxFQUF1QixhQUFhUCxNQUFNWSxLQUFOLENBQVlWLElBQVosWUFBdUJJLElBQXZCLEVBQTZCRSxLQUE3QixDQUFwQyxFQUF5RSxhQUFhUixNQUFNWSxLQUFOLENBQVlWLElBQVosWUFBdUJJLElBQXZCLEVBQTZCRSxLQUE3QixDQUF0RixHQUFSO0FBQ0Q7QUFDRixXQVZEO0FBREEsU0FEYTtBQUFBLE9BQWY7QUFGRixLQTFDRjtBQTZERTtBQUFBO0FBQUEsUUFBUSxXQUFVLFFBQWxCLEVBQTJCLFNBQVNSLE1BQU1hLEtBQTFDO0FBQUE7QUFBQSxLQTdERjtBQThERTtBQUFBO0FBQUEsUUFBUSxXQUFVLFFBQWxCLEVBQTJCLFNBQVViLE1BQU1jLFFBQTNDO0FBQUE7QUFBQTtBQTlERixHQURlO0FBQUEsQ0FBakI7O0FBbUVBO0FBQ0E7QUFDQWYsV0FBV2dCLFNBQVgsR0FBdUI7QUFDckJKLFFBQU1LLE1BQU1DLFNBQU4sQ0FBZ0JDLEtBQWhCLENBQXNCQztBQURQLENBQXZCOztBQUlBO0FBQ0E7QUFDQUMsT0FBT3JCLFVBQVAsR0FBb0JBLFVBQXBCIiwiZmlsZSI6Im1hemVFZGl0b3IuanMiLCJzb3VyY2VzQ29udGVudCI6WyJ2YXIgTWF6ZUVkaXRvciA9IChwcm9wcykgPT4gKFxyXG4gIDxkaXYgY2xhc3NOYW1lPSBcIm1hemUtZWRpdG9yXCI+XHJcbiAgICA8ZGl2IGNsYXNzTmFtZT1cInNpZGUtYmFyXCI+XHJcbiAgICAgIDxoMz5EZWZhdWx0czwvaDM+XHJcbiAgICAgIDx0YWJsZSBjbGFzc05hbWU9XCJkZWZhdWx0MVwiIG9uQ2xpY2s9e3Byb3BzLmNsaWNrTGV2ZWwuYmluZCh0aGlzLCBwcm9wcy5kZWYpfT5cclxuXHJcbiAgICAgIHtcclxuICAgICAgICBwcm9wcy5kZWYubWFwKChjdXJyLCBpbmR5KT0+IChcclxuICAgICAgICAgIDx0ciBjbGFzc05hbWU9XCJ0YWJsZXJvd1wiPlxyXG4gICAgICAgICAge2N1cnIubWFwKChudW0sIGluZGV4LCBhcnIpID0+IHtcclxuICAgICAgICAgICAgaWYgKG51bSA9PT0gMCkge1xyXG4gICAgICAgICAgICAgIHJldHVybiAoPHRkIGNsYXNzTmFtZT1cImJsb2NrMVwiID48L3RkPik7XHJcbiAgICAgICAgICAgIH0gZWxzZSBpZiAobnVtID09PSAxKSB7XHJcbiAgICAgICAgICAgICAgcmV0dXJuICg8dGQgY2xhc3NOYW1lPVwiYmxvY2syXCI+PC90ZD4pO1xyXG4gICAgICAgICAgICB9IGVsc2UgaWYgKG51bSA9PT0gMikge1xyXG4gICAgICAgICAgICAgIHJldHVybiAoPHRkIGNsYXNzTmFtZT1cImJsb2NrM1wiID48L3RkPik7XHJcbiAgICAgICAgICAgIH0gZWxzZSBpZiAobnVtID09PSAzKSB7XHJcbiAgICAgICAgICAgICAgcmV0dXJuICg8dGQgY2xhc3NOYW1lPVwiYmxvY2s0XCI+PC90ZD4pO1xyXG4gICAgICAgICAgICB9XHJcbiAgICAgICAgICB9KX1cclxuICAgICAgICAgIDwvdHI+XHJcbiAgICAgICAgKSlcclxuICAgICAgfVxyXG5cclxuICAgICAgPC90YWJsZT5cclxuICAgIDwvZGl2PlxyXG4gICAgPGRpdiBjbGFzc05hbWU9XCJsZWdlbmRcIj4gXHJcbiAgICA8aDM+TGVnZW5kPC9oMz5cclxuICAgICAgPHRhYmxlIGNsYXNzTmFtZT1cImxlZ2VuZC10YWJsZVwiPlxyXG4gICAgICAgIDx0ciBjbGFzc05hbWU9XCJsZWdlbmQtdGFibGUtcm93XCIgb25DbGljaz17cHJvcHMuY2xpY2tMZWdlbmQuYmluZCh0aGlzLCAxKX0+XHJcbiAgICAgICAgICA8dGQgY2xhc3NOYW1lPVwibGVnZW5kLWJsb2NrMVwiID48L3RkPlxyXG4gICAgICAgICAgPHRkIGNsYXNzTmFtZT1cImxlZ2VuZC1lbXB0eVwiPkVtcHR5PC90ZD5cclxuICAgICAgICA8L3RyPlxyXG4gICAgICAgIDx0ciBjbGFzc05hbWU9XCJsZWdlbmQtdGFibGUtcm93XCIgb25DbGljaz17cHJvcHMuY2xpY2tMZWdlbmQuYmluZCh0aGlzLCAyKX0+XHJcbiAgICAgICAgICA8dGQgY2xhc3NOYW1lPVwibGVnZW5kLWJsb2NrMlwiID48L3RkPlxyXG4gICAgICAgICAgPHRkIGNsYXNzTmFtZT1cImxlZ2VuZC1ibG9ja1wiPmJsb2NrPC90ZD5cclxuICAgICAgICA8L3RyPlxyXG4gICAgICAgIDx0ciBjbGFzc05hbWU9XCJsZWdlbmQtdGFibGUtcm93XCIgb25DbGljaz17cHJvcHMuY2xpY2tMZWdlbmQuYmluZCh0aGlzLCAzKX0+XHJcbiAgICAgICAgICA8dGQgY2xhc3NOYW1lPVwibGVnZW5kLWJsb2NrM1wiID48L3RkPlxyXG4gICAgICAgICAgPHRkIGNsYXNzTmFtZT1cImxlZ2VuZC1wZWxsZXRcIj5QZWxsZXQ8L3RkPlxyXG4gICAgICAgIDwvdHI+XHJcbiAgICAgIDwvdGFibGU+XHJcbiAgICA8L2Rpdj5cclxuICAgIDx0YWJsZSBjbGFzc05hbWU9XCJtYXplLWVkaXRvci10YWJsZVwiPlxyXG4gICAge1xyXG4gICAgICBwcm9wcy5tYXplLm1hcCgoY3VyciwgaW5keSk9PiAoXHJcbiAgICAgICAgPHRyIGNsYXNzTmFtZT1cIm1hemUtZWRpdG9yLXJvd1wiPntcclxuICAgICAgICBjdXJyLm1hcCgobnVtLCBpbmRleCwgYXJyKSA9PiB7XHJcbiAgICAgICAgICBpZiAobnVtID09PSAwKSB7XHJcbiAgICAgICAgICAgIHJldHVybiAoPHRkIGNsYXNzTmFtZT1cImVsZW1lbnRcIiBvbkRyYWdFbnRlciA9e3Byb3BzLmNsaWNrLmJpbmQodGhpcywgaW5keSwgaW5kZXgpfSBvbk1vdXNlRG93bj17cHJvcHMuY2xpY2suYmluZCh0aGlzLCBpbmR5LCBpbmRleCl9PjwvdGQ+KTtcclxuICAgICAgICAgIH0gZWxzZSBpZiAobnVtID09PSAxKSB7XHJcbiAgICAgICAgICAgIHJldHVybiAoPHRkIGNsYXNzTmFtZT1cImVsZW1lbnRhbFwiIG9uRHJhZ0VudGVyID17cHJvcHMuY2xpY2suYmluZCh0aGlzLCBpbmR5LCBpbmRleCl9IG9uTW91c2VEb3duPXtwcm9wcy5jbGljay5iaW5kKHRoaXMsIGluZHksIGluZGV4KX0+PC90ZD4pO1xyXG4gICAgICAgICAgfSBlbHNlIGlmIChudW0gPT09IDIpIHtcclxuICAgICAgICAgICAgcmV0dXJuICg8dGQgY2xhc3NOYW1lPVwiZG90XCIgb25EcmFnRW50ZXI9e3Byb3BzLmNsaWNrLmJpbmQodGhpcywgaW5keSwgaW5kZXgpfSBvbk1vdXNlRG93bj17cHJvcHMuY2xpY2suYmluZCh0aGlzLCBpbmR5LCBpbmRleCl9PjwvdGQ+KTtcclxuICAgICAgICAgIH0gZWxzZSBpZiAobnVtID09PSAzKSB7XHJcbiAgICAgICAgICAgIHJldHVybiAoPHRkIGNsYXNzTmFtZT1cInBhY21hblwiIG9uRHJhZ0VudGVyPXtwcm9wcy5jbGljay5iaW5kKHRoaXMsIGluZHksIGluZGV4KX0gb25Nb3VzZURvd249e3Byb3BzLmNsaWNrLmJpbmQodGhpcywgaW5keSwgaW5kZXgpfT48L3RkPik7XHJcbiAgICAgICAgICB9XHJcbiAgICAgICAgfSlcclxuICAgICAgICB9PC90cj5cclxuICAgICAgKSlcclxuICAgIH1cclxuICAgIDwvdGFibGU+XHJcbiAgICA8YnV0dG9uIGNsYXNzTmFtZT1cImJ1dHRvblwiIG9uQ2xpY2s9e3Byb3BzLmFtYXplfT5NYXplPC9idXR0b24+XHJcbiAgICA8YnV0dG9uIGNsYXNzTmFtZT1cImJ1dHRvblwiIG9uQ2xpY2sgPXtwcm9wcy5zYXZlTWF6ZX0+U2F2ZSBNYXplITwvYnV0dG9uPlxyXG4gIDwvZGl2PlxyXG4pO1xyXG5cclxuLy8gUHJvcFR5cGVzIHRlbGwgb3RoZXIgZGV2ZWxvcGVycyB3aGF0IGBwcm9wc2AgYSBjb21wb25lbnQgZXhwZWN0c1xyXG4vLyBXYXJuaW5ncyB3aWxsIGJlIHNob3duIGluIHRoZSBjb25zb2xlIHdoZW4gdGhlIGRlZmluZWQgcnVsZXMgYXJlIHZpb2xhdGVkXHJcbk1hemVFZGl0b3IucHJvcFR5cGVzID0ge1xyXG4gIG1hemU6IFJlYWN0LlByb3BUeXBlcy5hcnJheS5pc1JlcXVpcmVkXHJcbn07XHJcblxyXG4vLyBJbiB0aGUgRVM2IHNwZWMsIGZpbGVzIGFyZSBcIm1vZHVsZXNcIiBhbmQgZG8gbm90IHNoYXJlIGEgdG9wLWxldmVsIHNjb3BlLlxyXG4vLyBgdmFyYCBkZWNsYXJhdGlvbnMgd2lsbCBvbmx5IGV4aXN0IGdsb2JhbGx5IHdoZXJlIGV4cGxpY2l0bHkgZGVmaW5lZC5cclxud2luZG93Lk1hemVFZGl0b3IgPSBNYXplRWRpdG9yOyJdfQ==